# ScamGraph AI
### Explainable Scam Network Investigator | FalkorDB Graph Hacks 2026

**Tagline:** *Investigate the network. Expose the pattern. Explain every decision.*

ScamGraph AI is an autonomous, explainable cyber-threat investigation engine built on **FalkorDB**. When presented with a suspicious message, phishing link, payment cashtag, or brand impersonation lure, ScamGraph AI traverses a connected knowledge graph to uncover shared infrastructure, multi-incident syndicates, and forensic evidence trails—producing an inspectable, evidence-grounded risk assessment.

---

## 🏆 FalkorDB Graph Hacks 2026 Tracks
- **Primary Track:** **Track 01 — Agents That Act on Connected Data** (Autonomous 5-stage agent pipeline querying FalkorDB via multi-hop Cypher traversals).
- **Secondary Track:** **Track 02 — Memory & Feedback Loop** (Persists investigation history, evidence relationships, and human analyst review nodes in FalkorDB).

---

## 1. Problem Statement & Intended Users

### The Problem
Conventional scam detection tools examine text in isolation using basic keyword rules or generic LLM prompts. However, modern cybercrime operates via coordinated fraud syndicates that reuse:
- Bulletproof DNS hosting providers and authoritative nameservers
- Wildcard TLS certificates across fake portals
- Spoofed VoIP telephony blocks
- Cryptocurrency staging wallets and peer-to-peer handles

An isolated message might appear novel, yet its technical infrastructure is tied directly to dozens of reported scam incidents across the web.

### Intended Users
- **Cybersecurity Operations Centers (SOC):** Rapidly triage suspicious inbound SMS, emails, and employee phish reports.
- **Fraud Analysts & Investigators:** Inspect multi-hop attack trails and discover campaign syndicates.
- **Consumer Protection Platforms:** Expose fake logistics, advance-fee jobs, and banking lures with clear defensive next steps.

---

## 2. Product Overview & Key Implemented Features

1. **Autonomous 5-Stage Agent Pipeline:**
   - **Stage A (Input Analysis):** Extracts domains, URLs, phone numbers, cashtags, crypto wallets, claimed brands, and urgency cues.
   - **Stage B (FalkorDB Traversal):** Parameterized Cypher queries discover exact matches, expand relationships up to 3 hops, and reveal shared hosting bridges.
   - **Stage C (Deterministic Scoring):** 6 transparent, inspectable rules calculate a 0–100 score, separating score, confidence, and coverage.
   - **Stage D (Grounded Synthesis):** Validates all evidence IDs (`EVD-xxx`) against actual database nodes.
   - **Stage E (Persistent Memory):** Stores the investigation dossier and analyst feedback into FalkorDB.

2. **Interactive Graph Evidence Explorer:**
   - Force-directed network graph powered by `react-force-graph-2d`.
   - Distinct cyber-palette nodes for Brands (Sky), Indicators (Rose), Incidents (Amber), Campaigns (Purple), and Evidence (Emerald).
   - Node selection inspector drawer, zoom controls, and path highlighting.

3. **Multi-Hop Explainability Trails:**
   - Visual step-by-step breadcrumb cards (`Submitted Domain → Shared Infrastructure → Incident → Campaign`) explaining why each connection matters.

4. **Counterfactual Risk Explorer ("What-If?"):**
   - Interactive simulation allowing analysts to temporarily toggle off any evidence signal and observe real-time score recalculation with deltas (e.g. `-20 pts`), without mutating FalkorDB.

5. **Multi-Scenario Demo Lab:**
   - Pre-loaded benchmarks: Fictional Bank Account Lockout, SwiftDrop Courier Customs Fee, Apex Career Wire Deposit, and an Uncataloged Indicator test.

6. **Responsible AI & Unknown Indicator Handling:**
   - When an indicator is absent from FalkorDB, the system classifies the result as **INSUFFICIENT EVIDENCE**, avoiding the dangerous false reassurance of safety that LLMs often give.

7. **Human-in-the-Loop Analyst Feedback:**
   - Records provisional verdicts (`CONFIRMED_FRAUD`, `NEEDS_REVIEW`, `FALSE_POSITIVE`) directly to FalkorDB as review nodes.

8. **Exportable Dossiers:**
   - One-click export to Markdown (`.md`) and full JSON datasets.

---

## 3. Why FalkorDB is Essential

FalkorDB provides the foundational graph database capabilities that make ScamGraph AI possible:
- **Ultra-Fast Multi-Hop Traversals:** FalkorDB executes multi-hop Cypher queries in milliseconds using sparse matrix linear algebra.
- **Graph Source of Truth:** Relationships like `(:Indicator)-[:LINKED_TO]->(:Indicator)` and `(:Incident)-[:PART_OF]->(:Campaign)` are queried dynamically, preventing hardcoded lookups.
- **Persistent Investigation Lineage:** Investigations and analyst reviews are persisted as native graph nodes, enabling future queries to traverse past investigations.

---

## 4. FalkorDB Graph Schema & Cypher Queries

### Node Entities
- `(:Brand {id, name, officialDomain, industry})`
- `(:Indicator {id, value, indicatorType, displayValue, riskWeight})`
- `(:Incident {id, summary, category, timestamp, severity, victimCountEstimate})`
- `(:Campaign {id, label, description, status})`
- `(:Evidence {id, evidenceType, description, confidence, sourceType})`
- `(:Investigation {id, rawTextPreview, riskScore, riskLevel, timestamp})`
- `(:AnalystFeedback {id, verdict, note, timestamp})`

### Relationship Graph
```cypher
(:Incident)-[:MENTIONS]->(:Indicator)
(:Incident)-[:IMPERSONATES]->(:Brand)
(:Incident)-[:PART_OF]->(:Campaign)
(:Indicator)-[:LINKED_TO {basis, confidence}]->(:Indicator)
(:Investigation)-[:FOUND]->(:Indicator)
(:Investigation)-[:SUPPORTED_BY]->(:Evidence)
(:AnalystFeedback)-[:REVIEWS]->(:Investigation)
```

### Representative Parameterized Cypher Queries

**Find 3-Hop Neighbors:**
```cypher
MATCH path = (i:Indicator {id: $indicatorId})-[*1..3]-(connected)
RETURN path
LIMIT 50
```

**Find Infrastructure Pivot Across Campaigns:**
```cypher
MATCH (i1:Indicator {id: $sourceId})-[:LINKED_TO]->(shared:Indicator)<-[:LINKED_TO]-(i2:Indicator)
MATCH (inc:Incident)-[:MENTIONS]->(i2)
RETURN shared, i2, inc
```

---

## 5. Local Installation & Configuration

### Prerequisites
- Node.js 22+
- Docker & Docker Compose (optional, for local FalkorDB server)

### 1. Clone & Install
```bash
git clone <repo-url>
cd scamgraph-ai
npm install
```

### 2. Environment Variables (.env)
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Key configuration options:
```env
# FalkorDB Connection (default: local Docker)
FALKORDB_URL="falkordb://localhost:6379"

# Optional LLM Key (Gemini or OpenAI). If omitted, deterministic grounded engine is used.
GEMINI_API_KEY=""
OPENAI_API_KEY=""

PORT=3000
```

### 3. Run FalkorDB (via Docker)
```bash
docker run -p 6379:6379 -it --rm falkordb/falkordb
```
*Or using docker-compose:*
```bash
docker compose up -d
```

### 4. Start the Fullstack App
```bash
npm run dev
```
Open **`http://localhost:3000`** in your browser.

---

## 6. Testing & Acceptance Verification

Run the built-in unit test suite (Node 22 native test runner):
```bash
npm test
```
**Tests Executed (8 passing):**
- Domain & URL normalization
- E.164 phone parsing
- Cashtags & crypto wallet address recognition
- Entity extraction & urgency cue detection
- Unknown indicator classification (`INSUFFICIENT_EVIDENCE`)
- High-risk indicator and brand impersonation scoring
- Counterfactual simulation score delta verification

---

## 7. Responsible AI & Synthetic Data Disclosure

- **Ethical Testbed:** All brand names (e.g. *Northstar Bank*, *SwiftDrop Logistics*) and web domains (e.g. `.test`) used in pre-cataloged incidents are 100% synthetic to ensure safety and ethical handling.
- **Decision Support:** ScamGraph AI provides explainable decision support heuristics, not law enforcement attribution. Users are prompted to independently verify suspicious messages through official, out-of-band channels.

---

## 8. AI Coding Assistant Disclosure

This project was built and designed using Google AI Studio Build assistant, utilizing the official `falkordb` Node.js client, Tailwind CSS, React, and Express.
