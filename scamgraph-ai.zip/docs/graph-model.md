# FalkorDB Graph Schema & Model Documentation

## 1. Graph Entity Types (Nodes)

| Label | Primary Properties | Description |
| :--- | :--- | :--- |
| `:Brand` | `id, name, classification, officialDomain, industry` | Fictional or emulated corporate brand impersonated by threat actors. |
| `:Indicator` / `:Domain` | `id, value, indicatorType, displayValue, firstSeen, riskWeight, isSynthetic` | Atomic observable (domain, URL, phone, cashtag, crypto address, email). |
| `:Incident` | `id, summary, category, timestamp, severity, victimCountEstimate` | Cataloged synthetic fraud report or victim complaint event. |
| `:Campaign` | `id, label, description, status, isSynthetic` | Coordinated threat syndicate operating multi-wave operations. |
| `:Evidence` | `id, evidenceType, description, confidence, sourceType` | Forensic corroboration (DNS co-hosting, TLS cert signatures, telecom registry). |
| `:Investigation` | `id, rawTextPreview, riskScore, riskLevel, timestamp` | Past investigation record stored in FalkorDB persistent memory. |
| `:AnalystFeedback` | `id, verdict, note, timestamp` | Human-in-the-loop analyst assessment audit node. |

---

## 2. Graph Relationship Types (Edges)

```cypher
(:Incident)-[:MENTIONS]->(:Indicator)
(:Incident)-[:IMPERSONATES]->(:Brand)
(:Incident)-[:PART_OF]->(:Campaign)
(:Indicator)-[:LINKED_TO {basis, confidence}]->(:Indicator)
(:Investigation)-[:FOUND]->(:Indicator)
(:Investigation)-[:SUPPORTED_BY]->(:Evidence)
(:AnalystFeedback)-[:REVIEWS]->(:Investigation)
```

### Relationship Semantics

1. `(:Incident)-[:MENTIONS]->(:Indicator)`
   Indicates that a reported synthetic scam event explicitly referenced the given domain, phone, or payment handle in its lure.

2. `(:Incident)-[:IMPERSONATES]->(:Brand)`
   Indicates unauthorized brand usage in the incident's social engineering copy.

3. `(:Incident)-[:PART_OF]->(:Campaign)`
   Associates an incident with an overarching threat campaign ring.

4. `(:Indicator)-[:LINKED_TO {basis, confidence}]->(:Indicator)`
   Forensic bridge between observables (e.g. `basis: 'DNS_RESOLVES_TO'`, `basis: 'SHARED_TLS_CERT'`, `basis: 'AUTHORITATIVE_NS'`).

5. `(:Investigation)-[:FOUND]->(:Indicator)`
   Maintains graph audit lineage between an automated investigation session and matched indicators.

6. `(:Investigation)-[:SUPPORTED_BY]->(:Evidence)`
   Links findings in an investigation to corroborating forensic evidence.

7. `(:AnalystFeedback)-[:REVIEWS]->(:Investigation)`
   Attaches provisional human assessment to the investigation dossier.

---

## 3. Core Parameterized Cypher Queries

### A. Exact Match
```cypher
MATCH (i:Indicator)
WHERE toLower(i.value) = $cleanValue
RETURN i
```

### B. 3-Hop Multi-Hop Expansion
```cypher
MATCH path = (i:Indicator {id: $indicatorId})-[*1..3]-(target)
RETURN path
LIMIT 50
```

### C. Shared Infrastructure Bridge Discovery
```cypher
MATCH (i1:Indicator {id: $sourceId})-[:LINKED_TO]->(shared:Indicator)<-[:LINKED_TO]-(i2:Indicator)
MATCH (inc:Incident)-[:MENTIONS]->(i2)
RETURN shared, i2, inc
```

### D. Campaign Cluster Attribution
```cypher
MATCH (i:Indicator {id: $indicatorId})<-[:MENTIONS]-(inc:Incident)-[:PART_OF]->(c:Campaign)
RETURN c, count(inc) AS incidentCount
```

### E. Seed Persistence (Idempotent MERGE)
```cypher
MERGE (i:Indicator {id: $id})
ON CREATE SET i.value = $value, i.displayValue = $displayValue,
              i.riskWeight = $riskWeight, i.isSynthetic = true
```
