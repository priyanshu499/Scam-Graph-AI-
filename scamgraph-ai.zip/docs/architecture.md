# ScamGraph AI — Architecture & Data Flow

## 1. Executive Architecture Overview

ScamGraph AI is an explainable cyber-threat investigation engine powered by **FalkorDB**, designed to unmask multi-hop fraud networks, shared malicious infrastructure, and brand impersonation syndicates.

While conventional fraud systems evaluate messages using isolated text heuristics, ScamGraph AI pivots on connected graph intelligence:
1. **Discovers Hidden Infrastructure:** Traces shared DNS nameservers, TLS wildcard certificates, bulletproof hosting IPs, and payment staging wallets that connect seemingly distinct scam messages.
2. **Explains Every Decision:** Derives deterministic, transparent risk scores from inspectable graph rules rather than LLM hallucinations.
3. **Persists Memory & Feedback:** Stores every investigation and human analyst review node back into FalkorDB.

```
                    ┌────────────────────────────┐
                    │     Suspicious Input       │
                    │   (SMS, Domain, Email)     │
                    └─────────────┬──────────────┘
                                  │
                                  ▼
               [Stage A] Entity Extraction & Normalization
                                  │
                                  ▼
               [Stage B] FalkorDB Parameterized Cypher Queries
                    ├── Indicator & Brand Exact Match
                    ├── 3-Hop Multi-Hop Expansion
                    ├── Incident Corroboration
                    └── Infrastructure Pivot Traversal
                                  │
                                  ▼
               [Stage C] Deterministic Risk Scoring Engine
                    ├── 6 Documented Transparent Rules
                    ├── Score, Confidence, Coverage Split
                    └── Counterfactual Simulation ("What-If?")
                                  │
                                  ▼
               [Stage D] Structured Report Synthesis
                    └── Validates All Evidence IDs Against Graph
                                  │
                                  ▼
               [Stage E] FalkorDB Persistent Memory
                    ├── Save Investigation Node & Links
                    └── Audit Ledger & Analyst Reviews
```

---

## 2. Component Pipeline Details

### Stage A — Input Analysis & Entity Extraction
- Scans user input for:
  - Domains and URLs (`northstar-verify.test`, `swiftdrop-pay.test/fee/...`)
  - Phone numbers (`+1-800-555-0199`)
  - Payment handles & crypto wallets (`$northstar-help`, `0x9f82...`)
  - Claimed brands (`Northstar Bank`, `SwiftDrop Logistics`, `Apex Global Careers`)
  - Coercive urgency cues (account suspension, credential demands, detention fees).
- Normalizes observables into canonical forms (e.g., protocol removal, E.164 phone formatting).

### Stage B — FalkorDB Knowledge Graph Traversal
- Queries the FalkorDB graph using parameterized Cypher queries:
  - `MATCH (i:Indicator {value: $val})`
  - `MATCH (i)-[*1..3]-(connected)`
  - `MATCH (i1)-[:LINKED_TO]->(shared)<-[:LINKED_TO]-(i2)`
- Finds related synthetic incidents, associated campaign syndicates, and forensic evidence records.

### Stage C — Deterministic Risk Scoring
- Strict inspectable formula (capped at 100):
  1. **Pre-Cataloged High-Risk Indicator:** +25 pts
  2. **Multi-Incident Cluster Recurrence:** up to +20 pts (1 inc: 10, 2 incs: 15, >=3 incs: 20)
  3. **Brand Impersonation Signal:** +20 pts (Discrepancy between brand and destination domain)
  4. **Shared Infrastructure / Pivot:** +20 pts (Nameserver, TLS cert, hosting IP, wallet bridge)
  5. **Urgency & Credential Coercion:** up to +10 pts
  6. **URL Obfuscation & Path Structure:** +5 pts
- Distinct metrics:
  - `riskScore`: 0–100 numerical heuristic
  - `evidenceConfidence`: percentage based on average confidence of corroborated evidence nodes
  - `evidenceCoverage`: HIGH, MODERATE, LOW, or INSUFFICIENT
- **Responsible AI Rule:** If zero indicators match in FalkorDB, the system classifies the outcome as **INSUFFICIENT EVIDENCE**, explicitly warning that absence of data does NOT prove safety.

### Stage D — Evidence-Grounded Report Synthesis
- Integrates LLM (Gemini 2.5 Flash / OpenAI compatible) or deterministic evidence summarizer.
- Strict post-generation verification: checks every referenced `evidenceId` against real nodes in the database. Unsupported claims are stripped or rephrased as uncertainties.

### Stage E — Persistent Memory & Feedback
- Creates `(:Investigation)` nodes in FalkorDB linked via `[:FOUND]` and `[:SUPPORTED_BY]`.
- Allows security analysts to record `(:AnalystFeedback)` nodes with verdicts (`CONFIRMED_FRAUD`, `NEEDS_REVIEW`, `FALSE_POSITIVE`).

---

## 3. Deployment Topology

- **Docker Compose:** Provisions the official `falkordb/falkordb:latest` container alongside the fullstack Node 22 + React application.
- **Port:** Dev and production server operate on port 3000.
