# ScamGraph AI — Hackathon 90-120 Second Demo Walkthrough

## Scene 1: Introduction & The Problem (0:00 - 0:20)
- **Speaker:** "Conventional spam filters only analyze keywords in a suspicious message. But sophisticated threat actors operate networks. Welcome to **ScamGraph AI**, built for the FalkorDB Graph Hacks 2026. Our tagline: *Investigate the network. Expose the pattern. Explain every decision.*"
- **Action:** Show the Command Center dashboard with live FalkorDB telemetry (52 nodes, 68 edges, 14 incidents).

## Scene 2: Scenario 1 — Multi-Hop Threat Traversal (0:20 - 0:50)
- **Speaker:** "Let's submit a common SMS lure: *'URGENT: Northstar Bank says my account will be suspended in 24 hours unless I verify my identity at northstar-verify.test.'*"
- **Action:** Click Scenario 1 and hit **Execute Investigation**.
- **Speaker:** "Watch the 5-stage agent pipeline execute across FalkorDB:
  1. It extracts `northstar-verify.test`, the brand `Northstar Bank`, and VoIP phone `+1-800-555-0199`.
  2. It queries FalkorDB and traverses 3 hops: uncovering 5 linked incidents and a bulletproof host IP.
  3. Notice the **Explainability Trail**: it shows step-by-step why the score is 90/100, citing concrete evidence IDs like `EVD-101` and `EVD-102`."
- **Action:** Click a path in the Explainability Trail to highlight the nodes and links directly on the interactive graph.

## Scene 3: Counterfactual Risk Explorer ("What-If?") (0:50 - 1:10)
- **Speaker:** "ScamGraph AI includes a unique Counterfactual Risk Explorer. What if the domain had not shared bulletproof infrastructure with other scams? Let's uncheck *Shared Infrastructure*."
- **Action:** Uncheck the checkbox in Counterfactual Risk Explorer.
- **Speaker:** "The score immediately recalculates from 90 to 70 with an explainable -20 point delta. The analyst can test hypotheses without mutating the underlying database."

## Scene 4: Responsible AI — The Unknown Indicator Test (1:10 - 1:30)
- **Speaker:** "Now let's test what happens when an indicator has NO graph history. Let's submit `unknown-vendor-portal.test`."
- **Action:** Click Scenario 4 in the Demo Lab.
- **Speaker:** "Look at the verdict: **INSUFFICIENT EVIDENCE**. Most AI chatbots make the dangerous mistake of assuring users that unindexed links are 'Safe'. ScamGraph AI enforces Responsible AI: zero graph evidence means insufficient data, prompting cautious out-of-band verification."

## Scene 5: Persistent Memory & Analyst Feedback Loop (1:30 - 2:00)
- **Speaker:** "Finally, every investigation persists into FalkorDB. Let's record human analyst feedback: *'Confirmed Fraud - phishing kit v4.2'*. We save it, and it instantly links to the investigation node in the database.
- We can download the full dossier as Markdown or JSON, and view past investigations in the audit ledger."
- **Action:** Show Download Markdown button and History Page.
- **Speaker:** "ScamGraph AI: exposing fraud networks with the power of FalkorDB."
