import React from 'react';
import { FlaskConical, ArrowRight, ShieldCheck, AlertCircle, HelpCircle, Database, CheckCircle2 } from 'lucide-react';

interface DemoLabPageProps {
  onRunScenario: (text: string) => void;
}

export const DemoLabPage: React.FC<DemoLabPageProps> = ({ onRunScenario }) => {
  const SCENARIOS = [
    {
      id: 'demo-northstar',
      title: 'Scenario 1: Fictional Bank Account Lockout',
      brand: 'Northstar Bank (Synthetic)',
      category: 'Banking Credential Phishing Syndicate',
      text: 'URGENT: Northstar Bank says my account will be suspended in 24 hours unless I verify my identity at northstar-verify.test. Call +1-800-555-0199 if questions.',
      expectedPoints: '85 - 95 / 100 (High Risk)',
      behavior: 'Matches high-risk pre-cataloged domain, traverses 5 linked incidents, identifies spoofed VoIP number, and traces shared bulletproof DNS host (198.51.100.44).',
      badge: 'Known Syndicate'
    },
    {
      id: 'demo-swiftdrop',
      title: 'Scenario 2: Fictional Courier Detained Parcel Fee',
      brand: 'SwiftDrop Logistics (Synthetic)',
      category: 'Courier Customs Extortion & Card Skimming',
      text: 'SwiftDrop Logistics: Your package parcel-9842 is detained at customs. Pay pending $2.85 handling fee immediately at swiftdrop-pay.test or send to $swiftdrop-release to avoid return.',
      expectedPoints: '80 - 90 / 100 (High Risk)',
      behavior: 'Identifies credit card harvesting endpoint and flags peer-to-peer cashtag. Traversal discovers cross-campaign TLS certificate bridge linking to Northstar infrastructure!',
      badge: 'Cross-Campaign Bridge'
    },
    {
      id: 'demo-apexcareer',
      title: 'Scenario 3: Fictional Remote Job Starter Fee',
      brand: 'Apex Global Careers (Synthetic)',
      category: 'Employment Advance-Fee & Crypto Theft',
      text: 'Congratulations! You have been accepted for the remote Data Analyst role at Apex Global Careers. Please complete onboarding and deposit your $350 training kit bond to 0x9f82c40134d4a8e2 or $apexcareers_hr at apex-career-fee.test.',
      expectedPoints: '85 - 95 / 100 (High Risk)',
      behavior: 'Detects job advance-fee scheme, links crypto staging wallet (0x9f82...) and CashApp tag ($apexcareers_hr) across multiple victim complaint records.',
      badge: 'Advance Fee Ring'
    },
    {
      id: 'demo-unknown',
      title: 'Scenario 4: Unindexed Entity (Responsible AI Benchmark)',
      brand: 'Uncataloged Vendor',
      category: 'Zero Graph Records / Insufficient Evidence',
      text: 'Please review your quarterly corporate dashboard invoice at unknown-vendor-portal.test or submit support queries to support@unknown-vendor-portal.test.',
      expectedPoints: '0 / 100 (Insufficient Evidence)',
      behavior: 'Critical Responsible AI check: Because zero records exist in FalkorDB, the agent flags INSUFFICIENT EVIDENCE rather than giving a dangerous false assurance of safety.',
      badge: 'Responsible AI'
    }
  ];

  return (
    <div className="p-4 sm:p-6 space-y-5 max-w-7xl mx-auto">
      {/* Header */}
      <div className="rounded-xl border border-slate-800 bg-[#0B111E] p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-3 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <FlaskConical className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white">Multi-Scenario Investigation Lab</h2>
            <p className="text-xs text-slate-400">
              Deterministic evaluation benchmarks across known syndicates and uncataloged test cases
            </p>
          </div>
        </div>

        <span className="text-xs font-mono text-cyan-400 bg-cyan-950/60 border border-cyan-800/60 px-3 py-1.5 rounded-lg">
          4 Pre-Seeded Evaluation Scenarios
        </span>
      </div>

      {/* Scenario Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {SCENARIOS.map(sc => (
          <div
            key={sc.id}
            className="p-5 rounded-xl border border-slate-800 bg-[#0B111E] hover:border-slate-700 transition flex flex-col justify-between gap-4 shadow-sm"
          >
            <div className="space-y-2.5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-bold text-slate-200">{sc.title}</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 text-cyan-400 border border-slate-700">
                  {sc.badge}
                </span>
              </div>

              <div className="text-xs font-mono text-slate-400 bg-slate-950/70 p-2.5 rounded-lg border border-slate-800 leading-relaxed">
                "{sc.text}"
              </div>

              <div className="space-y-1.5 text-xs text-slate-300">
                <div className="flex items-center gap-1.5 text-[11px]">
                  <span className="text-slate-500">Expected Score:</span>
                  <span className="text-cyan-400 font-semibold">{sc.expectedPoints}</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  <strong className="text-slate-300">Graph Behavior: </strong>
                  {sc.behavior}
                </p>
              </div>
            </div>

            <button
              onClick={() => onRunScenario(sc.text)}
              className="w-full text-xs font-semibold py-2 px-3 rounded-lg bg-slate-900 hover:bg-cyan-500/20 text-cyan-300 hover:text-cyan-200 border border-slate-700/80 hover:border-cyan-500/40 flex items-center justify-center gap-1.5 transition"
            >
              <span>Load & Run in Workspace</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
