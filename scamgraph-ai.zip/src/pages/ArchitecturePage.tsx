import React, { useState } from 'react';
import { Layers, Database, Code, Terminal, CheckCircle2, Shield, ArrowRight, ExternalLink } from 'lucide-react';

export const ArchitecturePage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'schema' | 'cypher' | 'pipeline' | 'docker'>('schema');

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="rounded-xl border border-slate-800 bg-[#0B111E] p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-3 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <Layers className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white">System Architecture & FalkorDB Knowledge Model</h2>
            <p className="text-xs text-slate-400">
              Graph schema, Cypher query patterns, and agent pipeline specifications
            </p>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs font-mono">
          {[
            { id: 'schema', label: 'Graph Model' },
            { id: 'cypher', label: 'Cypher Queries' },
            { id: 'pipeline', label: 'Agent Pipeline' },
            { id: 'docker', label: 'Docker & FalkorDB' }
          ].map(t => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as any)}
              className={`px-3 py-1.5 rounded transition ${
                activeTab === t.id
                  ? 'bg-cyan-500 text-slate-950 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab 1: Graph Model & Schema */}
      {activeTab === 'schema' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Node Entities */}
            <div className="rounded-xl border border-slate-800 bg-[#0B111E] p-5 space-y-3">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Database className="h-4 w-4 text-cyan-400" />
                <span>Node Entity Types</span>
              </h3>
              <div className="space-y-2 text-xs">
                {[
                  { name: 'Brand', desc: 'Legitimate or fictional organization (e.g. Northstar Bank, official domain, industry).', color: 'text-sky-400 border-sky-800/40' },
                  { name: 'Indicator / Domain', desc: 'Extracted atomic observable: domain, URL, phone, or payment handle with risk weight.', color: 'text-rose-400 border-rose-800/40' },
                  { name: 'Incident', desc: 'Synthetic historical fraud incident with victim count estimate, severity, and category.', color: 'text-amber-400 border-amber-800/40' },
                  { name: 'Campaign', desc: 'Organized fraud syndicate coordinating multiple domain waves and shared tools.', color: 'text-purple-400 border-purple-800/40' },
                  { name: 'Evidence', desc: 'Verifiable technical artifacts: DNS co-hosting, TLS cert signatures, carrier registry, victim reports.', color: 'text-emerald-400 border-emerald-800/40' },
                  { name: 'Investigation', desc: 'Persisted analysis record with risk score, findings, and graph snapshot.', color: 'text-cyan-400 border-cyan-800/40' },
                  { name: 'AnalystFeedback', desc: 'Human-in-the-loop review nodes recording provisional verdict and notes.', color: 'text-teal-400 border-teal-800/40' }
                ].map(n => (
                  <div key={n.name} className="p-2.5 rounded-lg bg-slate-900/70 border border-slate-800/80">
                    <span className={`font-mono font-bold ${n.color}`}>{n.name}</span>
                    <p className="text-[11px] text-slate-400 mt-0.5">{n.desc}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Relationship Types */}
            <div className="rounded-xl border border-slate-800 bg-[#0B111E] p-5 space-y-3">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Layers className="h-4 w-4 text-purple-400" />
                <span>Relationship Definitions</span>
              </h3>
              <div className="space-y-2 text-xs font-mono">
                {[
                  { cypher: '(:Incident)-[:MENTIONS]->(:Indicator)', meaning: 'Incident report explicitly cites or targets the indicator observable.' },
                  { cypher: '(:Incident)-[:IMPERSONATES]->(:Brand)', meaning: 'Incident deceptively poses as the target legitimate brand.' },
                  { cypher: '(:Incident)-[:PART_OF]->(:Campaign)', meaning: 'Incident is attributed to a coordinated campaign syndicate.' },
                  { cypher: '(:Indicator)-[:LINKED_TO {basis, confidence}]->(:Indicator)', meaning: 'Technical infrastructure connection (DNS co-hosting, shared TLS cert, VoIP routing).' },
                  { cypher: '(:Investigation)-[:FOUND]->(:Indicator)', meaning: 'Investigation matched the indicator in its initial input extraction.' },
                  { cypher: '(:Investigation)-[:SUPPORTED_BY]->(:Evidence)', meaning: 'Investigation conclusion is backed by specific evidence artifacts.' },
                  { cypher: '(:AnalystFeedback)-[:REVIEWS]->(:Investigation)', meaning: 'Human analyst audit record reviewing the automated dossier.' }
                ].map((r, i) => (
                  <div key={i} className="p-2.5 rounded-lg bg-slate-900/70 border border-slate-800/80">
                    <div className="text-cyan-300 font-semibold text-[11px]">{r.cypher}</div>
                    <div className="text-[11px] text-slate-400 font-sans mt-0.5">{r.meaning}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Parameterized Cypher Queries */}
      {activeTab === 'cypher' && (
        <div className="rounded-xl border border-slate-800 bg-[#0B111E] p-5 space-y-4">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Code className="h-4 w-4 text-cyan-400" />
            <span>FalkorDB Parameterized Cypher Implementations</span>
          </h3>

          <div className="space-y-3 text-xs font-mono">
            {[
              {
                title: 'Multi-Hop Relationship Expansion (Up to 3 Hops)',
                cypher: `MATCH path = (i:Indicator {id: $indicatorId})-[*1..3]-(connected)
RETURN path, connected
LIMIT 50`
              },
              {
                title: 'Disclose Shared Infrastructure Connecting Disparate Incidents',
                cypher: `MATCH (i1:Indicator {id: $indicatorId})-[:LINKED_TO]->(shared:Indicator)<-[:LINKED_TO]-(i2:Indicator)
MATCH (inc:Incident)-[:MENTIONS]->(i2)
RETURN shared, i2, inc`
              },
              {
                title: 'Find Supporting Evidence for Matched Findings',
                cypher: `MATCH (i:Indicator {id: $indicatorId})-[:SUPPORTED_BY]->(e:Evidence)
RETURN e.id, e.evidenceType, e.description, e.confidence`
              },
              {
                title: 'Persist Investigation and Found Relationships',
                cypher: `MERGE (inv:Investigation {id: $id})
ON CREATE SET inv.riskScore = $score, inv.riskLevel = $riskLevel, inv.timestamp = $timestamp
WITH inv
MATCH (i:Indicator {id: $indicatorId})
MERGE (inv)-[:FOUND]->(i)`
              }
            ].map((q, i) => (
              <div key={i} className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 space-y-1.5">
                <div className="text-cyan-400 font-bold text-xs">{q.title}</div>
                <pre className="text-slate-300 overflow-x-auto p-2 bg-slate-900 rounded border border-slate-800 text-[11px] leading-relaxed">
                  {q.cypher}
                </pre>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Agent Pipeline */}
      {activeTab === 'pipeline' && (
        <div className="rounded-xl border border-slate-800 bg-[#0B111E] p-5 space-y-4">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Shield className="h-4 w-4 text-cyan-400" />
            <span>Bounded 5-Stage Agent Pipeline</span>
          </h3>

          <div className="space-y-3 text-xs">
            {[
              { stage: 'Stage A: Input Analysis', desc: 'Extracts domains, URLs, phone numbers, payment handles, claimed brands, and urgency cues. Normalizes strings into canonical values.' },
              { stage: 'Stage B: FalkorDB Graph Traversal', desc: 'Queries FalkorDB for matching entities, traverses relationships up to 3 hops, discovers shared nameservers/TLS certs/wallets, and gathers incident clusters.' },
              { stage: 'Stage C: Deterministic Scoring', desc: 'Calculates inspectable 0-100 score using 6 documented rules (Indicator match, incident recurrence, brand impersonation, shared infra, urgency, URL obfuscation). Separates score, confidence, and coverage.' },
              { stage: 'Stage D: Grounded Synthesis', desc: 'Synthesizes executive summary and structured findings. Rigorously validates evidence IDs against actual retrieved graph records; never hallucinates or invents links.' },
              { stage: 'Stage E: Persistent Memory', desc: 'Saves investigation node, links found indicators and evidence, and enables analyst feedback auditing.' }
            ].map((s, idx) => (
              <div key={idx} className="p-3 rounded-lg bg-slate-900/70 border border-slate-800">
                <span className="font-bold text-cyan-400 font-mono">{s.stage}</span>
                <p className="text-slate-300 text-xs mt-1 leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: Docker & Setup */}
      {activeTab === 'docker' && (
        <div className="rounded-xl border border-slate-800 bg-[#0B111E] p-5 space-y-4">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Terminal className="h-4 w-4 text-cyan-400" />
            <span>Docker & FalkorDB Setup Instructions</span>
          </h3>

          <div className="space-y-3 text-xs">
            <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 font-mono space-y-1">
              <span className="text-slate-500"># 1. Run official FalkorDB container</span>
              <div className="text-cyan-300 font-bold">docker run -p 6379:6379 -it --rm falkordb/falkordb</div>
            </div>

            <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 font-mono space-y-1">
              <span className="text-slate-500"># 2. Or run via docker-compose</span>
              <div className="text-cyan-300 font-bold">docker compose up -d</div>
            </div>

            <div className="p-3.5 rounded-lg bg-slate-950 border border-slate-800 font-mono space-y-1">
              <span className="text-slate-500"># 3. Environment Variables (.env)</span>
              <div className="text-slate-300">FALKORDB_URL="falkordb://localhost:6379"</div>
              <div className="text-slate-300">PORT=3000</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
