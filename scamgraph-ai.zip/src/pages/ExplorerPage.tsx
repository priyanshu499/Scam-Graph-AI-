import React, { useState, useMemo } from 'react';
import { Network, Search, Filter, Layers, Database, Shield, RotateCcw } from 'lucide-react';
import { NetworkGraph } from '../components/NetworkGraph';
import { GraphNodeData, GraphLinkData } from '../lib/api';

interface ExplorerPageProps {
  nodes: GraphNodeData[];
  links: GraphLinkData[];
}

export const ExplorerPage: React.FC<ExplorerPageProps> = ({ nodes, links }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('ALL');
  const [selectedNode, setSelectedNode] = useState<GraphNodeData | null>(null);

  // Filter nodes based on type and search query
  const filteredNodes = useMemo(() => {
    return nodes.filter(n => {
      const matchesType = selectedType === 'ALL' || n.type === selectedType;
      const matchesSearch =
        searchQuery === '' ||
        n.label.toLowerCase().includes(searchQuery.toLowerCase()) ||
        n.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (n.properties?.summary && n.properties.summary.toLowerCase().includes(searchQuery.toLowerCase()));

      return matchesType && matchesSearch;
    });
  }, [nodes, selectedType, searchQuery]);

  const filteredNodeIds = useMemo(() => new Set(filteredNodes.map(n => n.id)), [filteredNodes]);

  // Keep links where both source and target are in filtered nodes
  const filteredLinks = useMemo(() => {
    return links.filter(l => {
      const sourceId = typeof l.source === 'object' ? (l.source as any).id : l.source;
      const targetId = typeof l.target === 'object' ? (l.target as any).id : l.target;
      return filteredNodeIds.has(sourceId) && filteredNodeIds.has(targetId);
    });
  }, [links, filteredNodeIds]);

  return (
    <div className="p-4 sm:p-6 space-y-4 max-w-7xl mx-auto flex flex-col h-[calc(100vh-5rem)]">
      {/* Explorer Controls Bar */}
      <div className="rounded-xl border border-slate-800 bg-[#0B111E] p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <Network className="h-4 w-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white">FalkorDB Graph Evidence Explorer</h2>
            <p className="text-xs text-slate-400">
              Interactive structural knowledge visualization • Filter across categories
            </p>
          </div>
        </div>

        {/* Filter Pills and Search */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="relative">
            <Search className="h-3.5 w-3.5 text-slate-500 absolute left-2.5 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search nodes or IDs..."
              className="pl-8 pr-3 py-1.5 text-xs rounded-lg border border-slate-800 bg-slate-950 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-cyan-500 w-44"
            />
          </div>

          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
            {['ALL', 'Brand', 'Indicator', 'Incident', 'Campaign', 'Evidence'].map(t => (
              <button
                key={t}
                onClick={() => setSelectedType(t)}
                className={`px-2 py-1 rounded text-[11px] font-mono transition ${
                  selectedType === t
                    ? 'bg-cyan-500 text-slate-950 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Full-Height Graph Canvas */}
      <div className="flex-1 min-h-[460px] relative rounded-xl border border-slate-800 bg-[#070B14] overflow-hidden">
        <NetworkGraph
          nodes={filteredNodes}
          links={filteredLinks}
          onNodeClick={setSelectedNode}
          height={620}
        />
      </div>
    </div>
  );
};
