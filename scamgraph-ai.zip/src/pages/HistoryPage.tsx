import React, { useState, useMemo } from 'react';
import { History, Search, Filter, ArrowRight, ShieldAlert, CheckCircle, Clock, Calendar, UserCheck } from 'lucide-react';
import { InvestigationData } from '../lib/api';

interface HistoryPageProps {
  history: any[];
  onOpenInvestigation: (id: string) => void;
}

export const HistoryPage: React.FC<HistoryPageProps> = ({
  history,
  onOpenInvestigation
}) => {
  const [search, setSearch] = useState('');
  const [levelFilter, setLevelFilter] = useState('ALL');

  const filteredHistory = useMemo(() => {
    return history.filter(item => {
      const matchesLevel = levelFilter === 'ALL' || item.riskLevel === levelFilter;
      const matchesSearch =
        search === '' ||
        item.id.toLowerCase().includes(search.toLowerCase()) ||
        item.summary.toLowerCase().includes(search.toLowerCase()) ||
        (item.rawTextPreview && item.rawTextPreview.toLowerCase().includes(search.toLowerCase()));

      return matchesLevel && matchesSearch;
    });
  }, [history, levelFilter, search]);

  return (
    <div className="p-4 sm:p-6 space-y-5 max-w-7xl mx-auto">
      {/* Header */}
      <div className="rounded-xl border border-slate-800 bg-[#0B111E] p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-3 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <History className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white">Investigation Memory & Audit Ledger</h2>
            <p className="text-xs text-slate-400">
              Persisted investigations stored across FalkorDB knowledge nodes
            </p>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="relative">
            <Search className="h-3.5 w-3.5 text-slate-500 absolute left-2.5 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search by ID, keyword..."
              className="pl-8 pr-3 py-1.5 text-xs rounded-lg border border-slate-800 bg-slate-950 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-cyan-500 w-48"
            />
          </div>

          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
            {['ALL', 'HIGH_RISK', 'NEEDS_CAUTION', 'INSUFFICIENT_EVIDENCE'].map(lvl => (
              <button
                key={lvl}
                onClick={() => setLevelFilter(lvl)}
                className={`px-2 py-1 rounded text-[11px] font-mono transition ${
                  levelFilter === lvl
                    ? 'bg-cyan-500 text-slate-950 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {lvl === 'ALL' ? 'ALL' : lvl.replace('_', ' ')}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* History Items List */}
      {filteredHistory.length === 0 ? (
        <div className="p-12 text-center text-xs text-slate-500 border border-dashed border-slate-800 rounded-xl">
          No saved investigations found matching current filters.
        </div>
      ) : (
        <div className="space-y-3">
          {filteredHistory.map(item => (
            <div
              key={item.id}
              onClick={() => onOpenInvestigation(item.id)}
              className="p-4 rounded-xl border border-slate-800 bg-[#0B111E] hover:border-slate-700 hover:bg-slate-900/60 cursor-pointer transition flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm group"
            >
              <div className="space-y-1.5 min-w-0 max-w-2xl">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-mono text-cyan-400 font-bold text-xs">
                    {item.id}
                  </span>
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                    item.riskLevel === 'HIGH_RISK'
                      ? 'bg-red-950/60 text-red-300 border-red-800'
                      : item.riskLevel === 'NEEDS_CAUTION'
                      ? 'bg-amber-950/60 text-amber-300 border-amber-800'
                      : 'bg-slate-900 text-slate-300 border-slate-700'
                  }`}>
                    {item.riskScore}/100 • {item.riskLevel}
                  </span>
                  {item.feedback && (
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950/60 text-emerald-300 border border-emerald-800 flex items-center gap-1">
                      <UserCheck className="h-3 w-3" />
                      {item.feedback.verdict}
                    </span>
                  )}
                </div>

                <p className="text-xs text-slate-200 font-medium leading-relaxed">
                  {item.rawTextPreview || item.summary}
                </p>

                <div className="flex items-center gap-3 text-[11px] text-slate-500 font-mono pt-1">
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {new Date(item.timestamp).toLocaleString()}
                  </span>
                  <span>•</span>
                  <span>Confidence: {item.evidenceConfidence}%</span>
                  <span>•</span>
                  <span>Coverage: {item.evidenceCoverage}</span>
                </div>
              </div>

              <div className="flex items-center gap-2 text-cyan-400 group-hover:text-cyan-300 font-medium text-xs shrink-0">
                <span>Reopen Dossier</span>
                <ArrowRight className="h-4 w-4 transform group-hover:translate-x-1 transition" />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
