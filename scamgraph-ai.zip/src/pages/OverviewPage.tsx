import React from 'react';
import {
  ShieldAlert,
  Database,
  Network,
  Activity,
  Layers,
  ArrowRight,
  TrendingUp,
  AlertTriangle,
  History,
  FileCheck,
  CheckCircle2,
  ExternalLink
} from 'lucide-react';
import { GraphOverviewStats, FalkorStatus, InvestigationData } from '../lib/api';

interface OverviewPageProps {
  stats: GraphOverviewStats | null;
  falkorStatus: FalkorStatus | null;
  recentInvestigations: any[];
  onStartInvestigation: () => void;
  onOpenInvestigation: (id: string) => void;
}

export const OverviewPage: React.FC<OverviewPageProps> = ({
  stats,
  falkorStatus,
  recentInvestigations,
  onStartInvestigation,
  onOpenInvestigation
}) => {
  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Hero Banner / Command Center Header */}
      <div className="rounded-2xl border border-slate-800 bg-gradient-to-br from-[#0B111E] via-[#0F172A] to-[#070B14] p-6 shadow-xl relative overflow-hidden">
        <div className="relative z-10 max-w-2xl space-y-3">
          <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-mono">
            <span className="h-2 w-2 rounded-full bg-cyan-400 animate-pulse" />
            FalkorDB Graph Intelligence Engine Online
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
            Investigate the network. Expose the pattern. Explain every decision.
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Conventional tools inspect isolated keywords in scam messages. ScamGraph AI traverses FalkorDB's multi-hop knowledge graph to uncover shared DNS hosts, TLS certificates, VoIP trunks, and multi-incident syndicates.
          </p>
          <div className="pt-2 flex items-center gap-3">
            <button
              onClick={onStartInvestigation}
              className="text-xs font-semibold px-4 py-2 rounded-lg bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-950 shadow-md shadow-cyan-950 flex items-center gap-2 transition"
            >
              <ShieldAlert className="h-4 w-4" />
              <span>Launch Investigation</span>
            </button>
            <span className="text-xs text-slate-400">
              {stats?.incidentCount || 14} cataloged incidents in knowledge store
            </span>
          </div>
        </div>

        {/* Decorative background grid pattern */}
        <div className="absolute right-0 top-0 bottom-0 w-1/3 opacity-10 pointer-events-none bg-[radial-gradient(#2DD4BF_1px,transparent_1px)] [background-size:16px_16px]" />
      </div>

      {/* Real FalkorDB Telemetry Stat Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        {[
          { label: 'Graph Nodes', value: stats?.nodeCount || 52, icon: Database, color: 'text-cyan-400' },
          { label: 'Relationships', value: stats?.edgeCount || 68, icon: Network, color: 'text-teal-400' },
          { label: 'Synthetic Incidents', value: stats?.incidentCount || 14, icon: ShieldAlert, color: 'text-amber-400' },
          { label: 'Active Campaigns', value: stats?.campaignCount || 4, icon: Layers, color: 'text-purple-400' },
          { label: 'Threat Indicators', value: stats?.indicatorCount || 19, icon: Activity, color: 'text-rose-400' },
          { label: 'Saved Investigations', value: stats?.investigationCount || recentInvestigations.length, icon: History, color: 'text-emerald-400' }
        ].map((card, idx) => {
          const Icon = card.icon;
          return (
            <div
              key={idx}
              className="rounded-xl border border-slate-800 bg-[#0B111E] p-3.5 flex flex-col justify-between shadow-sm"
            >
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-[11px] font-medium truncate">{card.label}</span>
                <Icon className={`h-4 w-4 ${card.color}`} />
              </div>
              <div className="text-2xl font-black font-mono text-white">
                {card.value}
              </div>
            </div>
          );
        })}
      </div>

      {/* 2-Column Split: Active Campaign Clusters & Recent Investigations */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Active Campaigns in FalkorDB (7 cols) */}
        <div className="lg:col-span-7 rounded-xl border border-slate-800 bg-[#0B111E] p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Layers className="h-4 w-4 text-purple-400" />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                Cataloged Fraud Campaigns in FalkorDB
              </h3>
            </div>
            <span className="text-xs font-mono text-slate-400">
              {stats?.activeCampaigns.length || 3} Active Syndicates
            </span>
          </div>

          <div className="space-y-3">
            {[
              {
                id: 'camp-phish-fin-01',
                title: 'Northstar Credential Harvest Ring',
                category: 'Banking Phishing Syndicate',
                status: 'ACTIVE',
                incidents: 5,
                infrastructure: 'Shared nameserver ns1.bulletproof-dns.test & IP 198.51.100.44',
                color: 'border-red-800/60 bg-red-950/20'
              },
              {
                id: 'camp-courier-04',
                title: 'SwiftDrop Redelivery Fee Syndicate',
                category: 'Courier Fee Extortion & Card Skimming',
                status: 'ACTIVE',
                incidents: 4,
                infrastructure: 'Wildcard TLS cert cert-sha256:77ba91... linking to Northstar',
                color: 'border-amber-800/60 bg-amber-950/20'
              },
              {
                id: 'camp-work-job-09',
                title: 'Apex Remote Task Deposit Ring',
                category: 'Job Advance-Fee & Crypto Thefts',
                status: 'ACTIVE',
                incidents: 4,
                infrastructure: 'USDT staging wallet 0x9f82...a8e2 & disposable recruiter VoIP',
                color: 'border-purple-800/60 bg-purple-950/20'
              }
            ].map(c => (
              <div
                key={c.id}
                className={`p-3.5 rounded-lg border ${c.color} text-xs space-y-1.5`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-200">{c.title}</span>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-900 text-emerald-400 border border-emerald-800/50">
                    {c.status}
                  </span>
                </div>
                <div className="text-[11px] text-slate-400">{c.category}</div>
                <div className="text-[10px] font-mono text-slate-500 flex items-center justify-between pt-1">
                  <span>Pivot Infrastructure: <span className="text-cyan-400">{c.infrastructure}</span></span>
                  <span className="text-slate-300 font-bold">{c.incidents} Incidents</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Investigations History (5 cols) */}
        <div className="lg:col-span-5 rounded-xl border border-slate-800 bg-[#0B111E] p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <History className="h-4 w-4 text-cyan-400" />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                Recent Investigations
              </h3>
            </div>
            <span className="text-xs text-slate-500 font-mono">
              FalkorDB Memory
            </span>
          </div>

          {recentInvestigations.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-500 border border-dashed border-slate-800 rounded-lg">
              No investigations recorded yet. Click "Launch Investigation" above to analyze a scenario.
            </div>
          ) : (
            <div className="space-y-2">
              {recentInvestigations.slice(0, 5).map(inv => (
                <div
                  key={inv.id}
                  onClick={() => onOpenInvestigation(inv.id)}
                  className="p-3 rounded-lg bg-slate-900/60 hover:bg-slate-900 border border-slate-800 cursor-pointer transition flex items-center justify-between gap-3 text-xs"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-mono text-cyan-400 font-semibold">{inv.id}</span>
                      <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
                        inv.riskLevel === 'HIGH_RISK'
                          ? 'bg-red-950 text-red-300 border border-red-800'
                          : inv.riskLevel === 'NEEDS_CAUTION'
                          ? 'bg-amber-950 text-amber-300 border border-amber-800'
                          : 'bg-slate-800 text-slate-300 border border-slate-700'
                      }`}>
                        {inv.riskScore}/100
                      </span>
                    </div>
                    <p className="text-slate-400 text-[11px] truncate">
                      {inv.rawTextPreview || inv.summary}
                    </p>
                  </div>
                  <ArrowRight className="h-3.5 w-3.5 text-slate-500 shrink-0" />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
