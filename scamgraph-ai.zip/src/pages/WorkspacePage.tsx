import React, { useState } from 'react';
import {
  ShieldAlert,
  Search,
  Sparkles,
  ArrowRight,
  RotateCcw,
  Sliders,
  ExternalLink,
  Layers,
  HelpCircle,
  AlertCircle
} from 'lucide-react';
import { NetworkGraph } from '../components/NetworkGraph';
import { RiskAssessmentCard } from '../components/RiskAssessmentCard';
import { ExplainabilityTrail } from '../components/ExplainabilityTrail';
import { ReportViewer } from '../components/ReportViewer';
import { AnalystFeedbackWidget } from '../components/AnalystFeedbackWidget';
import { AgentPipelineTracker } from '../components/AgentPipelineTracker';
import { InvestigationData, api } from '../lib/api';

interface WorkspacePageProps {
  currentInvestigation: InvestigationData | null;
  onInvestigationComplete: (data: InvestigationData) => void;
  isLoading: boolean;
  setIsLoading: (val: boolean) => void;
}

export const WorkspacePage: React.FC<WorkspacePageProps> = ({
  currentInvestigation,
  onInvestigationComplete,
  isLoading,
  setIsLoading
}) => {
  const [inputText, setInputText] = useState(
    'URGENT: Northstar Bank says my account will be suspended in 24 hours unless I verify my identity at northstar-verify.test. Call +1-800-555-0199 if questions.'
  );
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [highlightedNodes, setHighlightedNodes] = useState<string[]>([]);
  const [selectedPathIdx, setSelectedPathIdx] = useState<number | null>(null);

  // Counterfactual simulation state
  const [simulatedScore, setSimulatedScore] = useState<number | null>(null);
  const [excludedRuleIds, setExcludedRuleIds] = useState<string[]>([]);

  // Demo scenarios quick pills
  const SCENARIO_PILLS = [
    {
      label: '💳 Northstar Bank Phish',
      text: 'URGENT: Northstar Bank says my account will be suspended in 24 hours unless I verify my identity at northstar-verify.test. Call +1-800-555-0199 if questions.'
    },
    {
      label: '📦 SwiftDrop Courier Scam',
      text: 'SwiftDrop Logistics: Your package parcel-9842 is detained at customs. Pay pending $2.85 handling fee immediately at swiftdrop-pay.test or send to $swiftdrop-release to avoid return.'
    },
    {
      label: '💼 Apex Career Wire Fraud',
      text: 'Congratulations! You have been accepted for the remote Data Analyst role at Apex Global Careers. Please complete onboarding and deposit your $350 training kit bond to 0x9f82c40134d4a8e2 or $apexcareers_hr at apex-career-fee.test.'
    },
    {
      label: '❓ Unknown Domain (Insufficient Data)',
      text: 'Please review your quarterly corporate dashboard invoice at unknown-vendor-portal.test or submit support queries to support@unknown-vendor-portal.test.'
    }
  ];

  const handleRunInvestigation = async (overrideText?: string) => {
    const textToAnalyze = overrideText || inputText;
    if (!textToAnalyze.trim()) {
      setErrorMsg('Please enter a suspicious message, indicator, domain, or phone number to analyze.');
      return;
    }

    setErrorMsg(null);
    setIsLoading(true);
    setHighlightedNodes([]);
    setSelectedPathIdx(null);
    setSimulatedScore(null);
    setExcludedRuleIds([]);

    try {
      const res = await api.runInvestigation(textToAnalyze.trim());
      if (res.success && res.investigation) {
        onInvestigationComplete(res.investigation);
      } else {
        setErrorMsg(res.error || 'Failed to complete investigation.');
      }
    } catch (err: any) {
      setErrorMsg(err?.message || 'Network error executing investigation.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectScenario = (text: string) => {
    setInputText(text);
    handleRunInvestigation(text);
  };

  const handleSelectPath = (nodeIds: string[]) => {
    setHighlightedNodes(nodeIds);
  };

  // Counterfactual rule toggling
  const handleToggleRule = async (ruleId: string) => {
    if (!currentInvestigation) return;
    const nextExcluded = excludedRuleIds.includes(ruleId)
      ? excludedRuleIds.filter(id => id !== ruleId)
      : [...excludedRuleIds, ruleId];

    setExcludedRuleIds(nextExcluded);

    try {
      const simRes = await api.simulateCounterfactual(
        currentInvestigation.input,
        currentInvestigation.extraction.indicators.map(i => i.value),
        nextExcluded
      );
      if (simRes.success && simRes.assessment) {
        setSimulatedScore(simRes.assessment.riskScore);
      }
    } catch (err) {
      console.error('Counterfactual simulation failed:', err);
    }
  };

  const handleResetSimulation = () => {
    setExcludedRuleIds([]);
    setSimulatedScore(null);
  };

  return (
    <div className="p-4 sm:p-6 space-y-5 max-w-7xl mx-auto">
      {/* Input Console */}
      <div className="rounded-xl border border-slate-800 bg-[#0B111E] p-4 sm:p-5 shadow-sm space-y-4">
        <div>
          <h2 className="text-sm font-bold tracking-tight text-white flex items-center gap-2">
            <Search className="h-4 w-4 text-cyan-400" />
            <span>Investigate Suspicious Message or Indicator</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Traverse the connected FalkorDB threat graph to discover shared infrastructure, brand impersonation, and multi-hop attack trails.
          </p>
        </div>

        {/* Input Text Area */}
        <div className="relative">
          <textarea
            value={inputText}
            onChange={e => setInputText(e.target.value)}
            placeholder="Paste a suspicious SMS, email excerpt, phishing URL, payment cashtag, or domain..."
            rows={3}
            className="w-full text-xs sm:text-sm font-mono rounded-lg border border-slate-800 bg-slate-950 p-3 text-slate-100 placeholder-slate-600 focus:outline-none focus:border-cyan-500 shadow-inner"
          />
        </div>

        {/* Scenario Pills & Submit Button */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-[11px] text-slate-500 font-medium mr-1">Demo Scenarios:</span>
            {SCENARIO_PILLS.map((p, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSelectScenario(p.text)}
                className="text-[11px] px-2.5 py-1 rounded-md bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 transition truncate max-w-[220px]"
                title={p.text}
              >
                {p.label}
              </button>
            ))}
          </div>

          <button
            onClick={() => handleRunInvestigation()}
            disabled={isLoading}
            className="text-xs font-semibold px-5 py-2.5 rounded-lg bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-950 shadow-md shadow-cyan-950 flex items-center justify-center gap-2 transition disabled:opacity-50 shrink-0"
          >
            <ShieldAlert className="h-4 w-4" />
            <span>{isLoading ? 'Traversing Graph...' : 'Execute Investigation'}</span>
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-lg bg-red-950/40 border border-red-800/80 text-xs text-red-300 flex items-center gap-2">
            <AlertCircle className="h-4 w-4 shrink-0 text-red-400" />
            <span>{errorMsg}</span>
          </div>
        )}
      </div>

      {/* Agent Pipeline Progress Tracker */}
      {currentInvestigation && (
        <AgentPipelineTracker
          logs={currentInvestigation.executionLogs}
          isLoading={isLoading}
        />
      )}

      {/* Main 2-Column Investigation Results */}
      {currentInvestigation && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
          {/* Left Column: Interactive Graph & Multi-Hop Paths (7 cols) */}
          <div className="lg:col-span-7 space-y-5">
            {/* Interactive Force Graph */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
                  <Layers className="h-3.5 w-3.5 text-cyan-400" />
                  <span>Interactive FalkorDB Graph Evidence</span>
                </h3>
                <span className="text-[11px] text-slate-500">
                  {currentInvestigation.graphVisualization.nodes.length} nodes • Drag to arrange • Scroll to zoom
                </span>
              </div>

              <NetworkGraph
                nodes={currentInvestigation.graphVisualization.nodes}
                links={currentInvestigation.graphVisualization.links}
                highlightedPathNodeIds={highlightedNodes}
                height={440}
              />
            </div>

            {/* Explainability Trail */}
            <ExplainabilityTrail
              paths={currentInvestigation.evidencePaths}
              onSelectPath={handleSelectPath}
              selectedPathIndex={selectedPathIdx}
            />

            {/* Structured Report & Recommendations */}
            <ReportViewer investigation={currentInvestigation} />
          </div>

          {/* Right Column: Risk Assessment, Counterfactual Explorer & Feedback (5 cols) */}
          <div className="lg:col-span-5 space-y-5">
            {/* Risk Assessment Card with Counterfactual Simulator */}
            <RiskAssessmentCard
              assessment={currentInvestigation.assessment}
              simulatedScore={simulatedScore}
              excludedRules={excludedRuleIds}
              onToggleRule={handleToggleRule}
              onResetSimulation={handleResetSimulation}
            />

            {/* Extracted Indicators Summary Box */}
            <div className="rounded-xl border border-slate-800 bg-[#0B111E] p-4 space-y-3">
              <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wide">
                Extracted Indicator Inventory
              </h4>
              <div className="space-y-2 text-xs">
                {(currentInvestigation.extraction?.indicators || []).map((ind, i) => (
                  <div
                    key={i}
                    className="p-2 rounded bg-slate-900 border border-slate-800 flex items-center justify-between"
                  >
                    <div className="font-mono text-cyan-300 truncate max-w-[240px]">
                      {ind.value}
                    </div>
                    <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-950 text-slate-400 border border-slate-800">
                      {ind.type}
                    </span>
                  </div>
                ))}
                {currentInvestigation.extraction?.claimedBrands && currentInvestigation.extraction.claimedBrands.length > 0 && (
                  <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400 flex items-center gap-1.5">
                    <span className="text-slate-500">Claimed Brand:</span>
                    <span className="text-sky-400 font-semibold">
                      {currentInvestigation.extraction.claimedBrands.join(', ')}
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Connected Campaign Discovery Box */}
            {currentInvestigation.connectedCampaigns && currentInvestigation.connectedCampaigns.length > 0 && (
              <div className="rounded-xl border border-slate-800 bg-[#0B111E] p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wide">
                    Attributed Campaign Syndicates
                  </h4>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800">
                    {currentInvestigation.connectedCampaigns.length} Campaign(s)
                  </span>
                </div>

                <div className="space-y-2">
                  {currentInvestigation.connectedCampaigns.map((cc, i) => (
                    <div key={i} className="p-3 rounded-lg bg-slate-900/60 border border-slate-800 text-xs space-y-1">
                      <div className="font-semibold text-purple-300">
                        {cc.campaign.properties?.label}
                      </div>
                      <p className="text-[11px] text-slate-400">
                        {cc.campaign.properties?.description}
                      </p>
                      <div className="text-[10px] font-mono text-slate-500 pt-1">
                        Linked Incidents: <span className="text-slate-200">{cc.incidentCount}</span>
                        {cc.sharedInfrastructure.length > 0 && (
                          <span> • Shared Infra: <span className="text-cyan-400">{cc.sharedInfrastructure.join(', ')}</span></span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Analyst Feedback Widget */}
            <AnalystFeedbackWidget
              investigationId={currentInvestigation.investigationId}
              initialFeedback={currentInvestigation.feedback}
            />
          </div>
        </div>
      )}
    </div>
  );
};
