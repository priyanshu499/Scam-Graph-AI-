import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Sidebar, NavTab } from './components/Sidebar';
import { FalkorSetupModal } from './components/FalkorSetupModal';
import { WorkspacePage } from './pages/WorkspacePage';
import { OverviewPage } from './pages/OverviewPage';
import { ExplorerPage } from './pages/ExplorerPage';
import { HistoryPage } from './pages/HistoryPage';
import { DemoLabPage } from './pages/DemoLabPage';
import { ArchitecturePage } from './pages/ArchitecturePage';
import { api, FalkorStatus, GraphOverviewStats, InvestigationData, GraphNodeData, GraphLinkData } from './lib/api';

export function App() {
  const [currentTab, setCurrentTab] = useState<NavTab>('overview');
  const [falkorStatus, setFalkorStatus] = useState<FalkorStatus | null>(null);
  const [stats, setStats] = useState<GraphOverviewStats | null>(null);
  const [investigations, setInvestigations] = useState<any[]>([]);
  const [currentInvestigation, setCurrentInvestigation] = useState<InvestigationData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSeeding, setIsSeeding] = useState(false);
  const [isSetupModalOpen, setIsSetupModalOpen] = useState(false);

  // Load telemetry, history, and initial state on mount
  useEffect(() => {
    loadOverviewData();
  }, []);

  const loadOverviewData = async () => {
    try {
      const overviewRes = await api.getGraphOverview();
      if (overviewRes.success) {
        setStats(overviewRes.stats);
        setFalkorStatus(overviewRes.falkordb);
      }

      const historyRes = await api.getInvestigations();
      if (historyRes.success) {
        setInvestigations(historyRes.history);
      }

      // Check URL query parameters: if ?autostart=1 or no investigation loaded yet, auto-run Northstar demo
      const urlParams = new URLSearchParams(window.location.search);
      const autostart = urlParams.get('autostart');
      if (autostart === '1' || historyRes.history.length === 0) {
        const initialRes = await api.runInvestigation(
          'URGENT: Northstar Bank says my account will be suspended in 24 hours unless I verify my identity at northstar-verify.test. Call +1-800-555-0199 if questions.'
        );
        if (initialRes.success && initialRes.investigation) {
          setCurrentInvestigation(initialRes.investigation);
          if (autostart === '1') {
            setCurrentTab('workspace');
          }
        }
      } else if (historyRes.history.length > 0) {
        // Load latest saved investigation
        const latestId = historyRes.history[0].id;
        const invRes = await api.getInvestigation(latestId);
        if (invRes.success && invRes.investigation) {
          setCurrentInvestigation(invRes.investigation);
        }
      }
    } catch (err) {
      console.error('Initialization error:', err);
    }
  };

  const handleSeedGraph = async () => {
    setIsSeeding(true);
    try {
      const res = await api.seedGraph();
      if (res.success && res.stats) {
        setStats(res.stats);
        await loadOverviewData();
      }
    } catch (err) {
      console.error('Seeding error:', err);
    } finally {
      setIsSeeding(false);
    }
  };

  const handleInvestigationComplete = (data: InvestigationData) => {
    setCurrentInvestigation(data);
    loadOverviewData();
  };

  const handleOpenInvestigation = async (id: string) => {
    setIsLoading(true);
    try {
      const res = await api.getInvestigation(id);
      if (res.success && res.investigation) {
        setCurrentInvestigation(res.investigation);
        setCurrentTab('workspace');
      }
    } catch (err) {
      console.error('Error reopening investigation:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRunDemoScenario = (text: string) => {
    setCurrentTab('workspace');
    setIsLoading(true);
    api.runInvestigation(text).then(res => {
      if (res.success && res.investigation) {
        setCurrentInvestigation(res.investigation);
      }
    }).finally(() => {
      setIsLoading(false);
    });
  };

  // Prepare full-graph nodes and links for Explorer view
  const explorerGraphData = React.useMemo(() => {
    const vis = currentInvestigation?.graphVisualization || (currentInvestigation as any)?.graphSnapshot;
    if (vis && Array.isArray(vis.nodes) && vis.nodes.length > 0) {
      return vis;
    }
    return { nodes: [], links: [] };
  }, [currentInvestigation]);

  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#070B14] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Top Navbar */}
      <Navbar
        falkorStatus={falkorStatus}
        stats={stats}
        onOpenSetup={() => setIsSetupModalOpen(true)}
        onSeedGraph={handleSeedGraph}
        onNewInvestigation={() => {
          setCurrentTab('workspace');
          setIsMobileSidebarOpen(false);
        }}
        isSeeding={isSeeding}
        onToggleMobileMenu={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
        isMobileMenuOpen={isMobileSidebarOpen}
      />

      {/* Main Body with Left Sidebar */}
      <div className="flex-1 flex overflow-x-hidden relative">
        {/* Left Navigation Sidebar */}
        <Sidebar
          currentTab={currentTab}
          onSelectTab={tab => {
            setCurrentTab(tab);
            setIsMobileSidebarOpen(false);
          }}
          investigationCount={investigations.length}
          isOpenOnMobile={isMobileSidebarOpen}
          onCloseMobile={() => setIsMobileSidebarOpen(false)}
        />

        {/* Primary Page Canvas */}
        <main className="flex-1 overflow-y-auto min-w-0 pb-12">
          {currentTab === 'overview' && (
            <OverviewPage
              stats={stats}
              falkorStatus={falkorStatus}
              recentInvestigations={investigations}
              onStartInvestigation={() => setCurrentTab('workspace')}
              onOpenInvestigation={handleOpenInvestigation}
            />
          )}

          {currentTab === 'workspace' && (
            <WorkspacePage
              currentInvestigation={currentInvestigation}
              onInvestigationComplete={handleInvestigationComplete}
              isLoading={isLoading}
              setIsLoading={setIsLoading}
            />
          )}

          {currentTab === 'explorer' && (
            <ExplorerPage
              nodes={explorerGraphData.nodes}
              links={explorerGraphData.links}
            />
          )}

          {currentTab === 'history' && (
            <HistoryPage
              history={investigations}
              onOpenInvestigation={handleOpenInvestigation}
            />
          )}

          {currentTab === 'demolab' && (
            <DemoLabPage onRunScenario={handleRunDemoScenario} />
          )}

          {currentTab === 'architecture' && <ArchitecturePage />}
        </main>
      </div>

      {/* FalkorDB Connection & Docker Setup Modal */}
      <FalkorSetupModal
        isOpen={isSetupModalOpen}
        onClose={() => setIsSetupModalOpen(false)}
        status={falkorStatus}
        onStatusUpdated={setFalkorStatus}
      />
    </div>
  );
}

export default App;
