export interface GraphNodeData {
  id: string;
  label: string;
  type: 'Brand' | 'Indicator' | 'Incident' | 'Campaign' | 'Evidence' | 'Unknown';
  properties: Record<string, any>;
  val: number;
  color: string;
}

export interface GraphLinkData {
  source: string;
  target: string;
  label: string;
  properties: Record<string, any>;
  color?: string;
}

export interface InvestigationData {
  investigationId: string;
  timestamp: string;
  input: string;
  extraction: {
    indicators: Array<{ value: string; type: string; rawText: string; confidence: number }>;
    claimedBrands: string[];
    urgencySignals: Array<{ category: string; matchedPhrase: string; weight: number }>;
    hasUrgentRequest: boolean;
    hasCredentialRequest: boolean;
    hasPaymentRequest: boolean;
    rawInputDigest: string;
  };
  assessment: {
    riskScore: number;
    riskLevel: 'HIGH_RISK' | 'NEEDS_CAUTION' | 'LOW_RISK' | 'INSUFFICIENT_EVIDENCE';
    riskLabel: string;
    evidenceConfidence: number;
    evidenceCoverage: 'HIGH' | 'MODERATE' | 'LOW' | 'INSUFFICIENT';
    rules: Array<{
      ruleId: string;
      name: string;
      description: string;
      points: number;
      maxPoints: number;
      applied: boolean;
      reason: string;
      evidenceIds: string[];
    }>;
    explanation: string;
    disclaimer: string;
  };
  report: {
    investigationId: string;
    timestamp: string;
    executiveSummary: string;
    riskAssessmentExplanation: string;
    matchedIndicators: string[];
    findings: Array<{
      id: string;
      title: string;
      description: string;
      evidenceIds: string[];
      severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';
    }>;
    connectedIncidentSummaries: string[];
    relationshipPathExplanations: string[];
    uncertaintiesAndLimitations: string[];
    recommendedNextSteps: string[];
    syntheticDisclaimer: string;
  };
  evidencePaths: Array<{
    nodes: any[];
    edges: any[];
    summary: string;
  }>;
  graphVisualization: {
    nodes: GraphNodeData[];
    links: GraphLinkData[];
  };
  connectedCampaigns: Array<{
    campaign: any;
    incidentCount: number;
    indicators: any[];
    sharedInfrastructure: string[];
  }>;
  executionLogs: Array<{
    step: string;
    title: string;
    durationMs: number;
    details: string;
    dataSummary: Record<string, any>;
  }>;
  metrics: {
    totalDurationMs: number;
    graphQueriesExecuted: number;
    nodesTraversed: number;
    relationshipsDiscovered: number;
  };
  feedback?: {
    verdict: 'CONFIRMED_FRAUD' | 'NEEDS_REVIEW' | 'FALSE_POSITIVE';
    note?: string;
    timestamp: string;
  };
}

export interface GraphOverviewStats {
  nodeCount: number;
  edgeCount: number;
  indicatorCount: number;
  incidentCount: number;
  campaignCount: number;
  evidenceCount: number;
  brandCount: number;
  investigationCount: number;
  feedbackCount: number;
  activeCampaigns: string[];
  isLiveDb: boolean;
}

export interface FalkorStatus {
  connected: boolean;
  mode: 'falkordb_live' | 'falkordb_standalone';
  url: string;
  graphName: string;
  lastChecked: string;
  errorMessage?: string;
  nodeCount: number;
  edgeCount: number;
}

export const api = {
  async getHealth() {
    const res = await fetch('/api/health');
    return res.json();
  },

  async getGraphOverview(): Promise<{ success: boolean; stats: GraphOverviewStats; falkordb: FalkorStatus }> {
    const res = await fetch('/api/graph/overview');
    return res.json();
  },

  async runInvestigation(text: string): Promise<{ success: boolean; investigation?: InvestigationData; error?: string }> {
    const res = await fetch('/api/investigations/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text })
    });
    return res.json();
  },

  async getInvestigations(): Promise<{ success: boolean; history: any[]; total: number }> {
    const res = await fetch('/api/investigations');
    return res.json();
  },

  async getInvestigation(id: string): Promise<{ success: boolean; investigation: any }> {
    const res = await fetch(`/api/investigations/${id}`);
    return res.json();
  },

  async submitFeedback(id: string, verdict: string, note?: string) {
    const res = await fetch(`/api/investigations/${id}/feedback`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ verdict, note })
    });
    return res.json();
  },

  async getDemoScenarios() {
    const res = await fetch('/api/demo/scenarios');
    return res.json();
  },

  async simulateCounterfactual(rawText: string, matchedIndicatorIds: string[], excludedRuleIds: string[]) {
    const res = await fetch('/api/counterfactual/simulate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rawText, matchedIndicatorIds, excludedRuleIds })
    });
    return res.json();
  },

  async testConnection(url?: string) {
    const res = await fetch('/api/graph/test-connection', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url })
    });
    return res.json();
  },

  async seedGraph() {
    const res = await fetch('/api/graph/seed', { method: 'POST' });
    return res.json();
  }
};
