import React, { useState } from 'react';
import { UserCheck, CheckCircle, AlertCircle, HelpCircle, Save, Loader2 } from 'lucide-react';
import { api } from '../lib/api';

interface AnalystFeedbackWidgetProps {
  investigationId: string;
  initialFeedback?: {
    verdict: 'CONFIRMED_FRAUD' | 'NEEDS_REVIEW' | 'FALSE_POSITIVE';
    note?: string;
    timestamp: string;
  };
  onFeedbackSaved?: (feedback: any) => void;
}

export const AnalystFeedbackWidget: React.FC<AnalystFeedbackWidgetProps> = ({
  investigationId,
  initialFeedback,
  onFeedbackSaved
}) => {
  const [verdict, setVerdict] = useState<'CONFIRMED_FRAUD' | 'NEEDS_REVIEW' | 'FALSE_POSITIVE'>(
    initialFeedback?.verdict || 'CONFIRMED_FRAUD'
  );
  const [note, setNote] = useState(initialFeedback?.note || '');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(Boolean(initialFeedback));
  const [feedbackRecord, setFeedbackRecord] = useState(initialFeedback);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const res = await api.submitFeedback(investigationId, verdict, note);
      if (res.success) {
        setSavedSuccess(true);
        setFeedbackRecord(res.feedback);
        if (onFeedbackSaved) onFeedbackSaved(res.feedback);
      }
    } catch (err) {
      console.error('Failed to submit feedback:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="rounded-xl border border-slate-800 bg-[#0B111E] p-4 flex flex-col gap-3">
      <div className="flex items-center justify-between pb-2 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <UserCheck className="h-4 w-4 text-cyan-400" />
          <h4 className="text-xs font-semibold text-slate-200">
            Analyst Review & Verification Loop
          </h4>
        </div>
        {savedSuccess && (
          <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
            <CheckCircle className="h-3 w-3" />
            Saved to FalkorDB
          </span>
        )}
      </div>

      <p className="text-[11px] text-slate-400">
        Record human analyst validation to establish audit trail in FalkorDB. Feedback is attributed as an analyst review node, not automated ground truth.
      </p>

      <form onSubmit={handleSubmit} className="space-y-3">
        {/* Verdict Pills */}
        <div className="grid grid-cols-3 gap-2">
          {[
            { id: 'CONFIRMED_FRAUD', label: 'Confirmed Fraud', color: 'border-red-700 text-red-400 bg-red-950/40' },
            { id: 'NEEDS_REVIEW', label: 'Needs Review', color: 'border-amber-700 text-amber-400 bg-amber-950/40' },
            { id: 'FALSE_POSITIVE', label: 'False Positive', color: 'border-emerald-700 text-emerald-400 bg-emerald-950/40' }
          ].map(opt => (
            <button
              key={opt.id}
              type="button"
              onClick={() => setVerdict(opt.id as any)}
              className={`p-2 rounded-lg border text-xs font-medium transition text-center ${
                verdict === opt.id
                  ? opt.color + ' ring-1 ring-cyan-500'
                  : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>

        {/* Note Input */}
        <div>
          <textarea
            value={note}
            onChange={e => setNote(e.target.value)}
            placeholder="Add analyst observations (e.g. verified with bank SOC, cloned credential template match...)"
            rows={2}
            className="w-full text-xs rounded-lg border border-slate-800 bg-slate-950 p-2 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-cyan-500"
          />
        </div>

        <div className="flex items-center justify-between">
          <span className="text-[10px] text-slate-500">
            {feedbackRecord?.timestamp && `Last reviewed: ${new Date(feedbackRecord.timestamp).toLocaleTimeString()}`}
          </span>
          <button
            type="submit"
            disabled={isSubmitting}
            className="text-xs px-3.5 py-1.5 rounded-md bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold flex items-center gap-1.5 transition disabled:opacity-50"
          >
            {isSubmitting ? <Loader2 className="h-3 w-3 animate-spin" /> : <Save className="h-3 w-3" />}
            <span>Persist Feedback</span>
          </button>
        </div>
      </form>
    </div>
  );
};
