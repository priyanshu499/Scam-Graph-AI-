import React from 'react';
import { GitCommit, ArrowRight, Shield, AlertTriangle, Layers, FileCheck } from 'lucide-react';

interface ExplainabilityTrailProps {
  paths: Array<{
    nodes: any[];
    edges: any[];
    summary: string;
  }>;
  onSelectPath?: (nodeIds: string[]) => void;
  selectedPathIndex?: number | null;
}

export const ExplainabilityTrail: React.FC<ExplainabilityTrailProps> = ({
  paths,
  onSelectPath,
  selectedPathIndex
}) => {
  if (paths.length === 0) {
    return (
      <div className="rounded-xl border border-slate-800 bg-[#0B111E] p-4 text-center">
        <p className="text-xs text-slate-500">
          No multi-hop connection paths discovered in FalkorDB knowledge graph.
        </p>
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-slate-800 bg-[#0B111E] p-4 flex flex-col gap-3">
      <div className="flex items-center justify-between pb-2 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <GitCommit className="h-4 w-4 text-cyan-400" />
          <h3 className="text-xs font-semibold text-slate-200">
            Multi-Hop Explainability Trails ({paths.length} Paths)
          </h3>
        </div>
        <span className="text-[10px] text-slate-500">Click path to highlight on graph</span>
      </div>

      <div className="space-y-2.5">
        {paths.map((p, idx) => {
          const isSelected = selectedPathIndex === idx;
          const nodeIds = p.nodes.map(n => n.id);

          return (
            <div
              key={idx}
              onClick={() => onSelectPath && onSelectPath(nodeIds)}
              className={`p-3 rounded-lg border cursor-pointer transition ${
                isSelected
                  ? 'bg-cyan-950/40 border-cyan-500/60 shadow-sm'
                  : 'bg-slate-900/60 border-slate-800/80 hover:bg-slate-900 hover:border-slate-700'
              }`}
            >
              {/* Visual Breadcrumb Steps */}
              <div className="flex items-center gap-1.5 flex-wrap mb-2">
                {p.nodes.map((node, nIdx) => {
                  const label = node.properties?.displayValue ||
                    node.properties?.name ||
                    node.properties?.label ||
                    node.properties?.summary ||
                    node.id;

                  const isLast = nIdx === p.nodes.length - 1;
                  const edge = p.edges[nIdx];

                  return (
                    <React.Fragment key={node.id}>
                      <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-200 flex items-center gap-1">
                        <span className="text-slate-500 text-[10px]">
                          {node.labels?.[0] || 'Node'}:
                        </span>
                        <span className="font-semibold text-cyan-300 truncate max-w-[140px]">
                          {typeof label === 'string' && label.length > 20 ? label.substring(0, 18) + '...' : label}
                        </span>
                      </span>

                      {!isLast && (
                        <div className="flex items-center gap-1 text-[10px] font-mono text-slate-500">
                          <ArrowRight className="h-3 w-3 text-cyan-500/60" />
                          {edge && (
                            <span className="text-slate-400 text-[9px] uppercase px-1 py-0.2 bg-slate-900 rounded">
                              {edge.relType}
                            </span>
                          )}
                        </div>
                      )}
                    </React.Fragment>
                  );
                })}
              </div>

              {/* Natural language summary */}
              <p className="text-xs text-slate-300 leading-relaxed font-sans">
                {p.summary}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
};
