import React, { useState } from 'react';
import { Download, FileText, CheckCircle, ShieldAlert, AlertTriangle, ExternalLink, Copy, Check } from 'lucide-react';
import { InvestigationData } from '../lib/api';

interface ReportViewerProps {
  investigation: InvestigationData;
}

export const ReportViewer: React.FC<ReportViewerProps> = ({ investigation }) => {
  const [copied, setCopied] = useState(false);
  const { report, assessment, extraction } = investigation;

  const handleDownloadJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(investigation, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `scamgraph-investigation-${investigation.investigationId}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleDownloadMarkdown = () => {
    window.location.href = `/api/reports/${investigation.investigationId}?format=markdown`;
  };

  const handleCopySummary = () => {
    navigator.clipboard.writeText(
      `ScamGraph AI Investigation Dossier [${investigation.investigationId}]\nRisk Score: ${assessment.riskScore}/100 (${assessment.riskLevel})\nSummary: ${report.executiveSummary}\nConfidence: ${assessment.evidenceConfidence}%`
    );
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="rounded-xl border border-slate-800 bg-[#0B111E] p-4 sm:p-6 flex flex-col gap-5">
      {/* Report Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <FileText className="h-4 w-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white tracking-wide uppercase">
              Investigation Dossier
            </h3>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-900 text-cyan-400 border border-cyan-800/40">
              {investigation.investigationId}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Generated on {new Date(investigation.timestamp).toLocaleString()} • Grounded in FalkorDB Threat Intelligence
          </p>
        </div>

        {/* Export Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleCopySummary}
            className="text-xs px-2.5 py-1.5 rounded-md bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 flex items-center gap-1.5 transition"
          >
            {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>
          <button
            onClick={handleDownloadMarkdown}
            className="text-xs px-2.5 py-1.5 rounded-md bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 flex items-center gap-1.5 transition"
            title="Download formatted Markdown report"
          >
            <Download className="h-3.5 w-3.5 text-cyan-400" />
            <span>Markdown</span>
          </button>
          <button
            onClick={handleDownloadJson}
            className="text-xs px-2.5 py-1.5 rounded-md bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 flex items-center gap-1.5 transition"
            title="Download full JSON dataset"
          >
            <Download className="h-3.5 w-3.5 text-teal-400" />
            <span>JSON</span>
          </button>
        </div>
      </div>

      {/* 1. Executive Summary */}
      <div>
        <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
          Executive Summary
        </h4>
        <div className="p-3.5 rounded-lg bg-slate-900/70 border border-slate-800 text-xs text-slate-200 leading-relaxed">
          {report.executiveSummary}
        </div>
      </div>

      {/* 2. Structured Findings */}
      <div>
        <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
          Corroborated Findings ({report.findings.length})
        </h4>
        <div className="space-y-2.5">
          {report.findings.map(finding => (
            <div
              key={finding.id}
              className="p-3.5 rounded-lg bg-slate-900/60 border border-slate-800 text-xs flex flex-col gap-1.5"
            >
              <div className="flex items-center justify-between gap-2">
                <span className="font-semibold text-slate-200 flex items-center gap-2">
                  <span className={`h-2 w-2 rounded-full ${
                    finding.severity === 'CRITICAL' ? 'bg-red-500' : finding.severity === 'HIGH' ? 'bg-amber-400' : 'bg-cyan-400'
                  }`} />
                  {finding.title}
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-950 text-slate-400 border border-slate-800">
                  {finding.severity}
                </span>
              </div>
              <p className="text-slate-300 leading-relaxed">{finding.description}</p>
              {finding.evidenceIds.length > 0 && (
                <div className="flex items-center gap-1.5 mt-1 pt-1.5 border-t border-slate-800/80">
                  <span className="text-[10px] text-slate-500">Supporting Evidence Nodes:</span>
                  <div className="flex items-center gap-1 flex-wrap">
                    {finding.evidenceIds.map(eid => (
                      <span
                        key={eid}
                        className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-emerald-950/60 text-emerald-300 border border-emerald-800/50"
                      >
                        {eid}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* 3. Recommended Defensive Actions */}
      <div>
        <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
          Recommended Safe Next Steps
        </h4>
        <div className="rounded-lg bg-slate-900/60 border border-slate-800 p-3.5 space-y-2">
          {report.recommendedNextSteps.map((step, idx) => (
            <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-300">
              <CheckCircle className="h-4 w-4 text-cyan-400 shrink-0 mt-0.5" />
              <span>{step}</span>
            </div>
          ))}
        </div>
      </div>

      {/* 4. Limitations & Synthetic Disclaimer */}
      <div className="p-3 rounded-lg bg-slate-950/70 border border-slate-800 text-[11px] text-slate-400 space-y-1">
        <div className="font-semibold text-slate-300 flex items-center gap-1.5">
          <AlertTriangle className="h-3.5 w-3.5 text-amber-400" />
          Responsible AI & Dataset Disclosure
        </div>
        <p className="leading-relaxed">{report.syntheticDisclaimer}</p>
      </div>
    </div>
  );
};
