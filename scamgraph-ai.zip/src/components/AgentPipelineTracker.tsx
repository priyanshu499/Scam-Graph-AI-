import React from 'react';
import { CheckCircle2, Clock, Activity, Database, ShieldAlert, FileText, Save, ArrowRight } from 'lucide-react';

interface AgentPipelineTrackerProps {
  logs: Array<{
    step: string;
    title: string;
    durationMs: number;
    details: string;
    dataSummary: Record<string, any>;
  }>;
  isLoading: boolean;
  activeStage?: number;
}

export const AgentPipelineTracker: React.FC<AgentPipelineTrackerProps> = ({
  logs,
  isLoading,
  activeStage = 5
}) => {
  const STAGES = [
    { key: 'STAGE_A_EXTRACTION', label: '1. Extraction', icon: Activity },
    { key: 'STAGE_B_GRAPH_QUERY', label: '2. FalkorDB Traversal', icon: Database },
    { key: 'STAGE_C_RISK_SCORE', label: '3. Risk Rules', icon: ShieldAlert },
    { key: 'STAGE_D_REPORT', label: '4. Report Synthesis', icon: FileText },
    { key: 'STAGE_E_MEMORY', label: '5. Persistent Memory', icon: Save }
  ];

  return (
    <div className="rounded-xl border border-slate-800 bg-[#0B111E] p-3.5 shadow-sm">
      <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-800/80">
        <div className="flex items-center gap-2">
          <Activity className="h-4 w-4 text-cyan-400" />
          <span className="text-xs font-semibold text-slate-200">Autonomous Agent Investigation Pipeline</span>
        </div>
        <span className="text-[11px] font-mono text-slate-400">
          {isLoading ? (
            <span className="text-cyan-400 flex items-center gap-1.5 animate-pulse">
              <span className="h-2 w-2 rounded-full bg-cyan-400" />
              Traversing Graph...
            </span>
          ) : (
            <span className="text-emerald-400 flex items-center gap-1">
              <CheckCircle2 className="h-3.5 w-3.5" />
              Pipeline Complete ({logs.reduce((acc, l) => acc + l.durationMs, 0)}ms)
            </span>
          )}
        </span>
      </div>

      {/* Progress Stepper Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
        {STAGES.map((st, idx) => {
          const Icon = st.icon;
          const log = logs.find(l => l.step === st.key);
          const isDone = Boolean(log) || (!isLoading && idx <= activeStage);
          const isCurrent = isLoading && idx === activeStage;

          return (
            <div
              key={st.key}
              className={`p-2.5 rounded-lg border text-xs transition ${
                isDone
                  ? 'bg-slate-900/90 border-cyan-500/30 text-slate-200'
                  : isCurrent
                  ? 'bg-cyan-950/40 border-cyan-500 text-cyan-300 animate-pulse'
                  : 'bg-slate-950/50 border-slate-800/80 text-slate-500'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <Icon className={`h-3.5 w-3.5 ${isDone ? 'text-cyan-400' : isCurrent ? 'text-cyan-300' : 'text-slate-600'}`} />
                {log && (
                  <span className="text-[10px] font-mono text-slate-400 flex items-center gap-0.5">
                    <Clock className="h-2.5 w-2.5" />
                    {log.durationMs}ms
                  </span>
                )}
              </div>
              <div className="font-medium truncate">{st.label}</div>
              {log && (
                <div className="text-[10px] text-slate-400 truncate mt-0.5" title={log.details}>
                  {log.details}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
