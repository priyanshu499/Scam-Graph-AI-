import React, { useState } from 'react';
import { X, Database, Terminal, Copy, Check, CheckCircle2, AlertTriangle, RefreshCw } from 'lucide-react';
import { FalkorStatus, api } from '../lib/api';

interface FalkorSetupModalProps {
  isOpen: boolean;
  onClose: () => void;
  status: FalkorStatus | null;
  onStatusUpdated: (status: FalkorStatus) => void;
}

export const FalkorSetupModal: React.FC<FalkorSetupModalProps> = ({
  isOpen,
  onClose,
  status,
  onStatusUpdated
}) => {
  const [copiedCmd, setCopiedCmd] = useState(false);
  const [customUrl, setCustomUrl] = useState(status?.url || 'falkordb://localhost:6379');
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<string | null>(null);

  if (!isOpen) return null;

  const dockerCommand = 'docker run -p 6379:6379 -it --rm falkordb/falkordb';

  const handleCopy = () => {
    navigator.clipboard.writeText(dockerCommand);
    setCopiedCmd(true);
    setTimeout(() => setCopiedCmd(false), 2000);
  };

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);
    try {
      const res = await api.testConnection(customUrl);
      if (res.connected) {
        setTestResult('Connected successfully to FalkorDB live instance!');
      } else {
        setTestResult(
          `Unable to connect to ${customUrl}. Running in standalone FalkorDB Cypher Engine mode. Start container with the Docker command below.`
        );
      }
      if (res.status) {
        onStatusUpdated(res.status);
      }
    } catch (err: any) {
      setTestResult(`Connection failed: ${err?.message || 'Host unreachable'}`);
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-xl rounded-xl border border-slate-700 bg-[#0B111E] p-6 shadow-2xl flex flex-col gap-4">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="h-9 w-9 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Database className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">FalkorDB Architecture & Connection</h3>
              <p className="text-[11px] text-slate-400">Knowledge Graph Source of Truth</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-slate-800 rounded-md text-slate-400 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Current Connection Status Box */}
        <div className={`p-3.5 rounded-lg border text-xs flex items-start gap-3 ${
          status?.connected
            ? 'bg-emerald-950/30 border-emerald-800/60 text-emerald-200'
            : 'bg-cyan-950/30 border-cyan-800/60 text-cyan-200'
        }`}>
          {status?.connected ? (
            <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0 mt-0.5" />
          ) : (
            <Database className="h-5 w-5 text-cyan-400 shrink-0 mt-0.5" />
          )}
          <div className="space-y-1">
            <div className="font-semibold flex items-center gap-2">
              <span>{status?.connected ? 'Live FalkorDB Connection Active' : 'FalkorDB Standalone Cypher Engine Active'}</span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-900 border border-slate-700">
                {status?.mode}
              </span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              {status?.connected
                ? `Connected to live FalkorDB instance at ${status.url}. Real-time Cypher graph queries and persistent graph updates are active.`
                : 'The application is running with its high-fidelity in-process Cypher graph store. All graph traversals, deterministic scoring, multi-hop path expansions, and investigations are 100% operational. Connect a live FalkorDB instance below for external persistence.'}
            </p>
            <div className="text-[10px] font-mono text-slate-400 pt-1">
              Active Graph Store: <span className="text-white font-bold">{status?.nodeCount} nodes</span>, <span className="text-white font-bold">{status?.edgeCount} relationships</span>.
            </div>
          </div>
        </div>

        {/* Local Docker Setup Instructions */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
            <Terminal className="h-3.5 w-3.5 text-cyan-400" />
            <span>Launch Local FalkorDB with Docker</span>
          </label>
          <div className="relative flex items-center">
            <code className="w-full text-xs font-mono bg-slate-950 border border-slate-800 rounded-lg p-2.5 pr-20 text-cyan-300 select-all overflow-x-auto">
              {dockerCommand}
            </code>
            <button
              onClick={handleCopy}
              className="absolute right-2 text-xs px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center gap-1 transition"
            >
              {copiedCmd ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
              <span>{copiedCmd ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
          <p className="text-[11px] text-slate-500">
            Or use the included <span className="font-mono text-slate-400">docker-compose.yml</span>: run <code className="text-cyan-400 font-mono">docker compose up -d</code>.
          </p>
        </div>

        {/* Custom URL & Test Connection */}
        <div className="space-y-2 pt-2 border-t border-slate-800">
          <label className="text-xs font-semibold text-slate-300">
            FalkorDB Connection URL
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={customUrl}
              onChange={e => setCustomUrl(e.target.value)}
              placeholder="falkordb://localhost:6379"
              className="flex-1 text-xs font-mono rounded-lg border border-slate-800 bg-slate-950 p-2 text-slate-200 focus:outline-none focus:border-cyan-500"
            />
            <button
              onClick={handleTestConnection}
              disabled={isTesting}
              className="text-xs px-3.5 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold flex items-center gap-1.5 transition disabled:opacity-50"
            >
              <RefreshCw className={`h-3 w-3 ${isTesting ? 'animate-spin' : ''}`} />
              <span>Test Socket</span>
            </button>
          </div>

          {testResult && (
            <div className="text-[11px] p-2 rounded bg-slate-900 border border-slate-800 text-slate-300">
              {testResult}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-2 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="text-xs px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
