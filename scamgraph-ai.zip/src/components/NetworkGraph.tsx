import React, { useRef, useState, useEffect, useMemo } from 'react';
import ForceGraph2D from 'react-force-graph-2d';
import { ZoomIn, ZoomOut, Maximize2, RotateCcw, Info, X, Shield, AlertTriangle, Layers, FileCheck } from 'lucide-react';
import { GraphNodeData, GraphLinkData } from '../lib/api';

interface NetworkGraphProps {
  nodes: GraphNodeData[];
  links: GraphLinkData[];
  highlightedPathNodeIds?: string[];
  onNodeClick?: (node: GraphNodeData) => void;
  height?: number;
}

export const NetworkGraph: React.FC<NetworkGraphProps> = ({
  nodes,
  links,
  highlightedPathNodeIds = [],
  onNodeClick,
  height = 420
}) => {
  const fgRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [dimensions, setDimensions] = useState({ width: 700, height });
  const [selectedNode, setSelectedNode] = useState<GraphNodeData | null>(null);
  const [zoomLevel, setZoomLevel] = useState(1);

  // Resize listener
  useEffect(() => {
    function updateDimensions() {
      if (containerRef.current) {
        setDimensions({
          width: containerRef.current.clientWidth || 700,
          height: height
        });
      }
    }
    updateDimensions();
    window.addEventListener('resize', updateDimensions);
    return () => window.removeEventListener('resize', updateDimensions);
  }, [height]);

  // Transform graph data for ForceGraph
  const graphData = useMemo(() => {
    const formattedNodes = nodes.map(n => ({
      ...n,
      id: n.id,
      name: n.label,
      val: n.val || 12,
      color: n.color || '#94A3B8'
    }));

    const formattedLinks = links.map(l => ({
      ...l,
      source: typeof l.source === 'object' ? (l.source as any).id : l.source,
      target: typeof l.target === 'object' ? (l.target as any).id : l.target,
      label: l.label || 'LINKED',
      color: l.color || '#334155'
    }));

    return {
      nodes: formattedNodes,
      links: formattedLinks
    };
  }, [nodes, links]);

  // Center view on mount or when data changes
  useEffect(() => {
    const timer = setTimeout(() => {
      if (fgRef.current) {
        fgRef.current.zoomToFit(400, 40);
      }
    }, 300);
    return () => clearTimeout(timer);
  }, [nodes.length, links.length]);

  const handleZoomIn = () => {
    if (fgRef.current) {
      fgRef.current.zoom(zoomLevel * 1.3, 300);
      setZoomLevel(prev => prev * 1.3);
    }
  };

  const handleZoomOut = () => {
    if (fgRef.current) {
      fgRef.current.zoom(zoomLevel * 0.7, 300);
      setZoomLevel(prev => prev * 0.7);
    }
  };

  const handleResetZoom = () => {
    if (fgRef.current) {
      fgRef.current.zoomToFit(400, 40);
      setZoomLevel(1);
    }
  };

  const handleNodeClick = (node: any) => {
    const matched = nodes.find(n => n.id === node.id) || node;
    setSelectedNode(matched);
    if (onNodeClick) onNodeClick(matched);
  };

  // Node counts by category
  const nodeCounts = useMemo(() => {
    const counts: Record<string, number> = {
      Brand: 0,
      Indicator: 0,
      Incident: 0,
      Campaign: 0,
      Evidence: 0
    };
    for (const n of nodes) {
      if (counts[n.type] !== undefined) {
        counts[n.type]++;
      }
    }
    return counts;
  }, [nodes]);

  return (
    <div
      ref={containerRef}
      className="relative rounded-xl border border-slate-800 bg-[#070B14] overflow-hidden shadow-inner flex flex-col"
      style={{ height }}
    >
      {/* Top Overlay: Title & Node Legend */}
      <div className="absolute top-3 left-3 z-10 flex flex-wrap items-center gap-2 pointer-events-none">
        <div className="bg-slate-900/90 backdrop-blur px-2.5 py-1 rounded-md border border-slate-800 text-xs font-medium text-slate-300 shadow">
          <span>Evidence Graph ({nodes.length} nodes, {links.length} relationships)</span>
        </div>

        {/* Badges for active node types */}
        <div className="hidden sm:flex items-center gap-1.5 bg-slate-900/80 backdrop-blur px-2.5 py-1 rounded-md border border-slate-800 text-[11px] font-mono">
          <span className="flex items-center gap-1 text-sky-400">
            <span className="h-2 w-2 rounded-full bg-sky-400" />
            Brand ({nodeCounts.Brand})
          </span>
          <span className="text-slate-700">|</span>
          <span className="flex items-center gap-1 text-rose-400">
            <span className="h-2 w-2 rounded-full bg-rose-500" />
            Indicator ({nodeCounts.Indicator})
          </span>
          <span className="text-slate-700">|</span>
          <span className="flex items-center gap-1 text-amber-400">
            <span className="h-2 w-2 rounded-full bg-amber-400" />
            Incident ({nodeCounts.Incident})
          </span>
          <span className="text-slate-700">|</span>
          <span className="flex items-center gap-1 text-purple-400">
            <span className="h-2 w-2 rounded-full bg-purple-400" />
            Campaign ({nodeCounts.Campaign})
          </span>
          <span className="text-slate-700">|</span>
          <span className="flex items-center gap-1 text-emerald-400">
            <span className="h-2 w-2 rounded-full bg-emerald-400" />
            Evidence ({nodeCounts.Evidence})
          </span>
        </div>
      </div>

      {/* Floating Canvas Zoom Controls */}
      <div className="absolute top-3 right-3 z-10 flex flex-col gap-1 bg-slate-900/90 backdrop-blur p-1 rounded-lg border border-slate-800 shadow">
        <button
          onClick={handleZoomIn}
          className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition"
          title="Zoom In"
          aria-label="Zoom in graph"
        >
          <ZoomIn className="h-3.5 w-3.5" />
        </button>
        <button
          onClick={handleZoomOut}
          className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition"
          title="Zoom Out"
          aria-label="Zoom out graph"
        >
          <ZoomOut className="h-3.5 w-3.5" />
        </button>
        <button
          onClick={handleResetZoom}
          className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition"
          title="Reset View"
          aria-label="Reset zoom"
        >
          <RotateCcw className="h-3.5 w-3.5" />
        </button>
      </div>

      {/* Canvas Area */}
      <div className="flex-1 w-full h-full cursor-grab active:cursor-grabbing">
        {nodes.length === 0 ? (
          <div className="h-full flex items-center justify-center text-slate-500 text-sm">
            No graph entities to display. Run an investigation or select a demo scenario.
          </div>
        ) : (
          <ForceGraph2D
            ref={fgRef}
            width={dimensions.width}
            height={dimensions.height}
            graphData={graphData}
            nodeLabel="name"
            nodeRelSize={5}
            linkColor={(link: any) => {
              if (highlightedPathNodeIds.includes(link.source?.id) && highlightedPathNodeIds.includes(link.target?.id)) {
                return '#2DD4BF'; // Highlighted path link
              }
              return link.color || '#334155';
            }}
            linkWidth={(link: any) => {
              if (highlightedPathNodeIds.includes(link.source?.id) && highlightedPathNodeIds.includes(link.target?.id)) {
                return 2.5;
              }
              return 1.2;
            }}
            linkDirectionalArrowLength={3.5}
            linkDirectionalArrowRelPos={1}
            nodeCanvasObject={(node: any, ctx: CanvasRenderingContext2D, globalScale: number) => {
              const label = node.name || node.id;
              const isHighlighted = highlightedPathNodeIds.includes(node.id);
              const isSelected = selectedNode?.id === node.id;
              const radius = (node.val || 10) * 0.7;

              // Outer glow for highlighted path or selection
              if (isHighlighted || isSelected) {
                ctx.beginPath();
                ctx.arc(node.x, node.y, radius + 4, 0, 2 * Math.PI, false);
                ctx.fillStyle = isSelected ? 'rgba(45, 212, 191, 0.4)' : 'rgba(167, 139, 250, 0.35)';
                ctx.fill();
                ctx.lineWidth = 1.5;
                ctx.strokeStyle = isSelected ? '#2DD4BF' : '#A78BFA';
                ctx.stroke();
              }

              // Main node circle
              ctx.beginPath();
              ctx.arc(node.x, node.y, radius, 0, 2 * Math.PI, false);
              ctx.fillStyle = node.color || '#94A3B8';
              ctx.fill();
              ctx.strokeStyle = '#0F172A';
              ctx.lineWidth = 1.5;
              ctx.stroke();

              // Node text label
              if (globalScale > 0.8 || isHighlighted || isSelected) {
                const fontSize = Math.max(10 / globalScale, 3);
                ctx.font = `${fontSize}px Inter, sans-serif`;
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillStyle = '#E2E8F0';
                ctx.fillText(label, node.x, node.y + radius + fontSize);
              }
            }}
            onNodeClick={handleNodeClick}
            cooldownTicks={120}
            d3VelocityDecay={0.3}
          />
        )}
      </div>

      {/* Selected Node Details Drawer */}
      {selectedNode && (
        <div className="absolute bottom-3 left-3 right-3 md:right-auto md:w-96 z-20 bg-slate-900/95 backdrop-blur-md rounded-lg border border-slate-700/80 p-3 shadow-xl text-xs transition animate-in fade-in slide-in-from-bottom-2">
          <div className="flex items-start justify-between gap-2 pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <span
                className="h-2.5 w-2.5 rounded-full"
                style={{ backgroundColor: selectedNode.color }}
              />
              <span className="font-semibold text-slate-200">{selectedNode.label}</span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                {selectedNode.type}
              </span>
            </div>
            <button
              onClick={() => setSelectedNode(null)}
              className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white"
              aria-label="Close details"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>

          <div className="mt-2 space-y-1.5 text-slate-300">
            {selectedNode.properties?.summary && (
              <p className="text-slate-300 leading-snug">{selectedNode.properties.summary}</p>
            )}
            {selectedNode.properties?.description && (
              <p className="text-slate-300 leading-snug">{selectedNode.properties.description}</p>
            )}
            {selectedNode.properties?.notes && (
              <p className="text-slate-400 italic text-[11px]">{selectedNode.properties.notes}</p>
            )}

            <div className="grid grid-cols-2 gap-2 pt-1 font-mono text-[11px]">
              <div>
                <span className="text-slate-500">ID: </span>
                <span className="text-slate-300">{selectedNode.id}</span>
              </div>
              {selectedNode.properties?.severity && (
                <div>
                  <span className="text-slate-500">Severity: </span>
                  <span className={selectedNode.properties.severity === 'CRITICAL' ? 'text-red-400 font-bold' : 'text-amber-400'}>
                    {selectedNode.properties.severity}
                  </span>
                </div>
              )}
              {selectedNode.properties?.riskWeight !== undefined && (
                <div>
                  <span className="text-slate-500">Risk Weight: </span>
                  <span className="text-rose-400 font-semibold">{selectedNode.properties.riskWeight}/100</span>
                </div>
              )}
              {selectedNode.properties?.confidence !== undefined && (
                <div>
                  <span className="text-slate-500">Confidence: </span>
                  <span className="text-emerald-400">{Math.round(selectedNode.properties.confidence * 100)}%</span>
                </div>
              )}
              {selectedNode.properties?.officialDomain && (
                <div className="col-span-2">
                  <span className="text-slate-500">Official Domain: </span>
                  <span className="text-cyan-400">{selectedNode.properties.officialDomain}</span>
                </div>
              )}
              {selectedNode.properties?.firstSeen && (
                <div className="col-span-2 text-[10px] text-slate-500">
                  First Cataloged: {new Date(selectedNode.properties.firstSeen).toLocaleDateString()}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
