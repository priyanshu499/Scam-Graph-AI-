import React, { useState } from 'react';
import {
  ShieldAlert,
  AlertTriangle,
  HelpCircle,
  Sliders,
  Check,
  RotateCcw,
  Info,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { InvestigationData } from '../lib/api';

interface RiskAssessmentCardProps {
  assessment: InvestigationData['assessment'];
  onSimulateCounterfactual?: (excludedRuleIds: string[]) => void;
  simulatedScore?: number | null;
  excludedRules?: string[];
  onToggleRule?: (ruleId: string) => void;
  onResetSimulation?: () => void;
}

export const RiskAssessmentCard: React.FC<RiskAssessmentCardProps> = ({
  assessment,
  simulatedScore,
  excludedRules = [],
  onToggleRule,
  onResetSimulation
}) => {
  const [showRulesBreakdown, setShowRulesBreakdown] = useState(true);
  const [showCounterfactual, setShowCounterfactual] = useState(false);

  const isSimulated = simulatedScore !== undefined && simulatedScore !== null && simulatedScore !== assessment.riskScore;
  const displayScore = isSimulated ? simulatedScore : assessment.riskScore;
  const scoreDelta = isSimulated ? (simulatedScore! - assessment.riskScore) : 0;

  // Determine badge styling
  const getBadgeStyle = (level: string) => {
    switch (level) {
      case 'HIGH_RISK':
        return 'bg-red-950/60 text-red-300 border-red-800/80';
      case 'NEEDS_CAUTION':
        return 'bg-amber-950/60 text-amber-300 border-amber-800/80';
      case 'LOW_RISK':
        return 'bg-blue-950/60 text-blue-300 border-blue-800/80';
      case 'INSUFFICIENT_EVIDENCE':
      default:
        return 'bg-slate-800/60 text-slate-300 border-slate-700/80';
    }
  };

  const getScoreColor = (score: number, level: string) => {
    if (level === 'INSUFFICIENT_EVIDENCE') return 'text-slate-400';
    if (score >= 70) return 'text-red-400';
    if (score >= 40) return 'text-amber-400';
    return 'text-blue-400';
  };

  return (
    <div className="rounded-xl border border-slate-800 bg-[#0B111E] p-4 shadow-sm flex flex-col gap-4">
      {/* Top Header: Score & Badges */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center h-16 w-16 rounded-xl bg-slate-900 border border-slate-800 shrink-0">
            <span className={`text-2xl font-black font-mono ${getScoreColor(displayScore, assessment.riskLevel)}`}>
              {displayScore}
            </span>
            <span className="text-[10px] text-slate-500 font-mono absolute bottom-1.5">/100</span>
          </div>

          <div>
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full border ${getBadgeStyle(assessment.riskLevel)}`}>
                {assessment.riskLabel}
              </span>
              {isSimulated && (
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800 flex items-center gap-1">
                  <Sliders className="h-2.5 w-2.5" />
                  Simulated ({scoreDelta > 0 ? `+${scoreDelta}` : scoreDelta} pts)
                </span>
              )}
            </div>
            <div className="text-xs text-slate-400">
              Deterministic rule assessment computed across FalkorDB knowledge graph.
            </div>
          </div>
        </div>

        {/* Telemetry metrics: Confidence & Coverage */}
        <div className="flex sm:flex-col items-end gap-1.5 text-xs font-mono">
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500">Confidence:</span>
            <span className="text-emerald-400 font-semibold">{assessment.evidenceConfidence}%</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500">Coverage:</span>
            <span className={`font-semibold ${
              assessment.evidenceCoverage === 'HIGH'
                ? 'text-emerald-400'
                : assessment.evidenceCoverage === 'MODERATE'
                ? 'text-cyan-400'
                : assessment.evidenceCoverage === 'LOW'
                ? 'text-amber-400'
                : 'text-slate-400'
            }`}>
              {assessment.evidenceCoverage}
            </span>
          </div>
        </div>
      </div>

      {/* Explanation summary */}
      <div className="text-xs text-slate-300 leading-relaxed bg-slate-900/60 p-3 rounded-lg border border-slate-800/80">
        <p>{assessment.explanation}</p>
      </div>

      {/* Counterfactual Risk Simulation Toggle */}
      <div className="rounded-lg border border-slate-800/90 bg-slate-900/40 p-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sliders className="h-4 w-4 text-cyan-400" />
            <div>
              <span className="text-xs font-semibold text-slate-200">Counterfactual Risk Explorer</span>
              <span className="text-[10px] text-slate-500 block">
                Simulate "What changes if this link is absent?" without altering FalkorDB
              </span>
            </div>
          </div>
          <button
            onClick={() => setShowCounterfactual(!showCounterfactual)}
            className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
          >
            {showCounterfactual ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
            <span>{showCounterfactual ? 'Hide Simulation' : 'Explore'}</span>
          </button>
        </div>

        {showCounterfactual && (
          <div className="mt-3 pt-3 border-t border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-[11px] text-slate-400 mb-2">
              <span>Uncheck active signals to test hypothesis:</span>
              {excludedRules.length > 0 && onResetSimulation && (
                <button
                  onClick={onResetSimulation}
                  className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
                >
                  <RotateCcw className="h-3 w-3" />
                  Reset Signals
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {assessment.rules
                .filter(r => r.applied)
                .map(rule => {
                  const isExcluded = excludedRules.includes(rule.ruleId);
                  return (
                    <label
                      key={rule.ruleId}
                      className={`flex items-start gap-2.5 p-2 rounded border cursor-pointer transition text-xs ${
                        isExcluded
                          ? 'bg-slate-950/40 border-slate-800/60 text-slate-500 line-through'
                          : 'bg-slate-900/80 border-slate-800 text-slate-200'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={!isExcluded}
                        onChange={() => onToggleRule && onToggleRule(rule.ruleId)}
                        className="mt-0.5 rounded border-slate-700 bg-slate-950 text-cyan-500 focus:ring-0 focus:ring-offset-0"
                      />
                      <div className="min-w-0">
                        <div className="font-medium flex items-center justify-between">
                          <span className="truncate">{rule.name}</span>
                          <span className="font-mono text-[10px] text-cyan-400 shrink-0 ml-1">+{rule.points} pts</span>
                        </div>
                        <div className="text-[10px] text-slate-400 truncate mt-0.5">{rule.description}</div>
                      </div>
                    </label>
                  );
                })}
            </div>
          </div>
        )}
      </div>

      {/* Inspectable Scoring Rules Breakdown */}
      <div>
        <button
          onClick={() => setShowRulesBreakdown(!showRulesBreakdown)}
          className="w-full flex items-center justify-between text-xs font-semibold text-slate-300 hover:text-white py-1"
        >
          <span>Transparent Scoring Formula & Applied Criteria</span>
          {showRulesBreakdown ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5 text-slate-500" />}
        </button>

        {showRulesBreakdown && (
          <div className="mt-2 space-y-1.5">
            {assessment.rules.map(rule => (
              <div
                key={rule.ruleId}
                className={`p-2.5 rounded-lg border text-xs flex items-start justify-between gap-3 ${
                  rule.applied
                    ? 'bg-slate-900/80 border-slate-800/90 text-slate-200'
                    : 'bg-slate-950/30 border-slate-800/40 text-slate-500'
                }`}
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold">{rule.name}</span>
                    <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
                      rule.applied ? 'bg-cyan-950 text-cyan-400 border border-cyan-800/40' : 'bg-slate-900 text-slate-600'
                    }`}>
                      {rule.applied ? 'APPLIED' : 'NOT TRIGGERED'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">{rule.reason}</p>
                </div>

                <div className="text-right shrink-0 font-mono">
                  <span className={`font-bold ${rule.applied ? 'text-cyan-400' : 'text-slate-600'}`}>
                    +{rule.points}
                  </span>
                  <span className="text-[10px] text-slate-500"> / {rule.maxPoints}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
