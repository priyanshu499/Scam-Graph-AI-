import React, { useState } from 'react';
import { ShieldAlert, Database, RefreshCw, Cpu, ExternalLink, Terminal, Menu, X } from 'lucide-react';
import { FalkorStatus, GraphOverviewStats } from '../lib/api';

interface NavbarProps {
  falkorStatus: FalkorStatus | null;
  stats: GraphOverviewStats | null;
  onOpenSetup: () => void;
  onSeedGraph: () => void;
  onNewInvestigation: () => void;
  isSeeding: boolean;
  onToggleMobileMenu?: () => void;
  isMobileMenuOpen?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  falkorStatus,
  stats,
  onOpenSetup,
  onSeedGraph,
  onNewInvestigation,
  isSeeding,
  onToggleMobileMenu,
  isMobileMenuOpen
}) => {
  return (
    <header className="h-16 border-b border-slate-800 bg-[#0B111E]/90 backdrop-blur sticky top-0 z-40 px-3 md:px-6 flex items-center justify-between">
      {/* Brand & Badge */}
      <div className="flex items-center gap-2.5">
        <button
          onClick={onToggleMobileMenu}
          className="md:hidden p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          aria-label="Toggle Navigation Menu"
        >
          {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>

        <div className="h-9 w-9 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shadow-sm shadow-cyan-950 shrink-0">
          <ShieldAlert className="h-5 w-5" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="font-bold text-lg tracking-tight text-white">ScamGraph <span className="text-cyan-400">AI</span></span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950/60 text-cyan-400 border border-cyan-800/40 hidden sm:inline-block">
              FalkorDB Graph Hacks 2026
            </span>
          </div>
          <p className="text-[11px] text-slate-400 hidden md:block">
            Explainable Scam Network Investigator • Powered by Connected Knowledge Graphs
          </p>
        </div>
      </div>

      {/* Right Controls & Telemetry */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Graph Telemetry */}
        {stats && (
          <div className="hidden lg:flex items-center gap-2 text-xs font-mono text-slate-400 bg-slate-900/80 px-3 py-1.5 rounded-md border border-slate-800">
            <Cpu className="h-3.5 w-3.5 text-slate-400" />
            <span className="text-slate-200 font-semibold">{stats.nodeCount}</span> Nodes
            <span className="text-slate-600">•</span>
            <span className="text-slate-200 font-semibold">{stats.edgeCount}</span> Edges
            <span className="text-slate-600">•</span>
            <span className="text-slate-200 font-semibold">{stats.incidentCount}</span> Incidents
          </div>
        )}

        {/* FalkorDB Connection Status Pill */}
        <button
          onClick={onOpenSetup}
          className={`text-xs px-2.5 py-1.5 rounded-md border flex items-center gap-2 transition font-mono ${
            falkorStatus?.connected
              ? 'bg-emerald-950/40 text-emerald-300 border-emerald-800/50 hover:bg-emerald-900/40'
              : 'bg-cyan-950/40 text-cyan-300 border-cyan-800/50 hover:bg-cyan-900/40'
          }`}
          title="Click to view FalkorDB Connection & Docker setup"
        >
          <span className={`h-2 w-2 rounded-full ${falkorStatus?.connected ? 'bg-emerald-400 animate-pulse' : 'bg-cyan-400'}`} />
          <Database className="h-3.5 w-3.5" />
          <span className="hidden sm:inline">
            {falkorStatus?.connected ? 'FalkorDB :6379 (Live)' : 'FalkorDB Standalone Cypher'}
          </span>
          <Terminal className="h-3 w-3 text-slate-400 ml-1" />
        </button>

        {/* Seed Data Button */}
        <button
          onClick={onSeedGraph}
          disabled={isSeeding}
          className="text-xs px-3 py-1.5 rounded-md bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700/80 flex items-center gap-1.5 transition disabled:opacity-50"
          title="Re-seed synthetic incidents, brands, and relationships"
        >
          <RefreshCw className={`h-3.5 w-3.5 text-cyan-400 ${isSeeding ? 'animate-spin' : ''}`} />
          <span className="hidden sm:inline">Reset Graph</span>
        </button>

        {/* Primary Action Button */}
        <button
          onClick={onNewInvestigation}
          className="text-xs font-medium px-3.5 py-1.5 rounded-md bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-950 font-semibold shadow-sm shadow-cyan-900/30 flex items-center gap-1.5 transition"
        >
          <ShieldAlert className="h-3.5 w-3.5" />
          <span>Investigate</span>
        </button>
      </div>
    </header>
  );
};
