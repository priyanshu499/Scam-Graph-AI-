import React from 'react';
import {
  LayoutDashboard,
  SearchCode,
  Network,
  History,
  FlaskConical,
  Layers,
  ChevronRight
} from 'lucide-react';

export type NavTab = 'overview' | 'workspace' | 'explorer' | 'history' | 'demolab' | 'architecture';

interface SidebarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  investigationCount: number;
  isOpenOnMobile?: boolean;
  onCloseMobile?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  investigationCount,
  isOpenOnMobile = false,
  onCloseMobile
}) => {
  const handleSelect = (tab: NavTab) => {
    onSelectTab(tab);
    if (onCloseMobile) onCloseMobile();
  };
  const navItems = [
    {
      id: 'overview' as NavTab,
      label: 'Command Center',
      sublabel: 'Threat Overview & Metrics',
      icon: LayoutDashboard
    },
    {
      id: 'workspace' as NavTab,
      label: 'Investigation Workspace',
      sublabel: 'Agent Pipeline & Analysis',
      icon: SearchCode,
      highlight: true
    },
    {
      id: 'explorer' as NavTab,
      label: 'Graph Evidence Explorer',
      sublabel: 'Interactive Knowledge Network',
      icon: Network
    },
    {
      id: 'history' as NavTab,
      label: 'Investigation Memory',
      sublabel: 'Saved History & Feedback',
      icon: History,
      badge: investigationCount > 0 ? investigationCount : undefined
    },
    {
      id: 'demolab' as NavTab,
      label: 'Scenario Demo Lab',
      sublabel: '4 Preloaded Test Scenarios',
      icon: FlaskConical
    },
    {
      id: 'architecture' as NavTab,
      label: 'Architecture & Cypher',
      sublabel: 'Schema & FalkorDB Docs',
      icon: Layers
    }
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenOnMobile && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-xs md:hidden"
        />
      )}

      {/* Main Sidebar Element */}
      <aside
        className={`fixed md:static inset-y-0 left-0 z-50 w-64 border-r border-slate-800 bg-[#0B111E] md:bg-[#0B111E]/70 flex flex-col shrink-0 min-h-[calc(100vh-4rem)] transition-transform duration-200 ease-in-out md:translate-x-0 ${
          isOpenOnMobile ? 'translate-x-0 shadow-2xl' : '-translate-x-full md:translate-x-0'
        } ${!isOpenOnMobile ? 'hidden md:flex' : 'flex'}`}
      >
        <div className="p-3">
          <div className="text-[10px] font-semibold tracking-wider text-slate-500 uppercase px-3 py-2">
            Investigation Console
          </div>
          <nav className="space-y-1">
            {navItems.map(item => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleSelect(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-left transition group ${
                    isActive
                      ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <Icon
                      className={`h-4 w-4 shrink-0 ${
                        isActive ? 'text-cyan-400' : 'text-slate-500 group-hover:text-slate-300'
                      }`}
                    />
                    <div className="truncate">
                      <div className="text-xs font-medium text-slate-200 group-hover:text-white">
                        {item.label}
                      </div>
                      <div className="text-[10px] text-slate-500 truncate">
                        {item.sublabel}
                      </div>
                    </div>
                  </div>

                  {item.badge !== undefined && (
                    <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Synthetic Dataset Notice in Sidebar Bottom */}
        <div className="mt-auto p-4 border-t border-slate-800/80">
          <div className="rounded-lg bg-slate-900/70 border border-slate-800 p-3 text-xs">
            <div className="flex items-center gap-1.5 text-cyan-400 font-medium mb-1">
              <span className="h-1.5 w-1.5 rounded-full bg-cyan-400" />
              Synthetic Intelligence
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              All brand entities and domains (e.g. <span className="font-mono text-slate-300">.test</span>) in demo data are synthetic and isolated for ethical security evaluation.
            </p>
          </div>
        </div>
      </aside>
    </>
  );
};
