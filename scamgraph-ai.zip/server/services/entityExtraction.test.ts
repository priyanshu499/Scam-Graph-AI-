import test from 'node:test';
import assert from 'node:assert/strict';
import { extractEntities, normalizeIndicator } from './entityExtraction.ts';

test('normalizeIndicator normalizes domains and URLs', () => {
  assert.equal(
    normalizeIndicator('https://NorthStar-Verify.TEST/auth/', 'domain'),
    'northstar-verify.test/auth'
  );
  assert.equal(
    normalizeIndicator('http://www.SwiftDrop-Pay.test', 'domain'),
    'swiftdrop-pay.test'
  );
});

test('normalizeIndicator formats 10 and 11 digit phones', () => {
  assert.equal(
    normalizeIndicator('8005550199', 'phone'),
    '+1-800-555-0199'
  );
  assert.equal(
    normalizeIndicator('+1 (888) 555-0142', 'phone'),
    '+1-888-555-0142'
  );
});

test('normalizeIndicator handles cashtags and crypto', () => {
  assert.equal(
    normalizeIndicator('Northstar-Help', 'payment_handle'),
    '$northstar-help'
  );
  assert.equal(
    normalizeIndicator('$ApexCareers_HR', 'payment_handle'),
    '$apexcareers_hr'
  );
});

test('extractEntities extracts domain, brand, phone and urgency signals', () => {
  const sample = 'Northstar Bank says my account will be suspended unless I verify my identity at northstar-verify.test. Call +1-800-555-0199 immediately!';
  const result = extractEntities(sample);

  assert.equal(result.claimedBrands.includes('Northstar Bank'), true);
  assert.equal(result.hasUrgentRequest, true);
  assert.equal(result.hasCredentialRequest, true);

  const domain = result.indicators.find(i => i.value.includes('northstar-verify.test'));
  assert.notEqual(domain, undefined);

  const phone = result.indicators.find(i => i.type === 'phone');
  assert.notEqual(phone, undefined);
  assert.equal(phone?.value, '+1-800-555-0199');
});

test('extractEntities extracts payment handles and crypto addresses', () => {
  const sample = 'Deposit $350 fee to 0x9f82c40134d4a8e2 or send to $swiftdrop-release';
  const result = extractEntities(sample);

  assert.equal(result.hasPaymentRequest, true);
  const crypto = result.indicators.find(i => i.value.startsWith('crypto:0x9f82'));
  assert.notEqual(crypto, undefined);

  const cashtag = result.indicators.find(i => i.value === '$swiftdrop-release');
  assert.notEqual(cashtag, undefined);
});
