import { FalkorDB } from 'falkordb';
import {
  SEED_BRANDS,
  SEED_CAMPAIGNS,
  SEED_INDICATORS,
  SEED_INCIDENTS,
  SEED_EVIDENCE,
  SEED_RELATIONSHIPS
} from '../data/seedData';

export interface GraphNode {
  id: string;
  labels: string[];
  properties: Record<string, any>;
}

export interface GraphEdge {
  id: string;
  fromId: string;
  toId: string;
  relType: string;
  properties: Record<string, any>;
}

export interface GraphPath {
  nodes: GraphNode[];
  edges: GraphEdge[];
  summary: string;
}

export interface FalkorStatus {
  connected: boolean;
  mode: 'falkordb_live' | 'falkordb_standalone';
  url: string;
  graphName: string;
  lastChecked: string;
  errorMessage?: string;
  nodeCount: number;
  edgeCount: number;
}

// In-process graph storage backing the Cypher query runner
class MemoryGraphStore {
  nodes: Map<string, GraphNode> = new Map();
  edges: Map<string, GraphEdge> = new Map();

  clear() {
    this.nodes.clear();
    this.edges.clear();
  }

  addNode(node: GraphNode) {
    this.nodes.set(node.id, {
      ...node,
      properties: { ...node.properties, id: node.id }
    });
  }

  addEdge(edge: GraphEdge) {
    this.edges.set(edge.id, edge);
  }

  getNode(id: string): GraphNode | undefined {
    return this.nodes.get(id);
  }

  getEdgesFrom(fromId: string): GraphEdge[] {
    const list: GraphEdge[] = [];
    for (const edge of this.edges.values()) {
      if (edge.fromId === fromId) list.push(edge);
    }
    return list;
  }

  getEdgesTo(toId: string): GraphEdge[] {
    const list: GraphEdge[] = [];
    for (const edge of this.edges.values()) {
      if (edge.toId === toId) list.push(edge);
    }
    return list;
  }

  getEdgesConnected(nodeId: string): GraphEdge[] {
    const list: GraphEdge[] = [];
    for (const edge of this.edges.values()) {
      if (edge.fromId === nodeId || edge.toId === nodeId) list.push(edge);
    }
    return list;
  }
}

class FalkorDBService {
  private url: string;
  private graphName = 'scamgraph_ai';
  private client: any = null;
  private graph: any = null;
  private isLiveConnected = false;
  private lastError: string | null = null;
  public memoryStore = new MemoryGraphStore();

  constructor() {
    this.url = process.env.FALKORDB_URL || 'falkordb://localhost:6379';
    // Seed initial dataset into memory store immediately so query operations are always available
    this.seedMemoryStore();
  }

  public getStatus(): FalkorStatus {
    return {
      connected: this.isLiveConnected,
      mode: this.isLiveConnected ? 'falkordb_live' : 'falkordb_standalone',
      url: this.url,
      graphName: this.graphName,
      lastChecked: new Date().toISOString(),
      errorMessage: this.lastError || undefined,
      nodeCount: this.memoryStore.nodes.size,
      edgeCount: this.memoryStore.edges.size
    };
  }

  public async connect(customUrl?: string): Promise<boolean> {
    if (customUrl) {
      this.url = customUrl;
    }

    const connectionUrl = this.url.startsWith('falkordb://')
      ? this.url.replace(/^falkordb:\/\//, 'redis://')
      : this.url;

    try {
      // Attempt connection with timeout
      const client = await Promise.race([
        FalkorDB.connect({ url: connectionUrl }),
        new Promise((_, reject) => setTimeout(() => reject(new Error('Connection timeout to ' + this.url)), 1500))
      ]);

      this.client = client;
      this.graph = (this.client as any).selectGraph(this.graphName);
      // Run quick test query
      await this.graph.query('RETURN 1');
      this.isLiveConnected = true;
      this.lastError = null;

      // Ensure graph is seeded in live FalkorDB
      await this.seedLiveDatabase();
      return true;
    } catch (err: any) {
      this.isLiveConnected = false;
      this.lastError = err?.message || 'Unable to connect to FalkorDB instance';
      return false;
    }
  }

  public seedMemoryStore() {
    this.memoryStore.clear();

    // Brands
    for (const brand of SEED_BRANDS) {
      this.memoryStore.addNode({
        id: brand.id,
        labels: ['Brand'],
        properties: {
          name: brand.name,
          classification: brand.classification,
          officialDomain: brand.officialDomain,
          industry: brand.industry,
          isSynthetic: true
        }
      });
    }

    // Campaigns
    for (const camp of SEED_CAMPAIGNS) {
      this.memoryStore.addNode({
        id: camp.id,
        labels: ['Campaign'],
        properties: {
          label: camp.label,
          description: camp.description,
          status: camp.status,
          isSynthetic: true
        }
      });
    }

    // Indicators
    for (const ind of SEED_INDICATORS) {
      this.memoryStore.addNode({
        id: ind.id,
        labels: ['Indicator', ind.indicatorType === 'domain' ? 'Domain' : 'EntityIndicator'],
        properties: {
          value: ind.value.toLowerCase(),
          indicatorType: ind.indicatorType,
          displayValue: ind.displayValue,
          firstSeen: ind.firstSeen,
          riskWeight: ind.riskWeight,
          notes: ind.notes,
          isSynthetic: true
        }
      });
    }

    // Evidence
    for (const evd of SEED_EVIDENCE) {
      this.memoryStore.addNode({
        id: evd.id,
        labels: ['Evidence'],
        properties: {
          evidenceType: evd.evidenceType,
          description: evd.description,
          confidence: evd.confidence,
          sourceType: evd.sourceType,
          isSynthetic: true
        }
      });
    }

    // Incidents
    for (const inc of SEED_INCIDENTS) {
      this.memoryStore.addNode({
        id: inc.id,
        labels: ['Incident'],
        properties: {
          summary: inc.summary,
          category: inc.category,
          timestamp: inc.timestamp,
          severity: inc.severity,
          sourceType: inc.sourceType,
          victimCountEstimate: inc.victimCountEstimate,
          isSynthetic: true
        }
      });
    }

    // Relationships
    let relIndex = 0;
    for (const rel of SEED_RELATIONSHIPS) {
      relIndex++;
      this.memoryStore.addEdge({
        id: `rel-${relIndex}-${rel.fromId}-${rel.relType}-${rel.toId}`,
        fromId: rel.fromId,
        toId: rel.toId,
        relType: rel.relType,
        properties: rel.properties || {}
      });
    }
  }

  public async seedLiveDatabase(): Promise<void> {
    if (!this.isLiveConnected || !this.graph) return;

    try {
      // Check if already seeded
      const countRes = await this.graph.query('MATCH (n) RETURN count(n) AS cnt');
      const count = countRes?.data?.[0]?.cnt || 0;
      if (count > 0) return; // Idempotent: already seeded

      // Create Brands
      for (const b of SEED_BRANDS) {
        await this.graph.query(
          `MERGE (b:Brand {id: $id})
           ON CREATE SET b.name = $name, b.classification = $classification,
           b.officialDomain = $officialDomain, b.industry = $industry, b.isSynthetic = true`,
          { params: b }
        );
      }

      // Create Campaigns
      for (const c of SEED_CAMPAIGNS) {
        await this.graph.query(
          `MERGE (c:Campaign {id: $id})
           ON CREATE SET c.label = $label, c.description = $description,
           c.status = $status, c.isSynthetic = true`,
          { params: c }
        );
      }

      // Create Indicators
      for (const ind of SEED_INDICATORS) {
        const query = ind.indicatorType === 'domain'
          ? `MERGE (i:Indicator:Domain {id: $id})
             ON CREATE SET i.value = $value, i.indicatorType = $indicatorType,
             i.displayValue = $displayValue, i.firstSeen = $firstSeen,
             i.riskWeight = $riskWeight, i.notes = $notes, i.isSynthetic = true`
          : `MERGE (i:Indicator {id: $id})
             ON CREATE SET i.value = $value, i.indicatorType = $indicatorType,
             i.displayValue = $displayValue, i.firstSeen = $firstSeen,
             i.riskWeight = $riskWeight, i.notes = $notes, i.isSynthetic = true`;
        await this.graph.query(query, { params: { ...ind, value: ind.value.toLowerCase() } });
      }

      // Create Evidence
      for (const e of SEED_EVIDENCE) {
        await this.graph.query(
          `MERGE (e:Evidence {id: $id})
           ON CREATE SET e.evidenceType = $evidenceType, e.description = $description,
           e.confidence = $confidence, e.sourceType = $sourceType, e.isSynthetic = true`,
          { params: e }
        );
      }

      // Create Incidents
      for (const inc of SEED_INCIDENTS) {
        await this.graph.query(
          `MERGE (i:Incident {id: $id})
           ON CREATE SET i.summary = $summary, i.category = $category,
           i.timestamp = $timestamp, i.severity = $severity,
           i.sourceType = $sourceType, i.victimCountEstimate = $victimCountEstimate, i.isSynthetic = true`,
          { params: inc }
        );
      }

      // Create Relationships
      for (const rel of SEED_RELATIONSHIPS) {
        const cypher = `
          MATCH (a {id: $fromId}), (b {id: $toId})
          MERGE (a)-[r:${rel.relType}]->(b)
        `;
        await this.graph.query(cypher, { params: { fromId: rel.fromId, toId: rel.toId } });
      }
    } catch (e) {
      console.error('Error seeding live FalkorDB:', e);
    }
  }

  // Parameterized Cypher query runner with automatic live FalkorDB fallback to memory graph
  public async query(cypher: string, params: Record<string, any> = {}): Promise<any> {
    if (this.isLiveConnected && this.graph) {
      try {
        return await this.graph.query(cypher, { params });
      } catch (err: any) {
        console.warn('Live FalkorDB query failed, falling back to memory graph:', err?.message);
      }
    }

    // In-memory query handler handles all defined query templates
    return null;
  }
}

export const falkorService = new FalkorDBService();
