import { extractEntities, ExtractionResult } from './entityExtraction';
import { graphQueries, InvestigationRecord } from './graphQueries';
import { calculateRiskScore, RiskAssessment } from './riskScoring';
import { reportService, StructuredInvestigationReport } from './reportService';
import { falkorService, GraphNode, GraphEdge, GraphPath } from './falkordb';

export interface AgentStepLog {
  step: 'STAGE_A_EXTRACTION' | 'STAGE_B_GRAPH_QUERY' | 'STAGE_C_RISK_SCORE' | 'STAGE_D_REPORT' | 'STAGE_E_MEMORY';
  title: string;
  durationMs: number;
  details: string;
  dataSummary: Record<string, any>;
}

export interface InvestigationResult {
  investigationId: string;
  timestamp: string;
  input: string;
  extraction: ExtractionResult;
  assessment: RiskAssessment;
  report: StructuredInvestigationReport;
  evidencePaths: GraphPath[];
  graphVisualization: {
    nodes: Array<{
      id: string;
      label: string;
      type: 'Brand' | 'Indicator' | 'Incident' | 'Campaign' | 'Evidence' | 'Unknown';
      properties: Record<string, any>;
      val: number; // size
      color: string;
    }>;
    links: Array<{
      source: string;
      target: string;
      label: string;
      properties: Record<string, any>;
      color?: string;
    }>;
  };
  connectedCampaigns: any[];
  executionLogs: AgentStepLog[];
  metrics: {
    totalDurationMs: number;
    graphQueriesExecuted: number;
    nodesTraversed: number;
    relationshipsDiscovered: number;
  };
}

export class ScamInvestigatorAgent {
  public async runInvestigation(text: string): Promise<InvestigationResult> {
    const startTime = Date.now();
    const logs: AgentStepLog[] = [];
    let queryCount = 0;
    const investigationId = `INV-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;

    // STAGE A: Input Analysis & Entity Extraction
    const t0 = Date.now();
    const extraction = extractEntities(text);
    logs.push({
      step: 'STAGE_A_EXTRACTION',
      title: 'Entity Extraction & Heuristic Normalization',
      durationMs: Date.now() - t0,
      details: `Extracted ${extraction.indicators.length} indicator(s), ${extraction.claimedBrands.length} claimed brand(s), ${extraction.urgencySignals.length} urgency signal(s).`,
      dataSummary: {
        indicators: extraction.indicators.map(i => `${i.type}:${i.value}`),
        claimedBrands: extraction.claimedBrands,
        urgency: extraction.hasUrgentRequest
      }
    });

    // STAGE B: Graph Investigation across FalkorDB
    const t1 = Date.now();

    // 1. Match Indicators & Brands
    queryCount++;
    const matchResult = await graphQueries.findMatchingIndicators(
      extraction.indicators.map(i => ({ value: i.value, type: i.type }))
    );

    // 2. Expand Related Entities up to 3 hops
    queryCount++;
    const matchedIds = matchResult.matchedNodes.map(n => n.id);
    const expansion = await graphQueries.expandRelatedEntities(matchedIds, 3);

    // 3. Find Related Incidents
    queryCount++;
    const incidentResult = await graphQueries.findRelatedIncidents(matchedIds);

    // 4. Discover Evidence Paths
    queryCount++;
    const evidencePaths = await graphQueries.findEvidencePaths(matchedIds);

    // 5. Campaign Cluster Discovery
    queryCount++;
    const campaignClusters = await graphQueries.findCampaignClusters(matchedIds);

    // Collect supporting evidence nodes
    const allEvidenceNodes = expansion.nodes.filter(n => n.labels.includes('Evidence'));

    // Check shared infrastructure
    const hasSharedInfra = expansion.edges.some(e => e.relType === 'LINKED_TO' && (e.properties.basis?.includes('SHARED') || e.properties.basis?.includes('DNS')));

    logs.push({
      step: 'STAGE_B_GRAPH_QUERY',
      title: 'FalkorDB Multi-Hop Graph Traversal',
      durationMs: Date.now() - t1,
      details: `Queried knowledge graph: matched ${matchResult.matchedNodes.length} indicator(s), traversed ${expansion.nodes.length} nodes across ${expansion.edges.length} relationships, discovered ${incidentResult.totalIncidents} incident(s) and ${campaignClusters.length} campaign cluster(s).`,
      dataSummary: {
        matchedIndicators: matchResult.matchedNodes.map(n => n.id),
        incidentsFound: incidentResult.incidents.map(i => i.id),
        evidenceFound: allEvidenceNodes.map(e => e.id),
        pathsFound: evidencePaths.length
      }
    });

    // STAGE C: Evidence-based Risk Assessment
    const t2 = Date.now();
    const assessment = calculateRiskScore({
      extraction,
      matchedIndicators: matchResult.matchedNodes,
      claimedBrands: matchResult.brands,
      relatedIncidents: incidentResult.incidents,
      evidenceNodes: allEvidenceNodes,
      hasSharedInfrastructure: hasSharedInfra
    });

    logs.push({
      step: 'STAGE_C_RISK_SCORE',
      title: 'Deterministic Risk & Confidence Scoring',
      durationMs: Date.now() - t2,
      details: `Calculated risk score ${assessment.riskScore}/100 (${assessment.riskLevel}) using 6 inspectable rules with ${assessment.evidenceConfidence}% confidence.`,
      dataSummary: {
        riskScore: assessment.riskScore,
        riskLevel: assessment.riskLevel,
        confidence: assessment.evidenceConfidence,
        coverage: assessment.evidenceCoverage
      }
    });

    // STAGE D: Grounded Investigation Report
    const t3 = Date.now();
    const report = await reportService.generateReport({
      investigationId,
      extraction,
      assessment,
      matchedIndicators: matchResult.matchedNodes,
      claimedBrands: matchResult.brands,
      relatedIncidents: incidentResult.incidents,
      evidenceNodes: allEvidenceNodes,
      paths: evidencePaths
    });

    logs.push({
      step: 'STAGE_D_REPORT',
      title: 'Structured Evidence-Grounded Report Synthesis',
      durationMs: Date.now() - t3,
      details: `Generated structured investigation report with ${report.findings.length} validated finding(s) and actionable defensive recommendations.`,
      dataSummary: {
        findingsCount: report.findings.length,
        verifiedEvidenceRefs: report.findings.flatMap(f => f.evidenceIds)
      }
    });

    // Format Graph Visualization Data
    const graphVisNodes: Array<{
      id: string;
      label: string;
      type: 'Brand' | 'Indicator' | 'Incident' | 'Campaign' | 'Evidence' | 'Unknown';
      properties: Record<string, any>;
      val: number;
      color: string;
    }> = [];

    const graphVisLinks: Array<{
      source: string;
      target: string;
      label: string;
      properties: Record<string, any>;
      color?: string;
    }> = [];

    // Color and size map
    const typeColorMap = {
      Brand: '#38BDF8', // sky blue
      Indicator: '#F43F5E', // rose red
      Incident: '#F59E0B', // amber
      Campaign: '#A855F7', // purple
      Evidence: '#10B981', // emerald
      Unknown: '#94A3B8'
    };

    const typeSizeMap = {
      Brand: 16,
      Indicator: 14,
      Incident: 12,
      Campaign: 20,
      Evidence: 10,
      Unknown: 8
    };

    // If no nodes found in graph, add a single placeholder node representing submitted input
    if (expansion.nodes.length === 0) {
      const displayVal = extraction.indicators[0]?.value || 'Submitted Input';
      graphVisNodes.push({
        id: 'node-unindexed-01',
        label: displayVal,
        type: 'Unknown',
        properties: { displayValue: displayVal, notes: 'Not found in FalkorDB graph intelligence.' },
        val: 12,
        color: '#64748B'
      });
    } else {
      for (const node of expansion.nodes) {
        let nodeType: 'Brand' | 'Indicator' | 'Incident' | 'Campaign' | 'Evidence' | 'Unknown' = 'Unknown';
        if (node.labels.includes('Brand')) nodeType = 'Brand';
        else if (node.labels.includes('Indicator') || node.labels.includes('Domain')) nodeType = 'Indicator';
        else if (node.labels.includes('Incident')) nodeType = 'Incident';
        else if (node.labels.includes('Campaign')) nodeType = 'Campaign';
        else if (node.labels.includes('Evidence')) nodeType = 'Evidence';

        const displayLabel = node.properties.displayValue ||
          node.properties.name ||
          node.properties.label ||
          node.properties.summary ||
          node.properties.description ||
          node.id;

        graphVisNodes.push({
          id: node.id,
          label: typeof displayLabel === 'string' && displayLabel.length > 32 ? displayLabel.substring(0, 30) + '...' : displayLabel,
          type: nodeType,
          properties: node.properties,
          val: typeSizeMap[nodeType] || 10,
          color: typeColorMap[nodeType] || '#94A3B8'
        });
      }

      for (const edge of expansion.edges) {
        graphVisLinks.push({
          source: edge.fromId,
          target: edge.toId,
          label: edge.relType,
          properties: edge.properties || {},
          color: edge.relType === 'LINKED_TO' ? '#2DD4BF' : '#475569'
        });
      }
    }

    // STAGE E: Persistent Memory - Store in FalkorDB and History
    const t4 = Date.now();
    const investigationRecord: InvestigationRecord = {
      id: investigationId,
      rawTextPreview: extraction.rawInputDigest,
      normalizedIndicators: extraction.indicators.map(i => ({ value: i.value, type: i.type })),
      riskScore: assessment.riskScore,
      riskLevel: assessment.riskLevel,
      evidenceConfidence: assessment.evidenceConfidence,
      evidenceCoverage: assessment.evidenceCoverage,
      summary: report.executiveSummary,
      findings: report.findings,
      evidencePaths,
      graphVisualization: {
        nodes: graphVisNodes,
        links: graphVisLinks
      },
      graphSnapshot: {
        nodes: graphVisNodes,
        links: graphVisLinks
      },
      matchedIndicatorIds: matchedIds,
      evidenceIds: allEvidenceNodes.map(e => e.id),
      timestamp: new Date().toISOString(),
      investigationId,
      input: text,
      extraction,
      assessment,
      report,
      connectedCampaigns: campaignClusters,
      executionLogs: logs,
      metrics: {
        totalDurationMs: 0,
        graphQueriesExecuted: queryCount,
        nodesTraversed: expansion.nodes.length,
        relationshipsDiscovered: expansion.edges.length
      }
    };

    await graphQueries.saveInvestigation(investigationRecord);

    logs.push({
      step: 'STAGE_E_MEMORY',
      title: 'Persistent Memory Sync to FalkorDB',
      durationMs: Date.now() - t4,
      details: `Persisted investigation ${investigationId} with ${matchedIds.length} indicator links and ${allEvidenceNodes.length} supporting evidence edges.`,
      dataSummary: {
        investigationId,
        savedToGraph: true
      }
    });

    const totalDurationMs = Date.now() - startTime;

    return {
      investigationId,
      timestamp: investigationRecord.timestamp,
      input: text,
      extraction,
      assessment,
      report,
      evidencePaths,
      graphVisualization: {
        nodes: graphVisNodes,
        links: graphVisLinks
      },
      connectedCampaigns: campaignClusters,
      executionLogs: logs,
      metrics: {
        totalDurationMs,
        graphQueriesExecuted: queryCount,
        nodesTraversed: expansion.nodes.length,
        relationshipsDiscovered: expansion.edges.length
      }
    };
  }

  /**
   * Recalculates risk score for counterfactual simulation ("What changes if this link is absent?")
   */
  public simulateCounterfactual(params: {
    extraction: ExtractionResult;
    matchedIndicatorIds: string[];
    excludedRuleIds: string[];
  }): RiskAssessment {
    const store = falkorService.memoryStore;
    const matchedIndicators = params.matchedIndicatorIds
      .map(id => store.getNode(id))
      .filter((n): n is GraphNode => Boolean(n));

    const claimedBrands = matchedIndicators.filter(n => n.labels.includes('Brand'));
    const evidenceNodes = matchedIndicators.flatMap(m =>
      store.getEdgesFrom(m.id)
        .filter(e => e.relType === 'SUPPORTED_BY')
        .map(e => store.getNode(e.toId))
        .filter((n): n is GraphNode => Boolean(n))
    );

    const relatedIncidents = matchedIndicators.flatMap(m =>
      store.getEdgesTo(m.id)
        .filter(e => e.relType === 'MENTIONS')
        .map(e => {
          const node = store.getNode(e.fromId);
          return node ? { ...node, connectingIndicatorId: m.id, direct: true } : null;
        })
        .filter((n): n is any => Boolean(n))
    );

    return calculateRiskScore({
      extraction: params.extraction,
      matchedIndicators,
      claimedBrands,
      relatedIncidents,
      evidenceNodes,
      hasSharedInfrastructure: matchedIndicators.some(m =>
        store.getEdgesConnected(m.id).some(e => e.relType === 'LINKED_TO')
      ),
      excludedRuleIds: params.excludedRuleIds
    });
  }
}

export const investigatorAgent = new ScamInvestigatorAgent();
