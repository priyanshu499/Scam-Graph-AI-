import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateRiskScore } from './riskScoring.ts';

test('calculateRiskScore returns INSUFFICIENT_EVIDENCE when indicators are unindexed', () => {
  const result = calculateRiskScore({
    extraction: {
      indicators: [{ value: 'unknown-portal.test', type: 'domain', rawText: 'unknown-portal.test', confidence: 0.9 }],
      claimedBrands: [],
      urgencySignals: [],
      hasUrgentRequest: false,
      hasCredentialRequest: false,
      hasPaymentRequest: false,
      rawInputDigest: 'unknown-portal.test'
    },
    matchedIndicators: [],
    claimedBrands: [],
    relatedIncidents: [],
    evidenceNodes: [],
    hasSharedInfrastructure: false
  });

  assert.equal(result.riskLevel, 'INSUFFICIENT_EVIDENCE');
  assert.equal(result.evidenceCoverage, 'INSUFFICIENT');
  assert.equal(result.riskScore, 0);
  assert.match(result.explanation, /absence of known indicators/i);
});

test('calculateRiskScore calculates high risk with multiple matched indicators and brand impersonation', () => {
  const result = calculateRiskScore({
    extraction: {
      indicators: [{ value: 'northstar-verify.test', type: 'domain', rawText: 'northstar-verify.test', confidence: 0.95 }],
      claimedBrands: ['Northstar Bank'],
      urgencySignals: [{ category: 'SUSPENSION_THREAT', matchedPhrase: 'suspended', weight: 10 }],
      hasUrgentRequest: true,
      hasCredentialRequest: true,
      hasPaymentRequest: false,
      rawInputDigest: 'Northstar Bank alert: verify at northstar-verify.test'
    },
    matchedIndicators: [
      {
        id: 'ind-ns-verify',
        labels: ['Indicator', 'Domain'],
        properties: { value: 'northstar-verify.test', riskWeight: 85, displayValue: 'northstar-verify.test' }
      }
    ],
    claimedBrands: [
      {
        id: 'brand-northstar',
        labels: ['Brand'],
        properties: { name: 'Northstar Bank', officialDomain: 'northstarbank.test' }
      }
    ],
    relatedIncidents: [
      {
        id: 'INC-2026-0801',
        labels: ['Incident'],
        properties: { severity: 'CRITICAL', summary: 'Phish incident' },
        connectingIndicatorId: 'ind-ns-verify',
        direct: true
      },
      {
        id: 'INC-2026-0809',
        labels: ['Incident'],
        properties: { severity: 'HIGH', summary: '2FA bypass' },
        connectingIndicatorId: 'ind-ns-verify',
        direct: false
      }
    ],
    evidenceNodes: [
      {
        id: 'EVD-101',
        labels: ['Evidence'],
        properties: { confidence: 0.95, evidenceType: 'PHISHING_KIT_SIGNATURE' }
      }
    ],
    hasSharedInfrastructure: true
  });

  assert.equal(result.riskLevel, 'HIGH_RISK');
  assert.equal(result.riskScore >= 70, true);
  assert.equal(result.evidenceCoverage, 'MODERATE');
  assert.equal(result.rules.find(r => r.ruleId === 'RULE_BRAND_IMPERSONATION')?.applied, true);
});

test('calculateRiskScore supports counterfactual simulation by excluding rules', () => {
  const baseParams = {
    extraction: {
      indicators: [{ value: 'northstar-verify.test', type: 'domain', rawText: 'northstar-verify.test', confidence: 0.95 }],
      claimedBrands: ['Northstar Bank'],
      urgencySignals: [{ category: 'SUSPENSION_THREAT', matchedPhrase: 'suspended', weight: 10 }],
      hasUrgentRequest: true,
      hasCredentialRequest: true,
      hasPaymentRequest: false,
      rawInputDigest: 'alert'
    },
    matchedIndicators: [
      {
        id: 'ind-ns-verify',
        labels: ['Indicator', 'Domain'],
        properties: { value: 'northstar-verify.test', riskWeight: 85 }
      }
    ],
    claimedBrands: [
      {
        id: 'brand-northstar',
        labels: ['Brand'],
        properties: { name: 'Northstar Bank', officialDomain: 'northstarbank.test' }
      }
    ],
    relatedIncidents: [
      {
        id: 'INC-1',
        labels: ['Incident'],
        properties: { severity: 'HIGH' },
        connectingIndicatorId: 'ind-ns-verify',
        direct: true
      }
    ],
    evidenceNodes: [],
    hasSharedInfrastructure: false
  };

  const initial = calculateRiskScore(baseParams);
  const counterfactual = calculateRiskScore({
    ...baseParams,
    excludedRuleIds: ['RULE_INDICATOR_MATCH', 'RULE_BRAND_IMPERSONATION']
  });

  assert.equal(counterfactual.riskScore < initial.riskScore, true);
  assert.equal(initial.riskScore - counterfactual.riskScore, 45); // 25 + 20
});
