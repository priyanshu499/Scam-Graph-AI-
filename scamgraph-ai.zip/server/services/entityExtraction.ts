export interface ExtractedEntity {
  value: string;
  type: 'domain' | 'url' | 'phone' | 'payment_handle' | 'email' | 'brand';
  rawText: string;
  confidence: number;
}

export interface ExtractedUrgencySignal {
  category: 'SUSPENSION_THREAT' | 'CREDENTIAL_HARVEST' | 'FEE_PAYMENT' | 'JOB_DEPOSIT' | 'URGENCY_DEADLINE';
  matchedPhrase: string;
  weight: number;
}

export interface ExtractionResult {
  indicators: ExtractedEntity[];
  claimedBrands: string[];
  urgencySignals: ExtractedUrgencySignal[];
  hasUrgentRequest: boolean;
  hasCredentialRequest: boolean;
  hasPaymentRequest: boolean;
  rawInputDigest: string;
}

const BRAND_PATTERNS = [
  { name: 'Northstar Bank', regex: /\b(northstar\s*bank|northstar)\b/i },
  { name: 'SwiftDrop Logistics', regex: /\b(swiftdrop\s*logistics|swiftdrop)\b/i },
  { name: 'Apex Global Careers', regex: /\b(apex\s*global\s*careers|apex\s*careers|apex\s*global)\b/i },
  { name: 'Vertex Pay', regex: /\b(vertex\s*pay|vertexpay)\b/i },
  { name: 'CloudShield Security', regex: /\b(cloudshield\s*security|cloudshield)\b/i }
];

const URGENCY_TRIGGERS: Array<{ category: ExtractedUrgencySignal['category']; regex: RegExp; weight: number }> = [
  { category: 'SUSPENSION_THREAT', regex: /\b(suspended|locked|terminated|disabled|freeze|closed|action\s+required)\b/i, weight: 10 },
  { category: 'CREDENTIAL_HARVEST', regex: /\b(verify\s+(?:my\s+|your\s+)?(?:identity|account|credentials|security|login)|login\s+to\s+confirm|passcode|otp|password|pin)\b/i, weight: 10 },
  { category: 'FEE_PAYMENT', regex: /\b(delivery\s+fee|customs\s+fee|redelivery\s+charge|pay\s+\$?\d+|unpaid\s+fee|release\s+fee|handling\s+fee|\$\d+\s+fee)\b/i, weight: 10 },
  { category: 'JOB_DEPOSIT', regex: /\b(deposit|starter\s+kit|equipment\s+deposit|task\s+fee|crypto\s+transfer|wire\s+deposit|reimbursement)\b/i, weight: 10 },
  { category: 'URGENCY_DEADLINE', regex: /\b(immediately|within\s+\d+\s+hours|24\s+hours|urgent|final\s+notice)\b/i, weight: 8 }
];

export function normalizeIndicator(val: string, type: string): string {
  const trimmed = val.trim();
  if (type === 'domain' || type === 'url') {
    return trimmed
      .toLowerCase()
      .replace(/^https?:\/\//i, '')
      .replace(/^www\./i, '')
      .replace(/\/+$/, '');
  }
  if (type === 'phone') {
    // Standardize digits
    const digits = trimmed.replace(/\D/g, '');
    if (digits.length === 10) {
      return `+1-${digits.slice(0, 3)}-${digits.slice(3, 6)}-${digits.slice(6)}`;
    }
    if (digits.length === 11 && digits.startsWith('1')) {
      return `+1-${digits.slice(1, 4)}-${digits.slice(4, 7)}-${digits.slice(7)}`;
    }
    return trimmed.replace(/\s+/g, '-');
  }
  if (type === 'payment_handle') {
    return trimmed.toLowerCase().startsWith('$') ? trimmed.toLowerCase() : `$${trimmed.toLowerCase().replace(/^@/, '')}`;
  }
  if (type === 'email') {
    return trimmed.toLowerCase();
  }
  return trimmed.toLowerCase();
}

export function extractEntities(text: string): ExtractionResult {
  const indicators: ExtractedEntity[] = [];
  const claimedBrands: string[] = [];
  const urgencySignals: ExtractedUrgencySignal[] = [];

  if (!text || typeof text !== 'string') {
    return {
      indicators: [],
      claimedBrands: [],
      urgencySignals: [],
      hasUrgentRequest: false,
      hasCredentialRequest: false,
      hasPaymentRequest: false,
      rawInputDigest: ''
    };
  }

  // 1. Extract URLs and Domains
  const urlRegex = /\b(?:https?:\/\/|www\.)[a-z0-9-]+(?:\.[a-z0-9-]+)+(?:\/[^\s<>'"]*)?/gi;
  const domainRegex = /\b([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.(?:test|com|net|org|io|xyz|info|top|site|online|app|vip|link|biz))(?:\/[^\s<>'"]*)?/gi;

  const urlMatches = text.match(urlRegex) || [];
  for (const m of urlMatches) {
    const norm = normalizeIndicator(m, 'url');
    indicators.push({
      value: norm,
      type: norm.includes('/') ? 'url' : 'domain',
      rawText: m,
      confidence: 0.95
    });
  }

  const domainMatches = text.match(domainRegex) || [];
  for (const m of domainMatches) {
    const norm = normalizeIndicator(m, 'domain');
    // If not already included
    if (!indicators.some(i => i.value === norm)) {
      indicators.push({
        value: norm,
        type: norm.includes('/') ? 'url' : 'domain',
        rawText: m,
        confidence: 0.90
      });
    }
  }

  // 2. Extract Phone Numbers
  const phoneRegex = /(?:\+?1[-.\s]?)?\(?[2-9]\d{2}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b/g;
  const phoneMatches = text.match(phoneRegex) || [];
  for (const p of phoneMatches) {
    const norm = normalizeIndicator(p, 'phone');
    if (!indicators.some(i => i.value === norm)) {
      indicators.push({
        value: norm,
        type: 'phone',
        rawText: p,
        confidence: 0.90
      });
    }
  }

  // 3. Extract Payment Handles & Crypto Addresses
  // Cashtag or handle: $username or @username
  const handleRegex = /(?:\$|@)[a-zA-Z0-9_-]{3,25}\b/g;
  const handleMatches = text.match(handleRegex) || [];
  for (const h of handleMatches) {
    const norm = normalizeIndicator(h, 'payment_handle');
    indicators.push({
      value: norm,
      type: 'payment_handle',
      rawText: h,
      confidence: 0.90
    });
  }

  // Crypto hex addresses: 0x[a-fA-F0-9]{16,42}
  const cryptoRegex = /\b0x[a-fA-F0-9]{16,42}\b/g;
  const cryptoMatches = text.match(cryptoRegex) || [];
  for (const c of cryptoMatches) {
    const norm = `crypto:${c.toLowerCase()}`;
    indicators.push({
      value: norm,
      type: 'payment_handle',
      rawText: c,
      confidence: 0.95
    });
  }

  // 4. Extract Emails
  const emailRegex = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g;
  const emailMatches = text.match(emailRegex) || [];
  for (const em of emailMatches) {
    const norm = normalizeIndicator(em, 'email');
    if (!indicators.some(i => i.value === norm)) {
      indicators.push({
        value: norm,
        type: 'email',
        rawText: em,
        confidence: 0.92
      });
    }
  }

  // 5. Brand matching
  for (const b of BRAND_PATTERNS) {
    if (b.regex.test(text)) {
      claimedBrands.push(b.name);
    }
  }

  // 6. Urgency and Threat Analysis
  for (const u of URGENCY_TRIGGERS) {
    const match = text.match(u.regex);
    if (match) {
      urgencySignals.push({
        category: u.category,
        matchedPhrase: match[0],
        weight: u.weight
      });
    }
  }

  // Deduplicate indicators by value
  const uniqueIndicators = Array.from(new Map(indicators.map(i => [i.value, i])).values());

  const hasUrgentRequest = urgencySignals.some(u => u.category === 'SUSPENSION_THREAT' || u.category === 'URGENCY_DEADLINE');
  const hasCredentialRequest = urgencySignals.some(u => u.category === 'CREDENTIAL_HARVEST');
  const hasPaymentRequest = urgencySignals.some(u => u.category === 'FEE_PAYMENT' || u.category === 'JOB_DEPOSIT');

  // Redacted summary/digest
  const rawInputDigest = text.length > 120 ? text.substring(0, 117) + '...' : text;

  return {
    indicators: uniqueIndicators,
    claimedBrands,
    urgencySignals,
    hasUrgentRequest,
    hasCredentialRequest,
    hasPaymentRequest,
    rawInputDigest
  };
}
