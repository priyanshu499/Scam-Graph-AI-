import { falkorService, GraphNode, GraphEdge, GraphPath } from './falkordb';

export interface InvestigationRecord {
  id: string;
  rawTextPreview: string;
  normalizedIndicators: Array<{ value: string; type: string }>;
  riskScore: number;
  riskLevel: 'HIGH_RISK' | 'NEEDS_CAUTION' | 'INSUFFICIENT_EVIDENCE' | 'LOW_RISK';
  evidenceConfidence: number;
  evidenceCoverage: 'HIGH' | 'MODERATE' | 'LOW' | 'INSUFFICIENT';
  summary: string;
  findings: Array<{
    id: string;
    title: string;
    description: string;
    evidenceIds: string[];
    severity: string;
  }>;
  evidencePaths: GraphPath[];
  graphVisualization: {
    nodes: any[];
    links: any[];
  };
  graphSnapshot?: {
    nodes: any[];
    links: any[];
  };
  matchedIndicatorIds: string[];
  evidenceIds: string[];
  timestamp: string;
  input?: string;
  investigationId?: string;
  extraction?: any;
  assessment?: any;
  report?: any;
  connectedCampaigns?: any[];
  executionLogs?: any[];
  metrics?: any;
  feedback?: {
    verdict: 'CONFIRMED_FRAUD' | 'NEEDS_REVIEW' | 'FALSE_POSITIVE';
    note?: string;
    timestamp: string;
  };
}

export interface GraphStatistics {
  nodeCount: number;
  edgeCount: number;
  indicatorCount: number;
  incidentCount: number;
  campaignCount: number;
  evidenceCount: number;
  brandCount: number;
  investigationCount: number;
  feedbackCount: number;
  activeCampaigns: string[];
  isLiveDb: boolean;
}

// In-memory persistent history store (synced with Graph)
const savedInvestigations: Map<string, InvestigationRecord> = new Map();

export const graphQueries = {
  /**
   * Find indicators and brands matching extracted values
   */
  async findMatchingIndicators(extracted: Array<{ value: string; type: string }>): Promise<{
    matchedNodes: GraphNode[];
    brands: GraphNode[];
    unmatchedValues: string[];
  }> {
    const store = falkorService.memoryStore;
    const matchedNodes: GraphNode[] = [];
    const brands: GraphNode[] = [];
    const matchedValues = new Set<string>();

    for (const item of extracted) {
      const cleanVal = item.value.trim().toLowerCase();

      // Search Indicator nodes
      for (const node of store.nodes.values()) {
        if (node.labels.includes('Indicator') || node.labels.includes('Domain')) {
          const nodeVal = String(node.properties.value || '').toLowerCase();
          const nodeDisplay = String(node.properties.displayValue || '').toLowerCase();

          // Check direct match, substring match, or domain matching
          if (
            nodeVal === cleanVal ||
            cleanVal.includes(nodeVal) ||
            nodeVal.includes(cleanVal) ||
            nodeDisplay.includes(cleanVal)
          ) {
            matchedNodes.push(node);
            matchedValues.add(item.value);
          }
        } else if (node.labels.includes('Brand')) {
          const brandName = String(node.properties.name || '').toLowerCase();
          const offDomain = String(node.properties.officialDomain || '').toLowerCase();
          if (
            brandName === cleanVal ||
            brandName.includes(cleanVal) ||
            cleanVal.includes(brandName) ||
            cleanVal.includes(offDomain)
          ) {
            brands.push(node);
            matchedValues.add(item.value);
          }
        }
      }
    }

    // Deduplicate
    const uniqueMatched = Array.from(new Map(matchedNodes.map(n => [n.id, n])).values());
    const uniqueBrands = Array.from(new Map(brands.map(b => [b.id, b])).values());
    const unmatchedValues = extracted
      .filter(e => !matchedValues.has(e.value))
      .map(e => e.value);

    return {
      matchedNodes: uniqueMatched,
      brands: uniqueBrands,
      unmatchedValues
    };
  },

  /**
   * Expand related entities up to bounded hops (default 3)
   */
  async expandRelatedEntities(
    startNodeIds: string[],
    maxHops: number = 3
  ): Promise<{
    nodes: GraphNode[];
    edges: GraphEdge[];
    depths: Record<string, number>;
  }> {
    const store = falkorService.memoryStore;
    const visitedNodes = new Set<string>();
    const collectedEdges = new Map<string, GraphEdge>();
    const nodeDepths: Record<string, number> = {};

    let currentFrontier = new Set<string>();
    for (const id of startNodeIds) {
      if (store.getNode(id)) {
        visitedNodes.add(id);
        currentFrontier.add(id);
        nodeDepths[id] = 0;
      }
    }

    for (let hop = 1; hop <= maxHops; hop++) {
      const nextFrontier = new Set<string>();

      for (const nodeId of currentFrontier) {
        const connectedEdges = store.getEdgesConnected(nodeId);

        for (const edge of connectedEdges) {
          collectedEdges.set(edge.id, edge);
          const neighborId = edge.fromId === nodeId ? edge.toId : edge.fromId;

          if (!visitedNodes.has(neighborId)) {
            const neighborNode = store.getNode(neighborId);
            if (neighborNode) {
              visitedNodes.add(neighborId);
              nextFrontier.add(neighborId);
              nodeDepths[neighborId] = hop;
            }
          }
        }
      }

      currentFrontier = nextFrontier;
      if (currentFrontier.size === 0) break;
    }

    const nodes = Array.from(visitedNodes)
      .map(id => store.getNode(id))
      .filter((n): n is GraphNode => Boolean(n));

    return {
      nodes,
      edges: Array.from(collectedEdges.values()),
      depths: nodeDepths
    };
  },

  /**
   * Find incidents sharing indicators or infrastructure
   */
  async findRelatedIncidents(indicatorIds: string[]): Promise<{
    incidents: Array<GraphNode & { connectingIndicatorId: string; direct: boolean }>;
    totalIncidents: number;
    categories: string[];
    maxSeverity: string;
  }> {
    const store = falkorService.memoryStore;
    const incidentsMap = new Map<string, GraphNode & { connectingIndicatorId: string; direct: boolean }>();
    const categoriesSet = new Set<string>();

    for (const indId of indicatorIds) {
      // Direct incident mentions
      const toEdges = store.getEdgesTo(indId);
      for (const edge of toEdges) {
        if (edge.relType === 'MENTIONS') {
          const incNode = store.getNode(edge.fromId);
          if (incNode && incNode.labels.includes('Incident')) {
            incidentsMap.set(incNode.id, {
              ...incNode,
              connectingIndicatorId: indId,
              direct: true
            });
            if (incNode.properties.category) categoriesSet.add(incNode.properties.category);
          }
        }
      }

      // Check 2-hop infrastructure links (e.g., Indicator -> LINKED_TO -> Shared Host -> Incident)
      const linkedEdges = store.getEdgesConnected(indId);
      for (const linkEdge of linkedEdges) {
        if (linkEdge.relType === 'LINKED_TO') {
          const intermediateId = linkEdge.fromId === indId ? linkEdge.toId : linkEdge.fromId;
          const intermediateEdges = store.getEdgesTo(intermediateId);
          for (const iEdge of intermediateEdges) {
            if (iEdge.relType === 'MENTIONS') {
              const incNode = store.getNode(iEdge.fromId);
              if (incNode && incNode.labels.includes('Incident') && !incidentsMap.has(incNode.id)) {
                incidentsMap.set(incNode.id, {
                  ...incNode,
                  connectingIndicatorId: intermediateId,
                  direct: false
                });
                if (incNode.properties.category) categoriesSet.add(incNode.properties.category);
              }
            }
          }
        }
      }
    }

    const incidents = Array.from(incidentsMap.values());
    const severities = incidents.map(i => i.properties.severity);
    const maxSeverity = severities.includes('CRITICAL')
      ? 'CRITICAL'
      : severities.includes('HIGH')
      ? 'HIGH'
      : severities.includes('MEDIUM')
      ? 'MEDIUM'
      : 'LOW';

    return {
      incidents,
      totalIncidents: incidents.length,
      categories: Array.from(categoriesSet),
      maxSeverity
    };
  },

  /**
   * Find explainable relationship paths linking source indicators to campaigns and evidence
   */
  async findEvidencePaths(sourceIndicatorIds: string[]): Promise<GraphPath[]> {
    const store = falkorService.memoryStore;
    const paths: GraphPath[] = [];

    for (const startId of sourceIndicatorIds) {
      const startNode = store.getNode(startId);
      if (!startNode) continue;

      // Path A: Indicator -> Incident -> Campaign
      const mentionsEdges = store.getEdgesTo(startId).filter(e => e.relType === 'MENTIONS');
      for (const mEdge of mentionsEdges) {
        const incidentNode = store.getNode(mEdge.fromId);
        if (incidentNode && incidentNode.labels.includes('Incident')) {
          const partOfEdges = store.getEdgesFrom(incidentNode.id).filter(e => e.relType === 'PART_OF');
          for (const pEdge of partOfEdges) {
            const campNode = store.getNode(pEdge.toId);
            if (campNode) {
              paths.push({
                nodes: [startNode, incidentNode, campNode],
                edges: [mEdge, pEdge],
                summary: `${startNode.properties.displayValue || startNode.properties.value} is linked to ${incidentNode.id} ("${incidentNode.properties.summary}"), part of ${campNode.properties.label}`
              });
            }
          }
        }
      }

      // Path B: Indicator -> LINKED_TO -> Host / Infrastructure -> Incident -> Campaign
      const linkEdges = store.getEdgesConnected(startId).filter(e => e.relType === 'LINKED_TO');
      for (const lEdge of linkEdges) {
        const targetId = lEdge.fromId === startId ? lEdge.toId : lEdge.fromId;
        const targetNode = store.getNode(targetId);
        if (!targetNode) continue;

        const intermediateMentions = store.getEdgesTo(targetId).filter(e => e.relType === 'MENTIONS');
        for (const mEdge of intermediateMentions) {
          const incidentNode = store.getNode(mEdge.fromId);
          if (incidentNode) {
            const partOfEdges = store.getEdgesFrom(incidentNode.id).filter(e => e.relType === 'PART_OF');
            for (const pEdge of partOfEdges) {
              const campNode = store.getNode(pEdge.toId);
              if (campNode) {
                paths.push({
                  nodes: [startNode, targetNode, incidentNode, campNode],
                  edges: [lEdge, mEdge, pEdge],
                  summary: `${startNode.properties.displayValue || startNode.properties.value} shares infrastructure (${targetNode.properties.displayValue || targetNode.properties.value}) with ${incidentNode.id}, attributed to ${campNode.properties.label}`
                });
              }
            }
          }
        }
      }

      // Path C: Indicator -> SUPPORTED_BY -> Evidence
      const evdEdges = store.getEdgesFrom(startId).filter(e => e.relType === 'SUPPORTED_BY');
      for (const eEdge of evdEdges) {
        const evdNode = store.getNode(eEdge.toId);
        if (evdNode) {
          paths.push({
            nodes: [startNode, evdNode],
            edges: [eEdge],
            summary: `${startNode.properties.displayValue || startNode.properties.value} corroborated by evidence ${evdNode.id} (${evdNode.properties.evidenceType}): ${evdNode.properties.description}`
          });
        }
      }
    }

    // Limit and deduplicate paths
    const uniquePaths: GraphPath[] = [];
    const seenSummaries = new Set<string>();
    for (const p of paths) {
      if (!seenSummaries.has(p.summary)) {
        seenSummaries.add(p.summary);
        uniquePaths.push(p);
      }
    }

    return uniquePaths.slice(0, 8);
  },

  /**
   * Find campaign clusters connected to the indicators
   */
  async findCampaignClusters(indicatorIds: string[]): Promise<Array<{
    campaign: GraphNode;
    incidentCount: number;
    indicators: GraphNode[];
    sharedInfrastructure: string[];
  }>> {
    const store = falkorService.memoryStore;
    const campaignMap = new Map<string, {
      campaign: GraphNode;
      incidentIds: Set<string>;
      indicatorNodes: Map<string, GraphNode>;
      sharedInfra: Set<string>;
    }>();

    for (const indId of indicatorIds) {
      const indNode = store.getNode(indId);
      if (!indNode) continue;

      // Direct incidents
      const mentions = store.getEdgesTo(indId).filter(e => e.relType === 'MENTIONS');
      for (const m of mentions) {
        const partOf = store.getEdgesFrom(m.fromId).filter(e => e.relType === 'PART_OF');
        for (const p of partOf) {
          const campNode = store.getNode(p.toId);
          if (!campNode) continue;

          if (!campaignMap.has(campNode.id)) {
            campaignMap.set(campNode.id, {
              campaign: campNode,
              incidentIds: new Set(),
              indicatorNodes: new Map(),
              sharedInfra: new Set()
            });
          }
          const entry = campaignMap.get(campNode.id)!;
          entry.incidentIds.add(m.fromId);
          entry.indicatorNodes.set(indNode.id, indNode);
        }
      }

      // Check linked infrastructure
      const linked = store.getEdgesConnected(indId).filter(e => e.relType === 'LINKED_TO');
      for (const l of linked) {
        const otherId = l.fromId === indId ? l.toId : l.fromId;
        const otherNode = store.getNode(otherId);
        if (otherNode) {
          const otherMentions = store.getEdgesTo(otherId).filter(e => e.relType === 'MENTIONS');
          for (const om of otherMentions) {
            const partOf = store.getEdgesFrom(om.fromId).filter(e => e.relType === 'PART_OF');
            for (const p of partOf) {
              const campNode = store.getNode(p.toId);
              if (!campNode) continue;

              if (!campaignMap.has(campNode.id)) {
                campaignMap.set(campNode.id, {
                  campaign: campNode,
                  incidentIds: new Set(),
                  indicatorNodes: new Map(),
                  sharedInfra: new Set()
                });
              }
              const entry = campaignMap.get(campNode.id)!;
              entry.incidentIds.add(om.fromId);
              entry.indicatorNodes.set(indNode.id, indNode);
              entry.sharedInfra.add(otherNode.properties.displayValue || otherNode.properties.value);
            }
          }
        }
      }
    }

    return Array.from(campaignMap.values()).map(item => ({
      campaign: item.campaign,
      incidentCount: item.incidentIds.size,
      indicators: Array.from(item.indicatorNodes.values()),
      sharedInfrastructure: Array.from(item.sharedInfra)
    }));
  },

  /**
   * Save investigation record to FalkorDB and persistent memory
   */
  async saveInvestigation(record: InvestigationRecord): Promise<void> {
    const store = falkorService.memoryStore;
    savedInvestigations.set(record.id, record);

    // Add Investigation node to graph
    store.addNode({
      id: record.id,
      labels: ['Investigation'],
      properties: {
        rawTextPreview: record.rawTextPreview,
        riskScore: record.riskScore,
        riskLevel: record.riskLevel,
        evidenceConfidence: record.evidenceConfidence,
        evidenceCoverage: record.evidenceCoverage,
        summary: record.summary,
        timestamp: record.timestamp,
        isSynthetic: true
      }
    });

    // Add FOUND links to matched indicators
    for (const indId of record.matchedIndicatorIds) {
      store.addEdge({
        id: `rel-${record.id}-FOUND-${indId}`,
        fromId: record.id,
        toId: indId,
        relType: 'FOUND',
        properties: { timestamp: record.timestamp }
      });
    }

    // Add SUPPORTED_BY links to evidence
    for (const evdId of record.evidenceIds) {
      store.addEdge({
        id: `rel-${record.id}-SUPPORTED_BY-${evdId}`,
        fromId: record.id,
        toId: evdId,
        relType: 'SUPPORTED_BY',
        properties: { timestamp: record.timestamp }
      });
    }

    // Also persist into live FalkorDB if connected
    if (falkorService.getStatus().connected) {
      try {
        await falkorService.query(
          `MERGE (inv:Investigation {id: $id})
           ON CREATE SET inv.rawTextPreview = $preview, inv.riskScore = $score,
           inv.riskLevel = $riskLevel, inv.timestamp = $timestamp, inv.isSynthetic = true`,
          {
            id: record.id,
            preview: record.rawTextPreview,
            score: record.riskScore,
            riskLevel: record.riskLevel,
            timestamp: record.timestamp
          }
        );
      } catch (e) {
        console.error('Error saving investigation to live FalkorDB:', e);
      }
    }
  },

  /**
   * Retrieve list of past investigations from FalkorDB / Graph
   */
  async getInvestigationHistory(limit: number = 50): Promise<InvestigationRecord[]> {
    const list = Array.from(savedInvestigations.values());
    list.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    return list.slice(0, limit);
  },

  /**
   * Get single investigation by ID
   */
  async getInvestigationById(id: string): Promise<InvestigationRecord | null> {
    return savedInvestigations.get(id) || null;
  },

  /**
   * Save analyst feedback for an investigation
   */
  async saveAnalystFeedback(
    investigationId: string,
    verdict: 'CONFIRMED_FRAUD' | 'NEEDS_REVIEW' | 'FALSE_POSITIVE',
    note?: string
  ): Promise<boolean> {
    const investigation = savedInvestigations.get(investigationId);
    if (!investigation) return false;

    const feedback = {
      verdict,
      note: note || '',
      timestamp: new Date().toISOString()
    };

    investigation.feedback = feedback;
    savedInvestigations.set(investigationId, investigation);

    const store = falkorService.memoryStore;
    const feedbackNodeId = `fb-${investigationId}`;
    store.addNode({
      id: feedbackNodeId,
      labels: ['AnalystFeedback'],
      properties: {
        verdict,
        note: note || '',
        timestamp: feedback.timestamp
      }
    });

    store.addEdge({
      id: `rel-${feedbackNodeId}-REVIEWS-${investigationId}`,
      fromId: feedbackNodeId,
      toId: investigationId,
      relType: 'REVIEWS',
      properties: { timestamp: feedback.timestamp }
    });

    // Also persist into live FalkorDB if connected
    if (falkorService.getStatus().connected) {
      try {
        await falkorService.query(
          `MERGE (fb:AnalystFeedback {id: $id})
           ON CREATE SET fb.verdict = $verdict, fb.note = $note, fb.timestamp = $timestamp
           WITH fb
           MATCH (inv:Investigation {id: $invId})
           MERGE (fb)-[:REVIEWS]->(inv)`,
          {
            id: feedbackNodeId,
            verdict,
            note: note || '',
            timestamp: feedback.timestamp,
            invId: investigationId
          }
        );
      } catch (e) {
        console.error('Error saving feedback to live FalkorDB:', e);
      }
    }

    return true;
  },

  /**
   * Get real graph statistics
   */
  async getGraphStatistics(): Promise<GraphStatistics> {
    const store = falkorService.memoryStore;
    let indicatorCount = 0;
    let incidentCount = 0;
    let campaignCount = 0;
    let evidenceCount = 0;
    let brandCount = 0;
    let investigationCount = 0;
    let feedbackCount = 0;
    const activeCampaigns: string[] = [];

    for (const node of store.nodes.values()) {
      if (node.labels.includes('Indicator')) indicatorCount++;
      if (node.labels.includes('Incident')) incidentCount++;
      if (node.labels.includes('Evidence')) evidenceCount++;
      if (node.labels.includes('Brand')) brandCount++;
      if (node.labels.includes('Investigation')) investigationCount++;
      if (node.labels.includes('AnalystFeedback')) feedbackCount++;
      if (node.labels.includes('Campaign')) {
        campaignCount++;
        if (node.properties.status === 'ACTIVE') {
          activeCampaigns.push(node.properties.label);
        }
      }
    }

    return {
      nodeCount: store.nodes.size,
      edgeCount: store.edges.size,
      indicatorCount,
      incidentCount,
      campaignCount,
      evidenceCount,
      brandCount,
      investigationCount,
      feedbackCount,
      activeCampaigns,
      isLiveDb: falkorService.getStatus().connected
    };
  }
};
