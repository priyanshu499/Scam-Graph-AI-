import { GoogleGenAI } from '@google/genai';
import OpenAI from 'openai';
import { ExtractionResult } from './entityExtraction';
import { RiskAssessment } from './riskScoring';
import { GraphNode, GraphPath } from './falkordb';

export interface StructuredInvestigationReport {
  investigationId: string;
  timestamp: string;
  executiveSummary: string;
  riskAssessmentExplanation: string;
  matchedIndicators: string[];
  findings: Array<{
    id: string;
    title: string;
    description: string;
    evidenceIds: string[];
    severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';
  }>;
  connectedIncidentSummaries: string[];
  relationshipPathExplanations: string[];
  uncertaintiesAndLimitations: string[];
  recommendedNextSteps: string[];
  syntheticDisclaimer: string;
}

export class ReportService {
  private geminiClient: GoogleGenAI | null = null;
  private openaiClient: OpenAI | null = null;

  constructor() {
    if (process.env.GEMINI_API_KEY) {
      this.geminiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    }
    if (process.env.OPENAI_API_KEY) {
      this.openaiClient = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY,
        baseURL: process.env.OPENAI_BASE_URL || undefined
      });
    }
  }

  public async generateReport(params: {
    investigationId: string;
    extraction: ExtractionResult;
    assessment: RiskAssessment;
    matchedIndicators: GraphNode[];
    claimedBrands: GraphNode[];
    relatedIncidents: Array<GraphNode & { connectingIndicatorId: string; direct: boolean }>;
    evidenceNodes: GraphNode[];
    paths: GraphPath[];
  }): Promise<StructuredInvestigationReport> {
    const {
      investigationId,
      extraction,
      assessment,
      matchedIndicators,
      claimedBrands,
      relatedIncidents,
      evidenceNodes,
      paths
    } = params;

    const validEvidenceIds = new Set(evidenceNodes.map(e => e.id));

    // Case 1: Insufficient Evidence (Unknown indicator)
    if (assessment.riskLevel === 'INSUFFICIENT_EVIDENCE') {
      return this.generateInsufficientEvidenceReport(investigationId, extraction, assessment);
    }

    // Attempt LLM generation if Gemini or OpenAI client is configured
    try {
      if (this.geminiClient) {
        return await this.generateWithGemini(params, validEvidenceIds);
      }
      if (this.openaiClient) {
        return await this.generateWithOpenAI(params, validEvidenceIds);
      }
    } catch (err: any) {
      console.warn('LLM report generation failed or timed out, using deterministic evidence report:', err?.message);
    }

    // Default: Grounded deterministic report
    return this.generateDeterministicReport(params, validEvidenceIds);
  }

  private generateInsufficientEvidenceReport(
    id: string,
    extraction: ExtractionResult,
    assessment: RiskAssessment
  ): StructuredInvestigationReport {
    return {
      investigationId: id,
      timestamp: new Date().toISOString(),
      executiveSummary:
        'Investigation inconclusive due to absence of graph records. Submitted indicators were not found in the FalkorDB threat intelligence knowledge graph. This is NOT an assurance of safety.',
      riskAssessmentExplanation:
        'Because the submitted entities have zero associated incidents or infrastructure links in the graph database, evidence coverage is categorized as INSUFFICIENT. A low numerical score in this context denotes absence of data rather than validated benign reputation.',
      matchedIndicators: [],
      findings: [
        {
          id: 'FINDING-UNKNOWN-01',
          title: 'Unindexed Indicators in Knowledge Graph',
          description: `Extracted indicators (${extraction.indicators.map(i => i.value).join(', ') || 'Submitted text'}) have no known history in the FalkorDB database. Zero technical links or campaign associations discovered.`,
          evidenceIds: [],
          severity: 'INFO'
        }
      ],
      connectedIncidentSummaries: [],
      relationshipPathExplanations: [
        'No multi-hop traversal paths could be formed due to absence of seed nodes.'
      ],
      uncertaintiesAndLimitations: [
        'Graph coverage is bounded to known synthetic threat intelligence records.',
        'Absence of an indicator in this database does not verify that the communication is genuine.',
        'Newly registered scam infrastructure often lacks pre-existing intelligence reports.'
      ],
      recommendedNextSteps: [
        'Do not click embedded links or download attachments from unsolicited messages.',
        'Contact the purported organization directly using contact information from their official website or billing statement.',
        'Never submit passwords, one-time passcodes (OTPs), or payment card details on unverified pages.'
      ],
      syntheticDisclaimer: assessment.disclaimer
    };
  }

  private async generateWithGemini(
    params: any,
    validEvidenceIds: Set<string>
  ): Promise<StructuredInvestigationReport> {
    const prompt = this.buildPrompt(params);

    const response = await this.geminiClient!.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json'
      }
    });

    const text = response.text || '{}';
    const parsed = JSON.parse(text);
    return this.sanitizeAndValidateReport(parsed, params, validEvidenceIds);
  }

  private async generateWithOpenAI(
    params: any,
    validEvidenceIds: Set<string>
  ): Promise<StructuredInvestigationReport> {
    const prompt = this.buildPrompt(params);

    const completion = await this.openaiClient!.chat.completions.create({
      model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
      messages: [
        {
          role: 'system',
          content: 'You are an explainable fraud investigation engine. Return only structured JSON matching the requested schema. Ground every finding strictly in the provided evidence without inventing facts.'
        },
        { role: 'user', content: prompt }
      ],
      response_format: { type: 'json_object' }
    });

    const content = completion.choices[0]?.message?.content || '{}';
    const parsed = JSON.parse(content);
    return this.sanitizeAndValidateReport(parsed, params, validEvidenceIds);
  }

  private buildPrompt(params: any): string {
    const {
      investigationId,
      extraction,
      assessment,
      matchedIndicators,
      claimedBrands,
      relatedIncidents,
      evidenceNodes,
      paths
    } = params;

    return `
You are the AI reporting engine for ScamGraph AI. Generate an explainable, fact-grounded investigation report based SOLELY on the graph evidence below. Do NOT invent incidents, metrics, or evidence IDs.

INVESTIGATION CONTEXT:
ID: ${investigationId}
Submitted Input: "${extraction.rawInputDigest}"
Risk Score: ${assessment.riskScore}/100 (${assessment.riskLevel})
Evidence Confidence: ${assessment.evidenceConfidence}%
Evidence Coverage: ${assessment.evidenceCoverage}

EXTRACTED ENTITIES:
${JSON.stringify(extraction.indicators, null, 2)}

MATCHED GRAPH INDICATORS:
${matchedIndicators.map((i: any) => `- ${i.id}: ${i.properties.displayValue || i.properties.value} (Risk Weight: ${i.properties.riskWeight})`).join('\n')}

CLAIMED BRANDS:
${claimedBrands.map((b: any) => `- ${b.id}: ${b.properties.name} (Official Domain: ${b.properties.officialDomain})`).join('\n')}

RELATED INCIDENTS IN FALKORDB:
${relatedIncidents.map((inc: any) => `- ${inc.id} [${inc.properties.severity}]: ${inc.properties.summary} (Victims: ${inc.properties.victimCountEstimate})`).join('\n')}

SUPPORTING EVIDENCE NODES:
${evidenceNodes.map((e: any) => `- ${e.id} [${e.properties.evidenceType}]: ${e.properties.description} (Confidence: ${e.properties.confidence})`).join('\n')}

DISCOVERED RELATIONSHIP PATHS:
${paths.map((p: any) => `- ${p.summary}`).join('\n')}

Return JSON with this EXACT structure:
{
  "executiveSummary": "Concise 2-3 sentence overview of the investigation findings and network linkages",
  "riskAssessmentExplanation": "Explain how the score was calculated based on the evidence",
  "matchedIndicators": ["indicator values"],
  "findings": [
    {
      "id": "FINDING-1",
      "title": "Short descriptive title",
      "description": "Specific evidence-grounded detail",
      "evidenceIds": ["only real evidence IDs from the list: ${Array.from(evidenceNodes.map((e: any) => e.id)).join(', ')}"],
      "severity": "CRITICAL" | "HIGH" | "MEDIUM" | "LOW"
    }
  ],
  "connectedIncidentSummaries": ["summaries of connected incidents"],
  "relationshipPathExplanations": ["concise explanations of multi-hop paths"],
  "uncertaintiesAndLimitations": ["untested domains, synthetic dataset boundaries, etc."],
  "recommendedNextSteps": ["safe practical defensive actions for the user"]
}
`;
  }

  private sanitizeAndValidateReport(
    parsed: any,
    params: any,
    validEvidenceIds: Set<string>
  ): StructuredInvestigationReport {
    // Validate findings and evidence references
    const rawFindings = Array.isArray(parsed.findings) ? parsed.findings : [];
    const sanitizedFindings = rawFindings.map((f: any, idx: number) => {
      const referencedEvidence = Array.isArray(f.evidenceIds)
        ? f.evidenceIds.filter((eid: string) => validEvidenceIds.has(eid))
        : [];

      return {
        id: f.id || `FINDING-${idx + 1}`,
        title: f.title || 'Investigative Finding',
        description: f.description || '',
        evidenceIds: referencedEvidence,
        severity: ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO'].includes(f.severity)
          ? f.severity
          : 'HIGH'
      };
    });

    return {
      investigationId: params.investigationId,
      timestamp: new Date().toISOString(),
      executiveSummary: parsed.executiveSummary || 'Network investigation completed across FalkorDB threat graph.',
      riskAssessmentExplanation: parsed.riskAssessmentExplanation || params.assessment.explanation,
      matchedIndicators: Array.isArray(parsed.matchedIndicators)
        ? parsed.matchedIndicators
        : params.matchedIndicators.map((i: any) => i.properties.displayValue || i.properties.value),
      findings: sanitizedFindings.length > 0 ? sanitizedFindings : this.buildDefaultFindings(params),
      connectedIncidentSummaries: Array.isArray(parsed.connectedIncidentSummaries)
        ? parsed.connectedIncidentSummaries
        : params.relatedIncidents.map((i: any) => `${i.id}: ${i.properties.summary}`),
      relationshipPathExplanations: Array.isArray(parsed.relationshipPathExplanations)
        ? parsed.relationshipPathExplanations
        : params.paths.map((p: any) => p.summary),
      uncertaintiesAndLimitations: Array.isArray(parsed.uncertaintiesAndLimitations)
        ? parsed.uncertaintiesAndLimitations
        : [
            'Assessment is grounded in synthetic threat intelligence data.',
            'Relationships represent structural links discovered in the knowledge graph.'
          ],
      recommendedNextSteps: Array.isArray(parsed.recommendedNextSteps)
        ? parsed.recommendedNextSteps
        : [
            'Do not follow links or input credentials into the flagged destination.',
            'Report the domain and phone number to your IT security or fraud desk.',
            'Verify any alerts by calling the verified phone number on the back of your official card.'
          ],
      syntheticDisclaimer: params.assessment.disclaimer
    };
  }

  private generateDeterministicReport(
    params: any,
    validEvidenceIds: Set<string>
  ): StructuredInvestigationReport {
    const {
      investigationId,
      assessment,
      matchedIndicators,
      relatedIncidents,
      evidenceNodes,
      paths
    } = params;

    const findings = this.buildDefaultFindings(params);

    const summaries = relatedIncidents.map((inc: any) => `[${inc.id} - ${inc.properties.severity}]: ${inc.properties.summary}`);
    const pathSummaries = paths.map((p: any) => p.summary);

    return {
      investigationId,
      timestamp: new Date().toISOString(),
      executiveSummary: `FalkorDB graph investigation matched ${matchedIndicators.length} suspicious indicator(s) connected to ${relatedIncidents.length} synthetic incident record(s) with ${assessment.evidenceConfidence}% confidence. Multi-hop traversal uncovered shared attack infrastructure.`,
      riskAssessmentExplanation: assessment.explanation,
      matchedIndicators: matchedIndicators.map((i: any) => i.properties.displayValue || i.properties.value),
      findings,
      connectedIncidentSummaries: summaries,
      relationshipPathExplanations: pathSummaries,
      uncertaintiesAndLimitations: [
        'Indicators and incidents derive from the synthetic FalkorDB test intelligence dataset.',
        'Scores represent a heuristic evidence assessment, not independent law enforcement attribution.',
        'Technical links reflect observed historical hosting and messaging configurations.'
      ],
      recommendedNextSteps: [
        'Do not navigate to, authorize, or submit credentials to the referenced domain.',
        'Block sender phone numbers or email addresses across communications systems.',
        'Notify your organization or financial provider using verified, out-of-band contact channels.'
      ],
      syntheticDisclaimer: assessment.disclaimer
    };
  }

  private buildDefaultFindings(params: any): Array<{
    id: string;
    title: string;
    description: string;
    evidenceIds: string[];
    severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';
  }> {
    const { matchedIndicators, relatedIncidents, evidenceNodes, claimedBrands } = params;
    const findings: any[] = [];

    if (matchedIndicators.length > 0) {
      findings.push({
        id: 'FINDING-01',
        title: 'Known Phishing Infrastructure Match',
        description: `Submitted indicator matches ${matchedIndicators.map((m: any) => m.properties.displayValue || m.properties.value).join(', ')} previously cataloged in synthetic incident waves.`,
        evidenceIds: evidenceNodes.slice(0, 2).map((e: any) => e.id),
        severity: 'CRITICAL'
      });
    }

    if (claimedBrands.length > 0) {
      findings.push({
        id: 'FINDING-02',
        title: 'Targeted Brand Impersonation',
        description: `Message impersonates ${claimedBrands.map((b: any) => b.properties.name).join(', ')} without authorization. Destination domains diverge from official infrastructure (${claimedBrands.map((b: any) => b.properties.officialDomain).join(', ')}).`,
        evidenceIds: evidenceNodes.slice(2, 3).map((e: any) => e.id),
        severity: 'HIGH'
      });
    }

    if (relatedIncidents.length > 0) {
      findings.push({
        id: 'FINDING-03',
        title: 'Multi-Incident Syndication Across Graph',
        description: `Correlated with ${relatedIncidents.length} synthetic incident report(s) involving credential harvesting and advance-fee payment fraud.`,
        evidenceIds: evidenceNodes.map((e: any) => e.id),
        severity: 'HIGH'
      });
    }

    return findings;
  }
}

export const reportService = new ReportService();
