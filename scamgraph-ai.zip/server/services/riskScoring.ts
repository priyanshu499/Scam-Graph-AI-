export interface GraphNode {
  id: string;
  labels: string[];
  properties: Record<string, any>;
}

export interface ExtractionResult {
  indicators: Array<{ value: string; type: string; rawText: string; confidence: number }>;
  claimedBrands: string[];
  urgencySignals: Array<{ category: any; matchedPhrase: string; weight: number }>;
  hasUrgentRequest: boolean;
  hasCredentialRequest: boolean;
  hasPaymentRequest: boolean;
  rawInputDigest: string;
}

export interface ScoreRuleResult {
  ruleId: string;
  name: string;
  description: string;
  points: number;
  maxPoints: number;
  applied: boolean;
  reason: string;
  evidenceIds: string[];
}

export interface RiskAssessment {
  riskScore: number; // 0 - 100
  riskLevel: 'HIGH_RISK' | 'NEEDS_CAUTION' | 'LOW_RISK' | 'INSUFFICIENT_EVIDENCE';
  riskLabel: string;
  evidenceConfidence: number; // 0 - 100 percentage
  evidenceCoverage: 'HIGH' | 'MODERATE' | 'LOW' | 'INSUFFICIENT';
  rules: ScoreRuleResult[];
  explanation: string;
  disclaimer: string;
}

export const DISCLAIMER_TEXT =
  'SYNTHETIC DEMO INTELLIGENCE: This assessment is an explainable decision-support heuristic calculated from the FalkorDB synthetic dataset and heuristic indicator analysis. It does not constitute legal or definitive fraud verification. Always verify through official channels.';

export function calculateRiskScore(params: {
  extraction: ExtractionResult;
  matchedIndicators: GraphNode[];
  claimedBrands: GraphNode[];
  relatedIncidents: Array<GraphNode & { connectingIndicatorId: string; direct: boolean }>;
  evidenceNodes: GraphNode[];
  hasSharedInfrastructure: boolean;
  excludedRuleIds?: string[];
}): RiskAssessment {
  const {
    extraction,
    matchedIndicators,
    claimedBrands,
    relatedIncidents,
    evidenceNodes,
    hasSharedInfrastructure,
    excludedRuleIds = []
  } = params;

  const rules: ScoreRuleResult[] = [];

  // Rule 1: High-Risk Indicator Match (up to 25 pts)
  let rule1Points = 0;
  let rule1Reason = 'No matched indicators in graph intelligence database.';
  let rule1Applied = false;
  const highRiskIndicators = matchedIndicators.filter(i => (i.properties.riskWeight || 0) >= 70);
  const medRiskIndicators = matchedIndicators.filter(i => (i.properties.riskWeight || 0) >= 40 && (i.properties.riskWeight || 0) < 70);

  if (highRiskIndicators.length > 0) {
    rule1Points = 25;
    rule1Applied = true;
    rule1Reason = `Matched ${highRiskIndicators.length} pre-flagged high-risk synthetic indicator(s): ${highRiskIndicators.map(i => i.properties.displayValue || i.properties.value).join(', ')}`;
  } else if (medRiskIndicators.length > 0) {
    rule1Points = 15;
    rule1Applied = true;
    rule1Reason = `Matched ${medRiskIndicators.length} suspicious synthetic indicator(s): ${medRiskIndicators.map(i => i.properties.displayValue || i.properties.value).join(', ')}`;
  } else if (matchedIndicators.length > 0) {
    rule1Points = 5;
    rule1Applied = true;
    rule1Reason = `Matched ${matchedIndicators.length} neutral/low-weight indicator node(s).`;
  }

  rules.push({
    ruleId: 'RULE_INDICATOR_MATCH',
    name: 'Indicator Dataset Match',
    description: 'Exact match with an indicator pre-flagged as high risk in the threat knowledge graph.',
    points: rule1Points,
    maxPoints: 25,
    applied: rule1Applied,
    reason: rule1Reason,
    evidenceIds: matchedIndicators.map(i => i.id)
  });

  // Rule 2: Multi-Incident Cluster Occurrence (up to 20 pts)
  let rule2Points = 0;
  let rule2Reason = 'No independent incident records associate with these indicators.';
  let rule2Applied = false;

  if (relatedIncidents.length >= 3) {
    rule2Points = 20;
    rule2Applied = true;
    rule2Reason = `Indicators recur across ${relatedIncidents.length} independent synthetic incidents (${relatedIncidents.map(i => i.id).slice(0, 3).join(', ')}).`;
  } else if (relatedIncidents.length === 2) {
    rule2Points = 15;
    rule2Applied = true;
    rule2Reason = `Indicators connect to 2 separate synthetic incidents (${relatedIncidents.map(i => i.id).join(', ')}).`;
  } else if (relatedIncidents.length === 1) {
    rule2Points = 10;
    rule2Applied = true;
    rule2Reason = `Indicators connect to 1 known synthetic incident (${relatedIncidents[0].id}).`;
  }

  rules.push({
    ruleId: 'RULE_INCIDENT_RECURRENCE',
    name: 'Incident Cluster Recurrence',
    description: 'Repeated appearance of indicators across independent fraud incident reports.',
    points: rule2Points,
    maxPoints: 20,
    applied: rule2Applied,
    reason: rule2Reason,
    evidenceIds: relatedIncidents.map(i => i.id)
  });

  // Rule 3: Brand Impersonation Evidence (up to 20 pts)
  let rule3Points = 0;
  let rule3Reason = 'No claimed brand detected or domain matches legitimate brand official domain.';
  let rule3Applied = false;

  const brandDiscrepancies: string[] = [];
  for (const b of claimedBrands) {
    const brandName = b.properties.name;
    const officialDomain = b.properties.officialDomain;
    const submittedDomains = extraction.indicators.filter(i => i.type === 'domain' || i.type === 'url');

    const domainMatchesOfficial = submittedDomains.some(d => d.value.includes(officialDomain));
    if (submittedDomains.length > 0 && !domainMatchesOfficial) {
      brandDiscrepancies.push(`${brandName} claimed, but domain points to unauthorized target (${submittedDomains.map(d => d.value).join(', ')} vs official ${officialDomain})`);
    } else if (submittedDomains.length === 0) {
      brandDiscrepancies.push(`${brandName} referenced in unverified communication channel`);
    }
  }

  if (brandDiscrepancies.length > 0) {
    rule3Points = 20;
    rule3Applied = true;
    rule3Reason = brandDiscrepancies.join('; ');
  } else if (extraction.claimedBrands.length > 0 && claimedBrands.length === 0) {
    rule3Points = 10;
    rule3Applied = true;
    rule3Reason = `Claimed brand "${extraction.claimedBrands.join(', ')}" is not registered in legitimate brand directory.`;
  }

  rules.push({
    ruleId: 'RULE_BRAND_IMPERSONATION',
    name: 'Brand Impersonation Signal',
    description: 'Discrepancy between the claimed brand organization and destination domains or contact handles.',
    points: rule3Points,
    maxPoints: 20,
    applied: rule3Applied,
    reason: rule3Reason,
    evidenceIds: claimedBrands.map(b => b.id)
  });

  // Rule 4: Shared Multi-Hop Infrastructure (up to 20 pts)
  let rule4Points = 0;
  let rule4Reason = 'No cross-campaign or shared infrastructure nodes discovered.';
  let rule4Applied = false;

  const indirectIncidents = relatedIncidents.filter(i => !i.direct);
  if (hasSharedInfrastructure && indirectIncidents.length > 0) {
    rule4Points = 20;
    rule4Applied = true;
    rule4Reason = `Cross-campaign infrastructure detected: shares nameservers, TLS certificates, or host IP with ${indirectIncidents.length} additional incident(s).`;
  } else if (hasSharedInfrastructure) {
    rule4Points = 15;
    rule4Applied = true;
    rule4Reason = 'Technical graph links corroborate shared hosting, wallet, or nameserver infrastructure.';
  } else if (indirectIncidents.length > 0) {
    rule4Points = 10;
    rule4Applied = true;
    rule4Reason = `Multi-hop relationship links connect indicator to incident ${indirectIncidents[0].id}.`;
  }

  rules.push({
    ruleId: 'RULE_SHARED_INFRASTRUCTURE',
    name: 'Shared Infrastructure & Pivot',
    description: 'Shared nameservers, TLS certs, phone trunks, or crypto wallets connecting disparate incidents.',
    points: rule4Points,
    maxPoints: 20,
    applied: rule4Applied,
    reason: rule4Reason,
    evidenceIds: evidenceNodes.map(e => e.id)
  });

  // Rule 5: Urgent Credential / Payment Demands (up to 10 pts)
  let rule5Points = 0;
  let rule5Reason = 'No urgency threats, credential demands, or advance payment requests in message copy.';
  let rule5Applied = false;

  if (extraction.hasUrgentRequest && (extraction.hasCredentialRequest || extraction.hasPaymentRequest)) {
    rule5Points = 10;
    rule5Applied = true;
    rule5Reason = 'Coercive urgency threat paired with direct credential or advance payment solicitation.';
  } else if (extraction.hasUrgentRequest || extraction.hasCredentialRequest || extraction.hasPaymentRequest) {
    rule5Points = 6;
    rule5Applied = true;
    rule5Reason = 'Suspicious urgency phrasing or credential verification request detected in text.';
  }

  rules.push({
    ruleId: 'RULE_URGENCY_CREDENTIALS',
    name: 'Urgency & Credential Coercion',
    description: 'Presence of artificial urgency, threats of account lockout, or urgent requests for credentials/money.',
    points: rule5Points,
    maxPoints: 10,
    applied: rule5Applied,
    reason: rule5Reason,
    evidenceIds: []
  });

  // Rule 6: URL Obfuscation / Non-Standard Structure (up to 5 pts)
  let rule6Points = 0;
  let rule6Reason = 'No suspicious URL obfuscation or deceptive TLD detected.';
  let rule6Applied = false;

  const urlIndicators = extraction.indicators.filter(i => i.type === 'url' || i.type === 'domain');
  const hasSuspiciousPath = urlIndicators.some(u => u.value.includes('/') || u.value.includes('-verify') || u.value.includes('-login') || u.value.includes('-pay'));
  if (hasSuspiciousPath) {
    rule6Points = 5;
    rule6Applied = true;
    rule6Reason = 'Deceptive subdomain or subpath pattern mimicking authentic authentication endpoints.';
  }

  rules.push({
    ruleId: 'RULE_URL_OBFUSCATION',
    name: 'URL Obfuscation & Path Structure',
    description: 'Use of hyphenated subdomains, deceptive subpaths, or disguised service names.',
    points: rule6Points,
    maxPoints: 5,
    applied: rule6Applied,
    reason: rule6Reason,
    evidenceIds: []
  });

  // Calculate final score with counterfactual exclusion filter
  let totalScore = 0;
  for (const r of rules) {
    if (!excludedRuleIds.includes(r.ruleId)) {
      totalScore += r.points;
    }
  }
  totalScore = Math.min(100, Math.max(0, totalScore));

  // Determine coverage and confidence
  const totalGraphNodes = matchedIndicators.length + relatedIncidents.length + evidenceNodes.length;
  let evidenceCoverage: 'HIGH' | 'MODERATE' | 'LOW' | 'INSUFFICIENT' = 'INSUFFICIENT';
  if (matchedIndicators.length === 0) {
    evidenceCoverage = 'INSUFFICIENT';
  } else if (totalGraphNodes >= 6) {
    evidenceCoverage = 'HIGH';
  } else if (totalGraphNodes >= 3) {
    evidenceCoverage = 'MODERATE';
  } else {
    evidenceCoverage = 'LOW';
  }

  // Calculate evidence confidence based on evidence confidence properties
  let avgConfidence = 0.5;
  if (evidenceNodes.length > 0) {
    const sum = evidenceNodes.reduce((acc, curr) => acc + (curr.properties.confidence || 0.8), 0);
    avgConfidence = sum / evidenceNodes.length;
  } else if (matchedIndicators.length > 0) {
    avgConfidence = 0.75;
  } else {
    avgConfidence = 0.2;
  }
  const evidenceConfidence = Math.round(avgConfidence * 100);

  // Determine Risk Category
  let riskLevel: 'HIGH_RISK' | 'NEEDS_CAUTION' | 'LOW_RISK' | 'INSUFFICIENT_EVIDENCE';
  let riskLabel: string;

  if (matchedIndicators.length === 0 && relatedIncidents.length === 0) {
    riskLevel = 'INSUFFICIENT_EVIDENCE';
    riskLabel = 'Insufficient Evidence';
  } else if (totalScore >= 70) {
    riskLevel = 'HIGH_RISK';
    riskLabel = 'High Risk Scam Network';
  } else if (totalScore >= 35) {
    riskLevel = 'NEEDS_CAUTION';
    riskLabel = 'Needs Caution';
  } else {
    riskLevel = 'LOW_RISK';
    riskLabel = 'Low Risk Observed';
  }

  // Generate plain-text explanation of the risk calculation
  let explanation = '';
  if (riskLevel === 'INSUFFICIENT_EVIDENCE') {
    explanation =
      'No matching indicators or relationship paths were identified in the FalkorDB knowledge graph. The score reflects absence of known indicators in this database, NOT verification of safety. Exercise independent caution.';
  } else {
    const appliedRules = rules.filter(r => r.applied && !excludedRuleIds.includes(r.ruleId));
    explanation = `Risk assessment computed at ${totalScore}/100 based on ${appliedRules.length} active risk criteria: ` +
      appliedRules.map(r => `${r.name} (+${r.points} pts)`).join(', ') +
      `. Connected to ${relatedIncidents.length} synthetic incident record(s) with ${evidenceConfidence}% evidence confidence.`;
  }

  return {
    riskScore: totalScore,
    riskLevel,
    riskLabel,
    evidenceConfidence,
    evidenceCoverage,
    rules,
    explanation,
    disclaimer: DISCLAIMER_TEXT
  };
}
