export interface SeedBrand {
  id: string;
  name: string;
  classification: 'fictional' | 'real_emulated';
  officialDomain: string;
  industry: string;
}

export interface SeedIndicator {
  id: string;
  value: string;
  indicatorType: 'domain' | 'url' | 'phone' | 'payment_handle' | 'email';
  displayValue: string;
  firstSeen: string;
  riskWeight: number; // 0 to 100 base suspiciousness
  notes: string;
}

export interface SeedIncident {
  id: string;
  summary: string;
  category: string;
  timestamp: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  sourceType: string;
  victimCountEstimate: number;
}

export interface SeedCampaign {
  id: string;
  label: string;
  description: string;
  status: 'ACTIVE' | 'EMERGING' | 'DORMANT';
}

export interface SeedEvidence {
  id: string;
  evidenceType: 'DNS_CO_HOSTING' | 'WHOIS_AFFILIATION' | 'SHARED_WALLET' | 'TELECOM_CARRIER' | 'VICTIM_REPORT' | 'PHISHING_KIT_SIGNATURE';
  description: string;
  confidence: number; // 0.0 to 1.0
  sourceType: string;
}

export interface SeedRelationship {
  fromId: string;
  toId: string;
  relType: 'MENTIONS' | 'IMPERSONATES' | 'PART_OF' | 'LINKED_TO' | 'SUPPORTED_BY';
  properties?: Record<string, any>;
}

export const SEED_BRANDS: SeedBrand[] = [
  { id: 'brand-northstar', name: 'Northstar Bank', classification: 'fictional', officialDomain: 'northstarbank.test', industry: 'Banking & Financial' },
  { id: 'brand-swiftdrop', name: 'SwiftDrop Logistics', classification: 'fictional', officialDomain: 'swiftdrop-logistics.test', industry: 'Postal & Delivery' },
  { id: 'brand-apexcareer', name: 'Apex Global Careers', classification: 'fictional', officialDomain: 'apex-globalcareers.test', industry: 'Employment & HR' },
  { id: 'brand-vertexpay', name: 'Vertex Pay', classification: 'fictional', officialDomain: 'vertexpay.test', industry: 'Fintech & Payments' },
  { id: 'brand-cloudshield', name: 'CloudShield Security', classification: 'fictional', officialDomain: 'cloudshield-auth.test', industry: 'IT & Cloud Services' }
];

export const SEED_CAMPAIGNS: SeedCampaign[] = [
  {
    id: 'camp-phish-fin-01',
    label: 'Campaign: Northstar Credential Harvest Ring',
    description: 'Syndicate using typo-squatted domains and SMS lures threatening urgent suspension to harvest banking credentials.',
    status: 'ACTIVE'
  },
  {
    id: 'camp-courier-04',
    label: 'Campaign: SwiftDrop Redelivery Fee Syndicate',
    description: 'Fraud network blasting package redelivery notifications demanding $1.99 - $3.50 custom/handling fees to capture payment cards.',
    status: 'ACTIVE'
  },
  {
    id: 'camp-work-job-09',
    label: 'Campaign: Apex Remote Task Deposit Ring',
    description: 'High-yield task platform scam coercing job seekers into depositing crypto or wire transfers for starter equipment packages.',
    status: 'ACTIVE'
  },
  {
    id: 'camp-dormant-fin-02',
    label: 'Campaign: Legacy Vertex Pay Phish Cluster',
    description: 'Dormant fintech credential harvesting ring sharing infrastructure with newer banking syndicates.',
    status: 'DORMANT'
  }
];

export const SEED_INDICATORS: SeedIndicator[] = [
  // Northstar Bank Scam Cluster
  { id: 'ind-ns-verify', value: 'northstar-verify.test', indicatorType: 'domain', displayValue: 'northstar-verify.test', firstSeen: '2026-08-12T04:20:00Z', riskWeight: 85, notes: 'Fake verification portal mimicking Northstar login' },
  { id: 'ind-ns-secure', value: 'northstar-secure-login.test', indicatorType: 'domain', displayValue: 'northstar-secure-login.test', firstSeen: '2026-08-20T11:00:00Z', riskWeight: 80, notes: 'Second stage harvest domain' },
  { id: 'ind-ns-suburl', value: 'northstar-verify.test/auth/account-lock', indicatorType: 'url', displayValue: 'northstar-verify.test/auth/account-lock', firstSeen: '2026-08-12T04:25:00Z', riskWeight: 90, notes: 'Deep link sent in phishing SMS' },
  { id: 'ind-phone-fin-01', value: '+1-800-555-0199', indicatorType: 'phone', displayValue: '+1-800-555-0199', firstSeen: '2026-08-10T14:15:00Z', riskWeight: 75, notes: 'VoIP caller ID used for spoofed Northstar security alerts' },
  { id: 'ind-pay-fin-ns', value: '$northstar-help', indicatorType: 'payment_handle', displayValue: '$northstar-help', firstSeen: '2026-08-14T19:30:00Z', riskWeight: 70, notes: 'Peer-to-peer handle demanding account restoration bond' },
  { id: 'ind-ip-fin-shared', value: '198.51.100.44', indicatorType: 'domain', displayValue: '198.51.100.44 (Shared Phish Host)', firstSeen: '2026-07-28T09:00:00Z', riskWeight: 80, notes: 'Bulletproof VPS hosting multiple credential harvesters' },

  // SwiftDrop Delivery Scam Cluster
  { id: 'ind-sd-pay', value: 'swiftdrop-pay.test', indicatorType: 'domain', displayValue: 'swiftdrop-pay.test', firstSeen: '2026-09-02T16:45:00Z', riskWeight: 85, notes: 'Fake package customs clearance payment gateway' },
  { id: 'ind-sd-track', value: 'swiftdrop-tracking.test', indicatorType: 'domain', displayValue: 'swiftdrop-tracking.test', firstSeen: '2026-09-01T08:10:00Z', riskWeight: 75, notes: 'Tracking landing page with fake pending fee modal' },
  { id: 'ind-sd-url', value: 'swiftdrop-pay.test/fee/parcel-9842', indicatorType: 'url', displayValue: 'swiftdrop-pay.test/fee/parcel-9842', firstSeen: '2026-09-02T16:50:00Z', riskWeight: 88, notes: 'Direct checkout link' },
  { id: 'ind-phone-courier-02', value: '+1-888-555-0142', indicatorType: 'phone', displayValue: '+1-888-555-0142', firstSeen: '2026-08-25T10:00:00Z', riskWeight: 70, notes: 'Toll-free spoofed dispatch sender' },
  { id: 'ind-pay-sd', value: '$swiftdrop-release', indicatorType: 'payment_handle', displayValue: '$swiftdrop-release', firstSeen: '2026-09-05T12:00:00Z', riskWeight: 75, notes: 'P2P account flagged for unauthorized delivery fees' },
  { id: 'ind-email-courier', value: 'dispatch@swiftdrop-support.test', indicatorType: 'email', displayValue: 'dispatch@swiftdrop-support.test', firstSeen: '2026-09-03T18:20:00Z', riskWeight: 65, notes: 'Notification dispatch email' },

  // Apex Career Scam Cluster
  { id: 'ind-apex-fee', value: 'apex-career-fee.test', indicatorType: 'domain', displayValue: 'apex-career-fee.test', firstSeen: '2026-09-18T13:30:00Z', riskWeight: 90, notes: 'Fake corporate candidate onboarding and deposit portal' },
  { id: 'ind-apex-portal', value: 'apex-global-onboard.test', indicatorType: 'domain', displayValue: 'apex-global-onboard.test', firstSeen: '2026-09-15T09:12:00Z', riskWeight: 78, notes: 'Secondary onboarding site' },
  { id: 'ind-phone-job-03', value: '+1-202-555-0187', indicatorType: 'phone', displayValue: '+1-202-555-0187', firstSeen: '2026-09-10T20:00:00Z', riskWeight: 72, notes: 'WhatsApp/SMS recruiter identity' },
  { id: 'ind-pay-apex-crypto', value: 'crypto:0x9f82c40134d4a8e2', indicatorType: 'payment_handle', displayValue: '0x9f82...a8e2 (Tether Deposit)', firstSeen: '2026-09-20T11:45:00Z', riskWeight: 92, notes: 'Deposit address for training kit payment' },
  { id: 'ind-pay-apex-cashapp', value: '$apexcareers_hr', indicatorType: 'payment_handle', displayValue: '$apexcareers_hr', firstSeen: '2026-09-19T14:10:00Z', riskWeight: 75, notes: 'Alternative CashApp tag requested from applicants' },

  // Cross-Cluster Infrastructure Bridge (Connecting SwiftDrop and Northstar via shared server & registrar)
  { id: 'ind-infra-nameserver', value: 'ns1.bulletproof-dns.test', indicatorType: 'domain', displayValue: 'ns1.bulletproof-dns.test (Shared NS)', firstSeen: '2026-06-15T00:00:00Z', riskWeight: 80, notes: 'Fast-flux authoritative nameserver shared across scams' },
  { id: 'ind-infra-ssl', value: 'cert-sha256:77ba91f28b4c', indicatorType: 'domain', displayValue: 'SSL Cert: 77ba91f...', firstSeen: '2026-07-01T00:00:00Z', riskWeight: 70, notes: 'Wildcard SSL certificate used on both Northstar & SwiftDrop clone kits' },

  // Secondary Isolated / Benign Test Indicators (For benchmark & demonstration)
  { id: 'ind-vertex-legacy', value: 'vertexpay-update.test', indicatorType: 'domain', displayValue: 'vertexpay-update.test', firstSeen: '2025-11-04T10:00:00Z', riskWeight: 60, notes: 'Legacy inactive harvester' },
  { id: 'ind-benign-sample', value: 'company-portal.test', indicatorType: 'domain', displayValue: 'company-portal.test', firstSeen: '2026-01-10T12:00:00Z', riskWeight: 10, notes: 'Neutral test node with no scam incidents linked' }
];

export const SEED_EVIDENCE: SeedEvidence[] = [
  {
    id: 'EVD-101',
    evidenceType: 'PHISHING_KIT_SIGNATURE',
    description: 'DOM structure matches known cloned Northstar portal kit v4.2 with credential exfiltration hooks.',
    confidence: 0.96,
    sourceType: 'Synthetic Threat Intel Feed'
  },
  {
    id: 'EVD-102',
    evidenceType: 'DNS_CO_HOSTING',
    description: 'Domain northstar-verify.test resolves to IP 198.51.100.44 alongside northstar-secure-login.test and ns1.bulletproof-dns.test.',
    confidence: 0.94,
    sourceType: 'Synthetic Passive DNS Graph'
  },
  {
    id: 'EVD-103',
    evidenceType: 'TELECOM_CARRIER',
    description: 'VoIP number +1-800-555-0199 routed through unverified virtual PBX provider with 300+ fraud abuse flags.',
    confidence: 0.89,
    sourceType: 'Telecom Registry Intelligence'
  },
  {
    id: 'EVD-104',
    evidenceType: 'VICTIM_REPORT',
    description: '14 user reports submitted to synthetic fraud desk reporting unauthorized $450 withdrawals following Northstar verification message.',
    confidence: 0.92,
    sourceType: 'Synthetic Consumer Protection Portal'
  },
  {
    id: 'EVD-201',
    evidenceType: 'SHARED_WALLET',
    description: 'P2P handle $swiftdrop-release routes deposits to the same staging crypto off-ramp identified in incident INC-2026-0809.',
    confidence: 0.91,
    sourceType: 'Synthetic Blockchain Analytics'
  },
  {
    id: 'EVD-202',
    evidenceType: 'PHISHING_KIT_SIGNATURE',
    description: 'Payment form on swiftdrop-pay.test captures full CVV, billing address, and SSN last-4 under guise of redelivery verification.',
    confidence: 0.97,
    sourceType: 'Synthetic Web Sandbox Analysis'
  },
  {
    id: 'EVD-203',
    evidenceType: 'DNS_CO_HOSTING',
    description: 'swiftdrop-pay.test shares wildcard TLS certificate cert-sha256:77ba91f28b4c with northstar-verify.test infrastructure.',
    confidence: 0.88,
    sourceType: 'Certificate Transparency Logs'
  },
  {
    id: 'EVD-301',
    evidenceType: 'VICTIM_REPORT',
    description: 'Victim report: applicant pressured to deposit $350 in USDT to 0x9f82c40134d4a8e2 for laptop insurance prior to first interview.',
    confidence: 0.95,
    sourceType: 'Synthetic Job Fraud Clearinghouse'
  },
  {
    id: 'EVD-302',
    evidenceType: 'WHOIS_AFFILIATION',
    description: 'apex-career-fee.test registered with privacy proxy using identical anonymous contact pattern as known employment advance-fee scams.',
    confidence: 0.84,
    sourceType: 'Synthetic WHOIS Graph'
  },
  {
    id: 'EVD-303',
    evidenceType: 'TELECOM_CARRIER',
    description: 'Recruiter phone +1-202-555-0187 detected in 18 recruitment scam complaints originating from disposable SIM pools.',
    confidence: 0.90,
    sourceType: 'Synthetic Telecom Intelligence'
  }
];

export const SEED_INCIDENTS: SeedIncident[] = [
  // Northstar Bank Incidents (5 incidents)
  {
    id: 'INC-2026-0801',
    summary: 'Mass SMS wave alleging Northstar account lockout directing victims to northstar-verify.test',
    category: 'BANKING_CREDENTIAL_PHISH',
    timestamp: '2026-08-12T05:00:00Z',
    severity: 'CRITICAL',
    sourceType: 'Customer Incident Intake',
    victimCountEstimate: 230
  },
  {
    id: 'INC-2026-0809',
    summary: 'Voice phishing follow-up from +1-800-555-0199 coaching callers to authorize 2FA bypass on Northstar',
    category: 'VISHING_2FA_BYPASS',
    timestamp: '2026-08-14T15:20:00Z',
    severity: 'HIGH',
    sourceType: 'Bank Fraud Operations',
    victimCountEstimate: 45
  },
  {
    id: 'INC-2026-0815',
    summary: 'Spear-phishing email targeting high-value customers with backup domain northstar-secure-login.test',
    category: 'TARGETED_EXFILTRATION',
    timestamp: '2026-08-21T09:00:00Z',
    severity: 'HIGH',
    sourceType: 'Security Operations Center',
    victimCountEstimate: 18
  },
  {
    id: 'INC-2026-0822',
    summary: 'Demands for security bond restoration sent via $northstar-help payment handle',
    category: 'DIRECT_PAYMENT_EXTORTION',
    timestamp: '2026-08-23T18:40:00Z',
    severity: 'MEDIUM',
    sourceType: 'Victim Telemetry',
    victimCountEstimate: 12
  },
  {
    id: 'INC-2026-0829',
    summary: 'Shared hosting pivot discovering northstar-verify.test co-located with dormant banking kits',
    category: 'INFRASTRUCTURE_PROBE',
    timestamp: '2026-08-30T11:15:00Z',
    severity: 'HIGH',
    sourceType: 'Automated Threat Crawler',
    victimCountEstimate: 0
  },

  // SwiftDrop Logistics Incidents (4 incidents)
  {
    id: 'INC-2026-0901',
    summary: 'Delivery failure SMS lure demanding $2.85 rescheduling payment at swiftdrop-pay.test',
    category: 'COURIER_FEE_SCAM',
    timestamp: '2026-09-02T17:00:00Z',
    severity: 'HIGH',
    sourceType: 'Postal Inspection Desk',
    victimCountEstimate: 410
  },
  {
    id: 'INC-2026-0904',
    summary: 'Automated robocall from +1-888-555-0142 advising recipient of detained parcel awaiting fee',
    category: 'COURIER_ROBOCALL',
    timestamp: '2026-09-03T14:10:00Z',
    severity: 'MEDIUM',
    sourceType: 'Customer Reports',
    victimCountEstimate: 95
  },
  {
    id: 'INC-2026-0907',
    summary: 'Payment card skimming confirmed on swiftdrop-pay.test/fee/parcel-9842',
    category: 'CARD_DATA_THEFT',
    timestamp: '2026-09-04T22:30:00Z',
    severity: 'CRITICAL',
    sourceType: 'Card Scheme Fraud Alert',
    victimCountEstimate: 160
  },
  {
    id: 'INC-2026-0911',
    summary: 'SwiftDrop impersonation campaign directing payments to peer-to-peer handle $swiftdrop-release',
    category: 'PEER_TO_PEER_FRAUD',
    timestamp: '2026-09-06T10:00:00Z',
    severity: 'MEDIUM',
    sourceType: 'Victim Intake',
    victimCountEstimate: 34
  },

  // Apex Global Career Incidents (4 incidents)
  {
    id: 'INC-2026-0915',
    summary: 'Fake remote data entry offer demanding $350 training kit fee at apex-career-fee.test',
    category: 'JOB_ADVANCE_FEE',
    timestamp: '2026-09-18T14:00:00Z',
    severity: 'HIGH',
    sourceType: 'Job Portal Abuse Alert',
    victimCountEstimate: 78
  },
  {
    id: 'INC-2026-0918',
    summary: 'Recruiter persona on +1-202-555-0187 conducting fake interviews via encrypted messaging',
    category: 'RECRUITER_PERSONA_FRAUD',
    timestamp: '2026-09-19T16:20:00Z',
    severity: 'HIGH',
    sourceType: 'Social Media Escalation',
    victimCountEstimate: 52
  },
  {
    id: 'INC-2026-0922',
    summary: 'USDT deposit collection via 0x9f82c40134d4a8e2 with promise of prompt reimbursement',
    category: 'CRYPTO_DEPOSIT_THEFT',
    timestamp: '2026-09-20T12:00:00Z',
    severity: 'CRITICAL',
    sourceType: 'Victim Dispute Filing',
    victimCountEstimate: 29
  },
  {
    id: 'INC-2026-0925',
    summary: 'Applicant credential harvest via secondary portal apex-global-onboard.test',
    category: 'IDENTITY_THEFT',
    timestamp: '2026-09-22T08:45:00Z',
    severity: 'HIGH',
    sourceType: 'Security Bulletin',
    victimCountEstimate: 64
  },

  // Cross-Campaign Infrastructure Investigation Incident
  {
    id: 'INC-2026-1002',
    summary: 'Threat research cluster linking Northstar and SwiftDrop infrastructure via shared SSL cert and nameserver',
    category: 'SYNDICATE_CROSS_LINK',
    timestamp: '2026-10-02T16:00:00Z',
    severity: 'HIGH',
    sourceType: 'Analyst Investigation',
    victimCountEstimate: 0
  }
];

export const SEED_RELATIONSHIPS: SeedRelationship[] = [
  // --- Northstar Incidents to Indicators & Brands ---
  { fromId: 'INC-2026-0801', toId: 'ind-ns-verify', relType: 'MENTIONS' },
  { fromId: 'INC-2026-0801', toId: 'ind-ns-suburl', relType: 'MENTIONS' },
  { fromId: 'INC-2026-0801', toId: 'brand-northstar', relType: 'IMPERSONATES' },
  { fromId: 'INC-2026-0801', toId: 'camp-phish-fin-01', relType: 'PART_OF' },

  { fromId: 'INC-2026-0809', toId: 'ind-phone-fin-01', relType: 'MENTIONS' },
  { fromId: 'INC-2026-0809', toId: 'brand-northstar', relType: 'IMPERSONATES' },
  { fromId: 'INC-2026-0809', toId: 'camp-phish-fin-01', relType: 'PART_OF' },

  { fromId: 'INC-2026-0815', toId: 'ind-ns-secure', relType: 'MENTIONS' },
  { fromId: 'INC-2026-0815', toId: 'brand-northstar', relType: 'IMPERSONATES' },
  { fromId: 'INC-2026-0815', toId: 'camp-phish-fin-01', relType: 'PART_OF' },

  { fromId: 'INC-2026-0822', toId: 'ind-pay-fin-ns', relType: 'MENTIONS' },
  { fromId: 'INC-2026-0822', toId: 'brand-northstar', relType: 'IMPERSONATES' },
  { fromId: 'INC-2026-0822', toId: 'camp-phish-fin-01', relType: 'PART_OF' },

  { fromId: 'INC-2026-0829', toId: 'ind-ip-fin-shared', relType: 'MENTIONS' },
  { fromId: 'INC-2026-0829', toId: 'ind-ns-verify', relType: 'MENTIONS' },
  { fromId: 'INC-2026-0829', toId: 'camp-phish-fin-01', relType: 'PART_OF' },

  // --- SwiftDrop Incidents to Indicators & Brands ---
  { fromId: 'INC-2026-0901', toId: 'ind-sd-pay', relType: 'MENTIONS' },
  { fromId: 'INC-2026-0901', toId: 'ind-sd-track', relType: 'MENTIONS' },
  { fromId: 'INC-2026-0901', toId: 'brand-swiftdrop', relType: 'IMPERSONATES' },
  { fromId: 'INC-2026-0901', toId: 'camp-courier-04', relType: 'PART_OF' },

  { fromId: 'INC-2026-0904', toId: 'ind-phone-courier-02', relType: 'MENTIONS' },
  { fromId: 'INC-2026-0904', toId: 'brand-swiftdrop', relType: 'IMPERSONATES' },
  { fromId: 'INC-2026-0904', toId: 'camp-courier-04', relType: 'PART_OF' },

  { fromId: 'INC-2026-0907', toId: 'ind-sd-url', relType: 'MENTIONS' },
  { fromId: 'INC-2026-0907', toId: 'brand-swiftdrop', relType: 'IMPERSONATES' },
  { fromId: 'INC-2026-0907', toId: 'camp-courier-04', relType: 'PART_OF' },

  { fromId: 'INC-2026-0911', toId: 'ind-pay-sd', relType: 'MENTIONS' },
  { fromId: 'INC-2026-0911', toId: 'ind-email-courier', relType: 'MENTIONS' },
  { fromId: 'INC-2026-0911', toId: 'brand-swiftdrop', relType: 'IMPERSONATES' },
  { fromId: 'INC-2026-0911', toId: 'camp-courier-04', relType: 'PART_OF' },

  // --- Apex Career Incidents to Indicators & Brands ---
  { fromId: 'INC-2026-0915', toId: 'ind-apex-fee', relType: 'MENTIONS' },
  { fromId: 'INC-2026-0915', toId: 'brand-apexcareer', relType: 'IMPERSONATES' },
  { fromId: 'INC-2026-0915', toId: 'camp-work-job-09', relType: 'PART_OF' },

  { fromId: 'INC-2026-0918', toId: 'ind-phone-job-03', relType: 'MENTIONS' },
  { fromId: 'INC-2026-0918', toId: 'brand-apexcareer', relType: 'IMPERSONATES' },
  { fromId: 'INC-2026-0918', toId: 'camp-work-job-09', relType: 'PART_OF' },

  { fromId: 'INC-2026-0922', toId: 'ind-pay-apex-crypto', relType: 'MENTIONS' },
  { fromId: 'INC-2026-0922', toId: 'ind-pay-apex-cashapp', relType: 'MENTIONS' },
  { fromId: 'INC-2026-0922', toId: 'brand-apexcareer', relType: 'IMPERSONATES' },
  { fromId: 'INC-2026-0922', toId: 'camp-work-job-09', relType: 'PART_OF' },

  { fromId: 'INC-2026-0925', toId: 'ind-apex-portal', relType: 'MENTIONS' },
  { fromId: 'INC-2026-0925', toId: 'brand-apexcareer', relType: 'IMPERSONATES' },
  { fromId: 'INC-2026-0925', toId: 'camp-work-job-09', relType: 'PART_OF' },

  // --- Cross-Campaign Incident ---
  { fromId: 'INC-2026-1002', toId: 'ind-infra-ssl', relType: 'MENTIONS' },
  { fromId: 'INC-2026-1002', toId: 'ind-infra-nameserver', relType: 'MENTIONS' },
  { fromId: 'INC-2026-1002', toId: 'camp-phish-fin-01', relType: 'PART_OF' },
  { fromId: 'INC-2026-1002', toId: 'camp-courier-04', relType: 'PART_OF' },

  // --- Indicator to Indicator Technical Links (LINKED_TO) ---
  { fromId: 'ind-ns-verify', toId: 'ind-ip-fin-shared', relType: 'LINKED_TO', properties: { basis: 'DNS_RESOLVES_TO', confidence: 0.98 } },
  { fromId: 'ind-ns-secure', toId: 'ind-ip-fin-shared', relType: 'LINKED_TO', properties: { basis: 'DNS_RESOLVES_TO', confidence: 0.98 } },
  { fromId: 'ind-ns-verify', toId: 'ind-infra-nameserver', relType: 'LINKED_TO', properties: { basis: 'AUTHORITATIVE_NS', confidence: 0.95 } },
  { fromId: 'ind-ns-verify', toId: 'ind-infra-ssl', relType: 'LINKED_TO', properties: { basis: 'TLS_CERT_ISSUANCE', confidence: 0.94 } },
  { fromId: 'ind-ns-verify', toId: 'ind-ns-suburl', relType: 'LINKED_TO', properties: { basis: 'SUBPATH_PARENT', confidence: 1.0 } },
  { fromId: 'ind-phone-fin-01', toId: 'ind-ns-verify', relType: 'LINKED_TO', properties: { basis: 'SMS_LURE_TARGET', confidence: 0.92 } },
  { fromId: 'ind-pay-fin-ns', toId: 'ind-ns-verify', relType: 'LINKED_TO', properties: { basis: 'CO-REFERENCED_IN_LURE', confidence: 0.88 } },

  { fromId: 'ind-sd-pay', toId: 'ind-infra-ssl', relType: 'LINKED_TO', properties: { basis: 'SHARED_TLS_CERT', confidence: 0.92 } },
  { fromId: 'ind-sd-pay', toId: 'ind-infra-nameserver', relType: 'LINKED_TO', properties: { basis: 'AUTHORITATIVE_NS', confidence: 0.95 } },
  { fromId: 'ind-sd-pay', toId: 'ind-sd-url', relType: 'LINKED_TO', properties: { basis: 'SUBPATH_PARENT', confidence: 1.0 } },
  { fromId: 'ind-sd-track', toId: 'ind-sd-pay', relType: 'LINKED_TO', properties: { basis: 'REDIRECT_DESTINATION', confidence: 0.96 } },
  { fromId: 'ind-phone-courier-02', toId: 'ind-sd-pay', relType: 'LINKED_TO', properties: { basis: 'DISPATCH_SMS_ORIGIN', confidence: 0.90 } },
  { fromId: 'ind-pay-sd', toId: 'ind-sd-pay', relType: 'LINKED_TO', properties: { basis: 'PAYMENT_CHECKOUT_DESTINATION', confidence: 0.93 } },
  { fromId: 'ind-email-courier', toId: 'ind-sd-pay', relType: 'LINKED_TO', properties: { basis: 'NOTIFICATION_HEADER_LINK', confidence: 0.86 } },

  { fromId: 'ind-apex-fee', toId: 'ind-apex-portal', relType: 'LINKED_TO', properties: { basis: 'CANONICAL_HOST_LINK', confidence: 0.91 } },
  { fromId: 'ind-phone-job-03', toId: 'ind-apex-fee', relType: 'LINKED_TO', properties: { basis: 'RECRUITER_SMS_LINK', confidence: 0.94 } },
  { fromId: 'ind-pay-apex-crypto', toId: 'ind-apex-fee', relType: 'LINKED_TO', properties: { basis: 'SPECIFIED_DEPOSIT_WALLET', confidence: 0.98 } },
  { fromId: 'ind-pay-apex-cashapp', toId: 'ind-apex-fee', relType: 'LINKED_TO', properties: { basis: 'SECONDARY_PAYMENT_FALLBACK', confidence: 0.87 } },

  // --- Evidence to Incidents / Indicators ---
  { fromId: 'INC-2026-0801', toId: 'EVD-101', relType: 'SUPPORTED_BY' },
  { fromId: 'ind-ns-verify', toId: 'EVD-101', relType: 'SUPPORTED_BY' },
  { fromId: 'ind-ns-verify', toId: 'EVD-102', relType: 'SUPPORTED_BY' },
  { fromId: 'ind-phone-fin-01', toId: 'EVD-103', relType: 'SUPPORTED_BY' },
  { fromId: 'INC-2026-0801', toId: 'EVD-104', relType: 'SUPPORTED_BY' },

  { fromId: 'INC-2026-0901', toId: 'EVD-202', relType: 'SUPPORTED_BY' },
  { fromId: 'ind-sd-pay', toId: 'EVD-202', relType: 'SUPPORTED_BY' },
  { fromId: 'ind-sd-pay', toId: 'EVD-203', relType: 'SUPPORTED_BY' },
  { fromId: 'ind-pay-sd', toId: 'EVD-201', relType: 'SUPPORTED_BY' },

  { fromId: 'INC-2026-0915', toId: 'EVD-301', relType: 'SUPPORTED_BY' },
  { fromId: 'ind-apex-fee', toId: 'EVD-302', relType: 'SUPPORTED_BY' },
  { fromId: 'ind-phone-job-03', toId: 'EVD-303', relType: 'SUPPORTED_BY' },
  { fromId: 'ind-pay-apex-crypto', toId: 'EVD-301', relType: 'SUPPORTED_BY' }
];
