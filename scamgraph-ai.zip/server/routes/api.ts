import { Router, Request, Response } from 'express';
import { falkorService } from '../services/falkordb';
import { graphQueries } from '../services/graphQueries';
import { investigatorAgent } from '../services/agent';
import { extractEntities } from '../services/entityExtraction';

export const apiRouter = Router();

// Demo Scenarios catalog (including 3 known scams + 1 unknown indicator case)
const DEMO_SCENARIOS = [
  {
    id: 'scenario-northstar',
    title: 'Northstar Bank Urgent Lockout Phish',
    category: 'Banking Credential Phishing',
    targetBrand: 'Northstar Bank (Fictional)',
    promptMessage: 'URGENT: Northstar Bank says my account will be suspended in 24 hours unless I verify my identity at northstar-verify.test. Call +1-800-555-0199 if questions.',
    expectedOutcome: 'Multi-incident banking campaign match, shared nameserver/IP pivot, high risk score (85+).'
  },
  {
    id: 'scenario-swiftdrop',
    title: 'SwiftDrop Courier Customs Redelivery Scam',
    category: 'Courier Fee Extortion',
    targetBrand: 'SwiftDrop Logistics (Fictional)',
    promptMessage: 'SwiftDrop Logistics: Your package parcel-9842 is detained at customs. Pay pending $2.85 handling fee immediately at swiftdrop-pay.test or send to $swiftdrop-release to avoid return.',
    expectedOutcome: 'Credit card skimmer finding, shared TLS wildcard certificate pivot to Northstar infrastructure, high risk score.'
  },
  {
    id: 'scenario-apexcareer',
    title: 'Apex Global Work-From-Home Advance Fee',
    category: 'Employment Advance-Fee Fraud',
    targetBrand: 'Apex Global Careers (Fictional)',
    promptMessage: 'Congratulations! You have been accepted for the remote Data Analyst role at Apex Global Careers. Please complete onboarding and deposit your $350 training kit bond to 0x9f82c40134d4a8e2 or $apexcareers_hr at apex-career-fee.test.',
    expectedOutcome: 'Advance fee recruitment scam detection, cryptocurrency staging wallet, disposable recruiter VOIP link.'
  },
  {
    id: 'scenario-unknown',
    title: 'Uncataloged Vendor Domain (Unknown Case)',
    category: 'Unverified Indicator / Insufficient Data',
    targetBrand: 'Unknown Entity',
    promptMessage: 'Please review your quarterly corporate dashboard invoice at unknown-vendor-portal.test or submit support queries to support@unknown-vendor-portal.test.',
    expectedOutcome: 'Responsible handling: flags INSUFFICIENT EVIDENCE rather than declaring safe. Cautious defensive guidance.'
  }
];

// GET /api/health
apiRouter.get('/health', async (_req: Request, res: Response) => {
  const falkorStatus = falkorService.getStatus();
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    falkordb: falkorStatus,
    llmConfigured: Boolean(process.env.GEMINI_API_KEY || process.env.OPENAI_API_KEY),
    provider: process.env.GEMINI_API_KEY ? 'gemini' : process.env.OPENAI_API_KEY ? 'openai' : 'deterministic_evidence_engine'
  });
});

// GET /api/graph/overview
apiRouter.get('/graph/overview', async (_req: Request, res: Response) => {
  try {
    const stats = await graphQueries.getGraphStatistics();
    const falkorStatus = falkorService.getStatus();
    res.json({
      success: true,
      stats,
      falkordb: falkorStatus
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to fetch graph overview' });
  }
});

// POST /api/investigations/analyze
apiRouter.post('/investigations/analyze', async (req: Request, res: Response) => {
  try {
    const { text } = req.body;
    if (!text || typeof text !== 'string' || text.trim().length === 0) {
      return res.status(400).json({ success: false, error: 'A suspicious message, domain, or indicator text is required.' });
    }

    if (text.length > 5000) {
      return res.status(400).json({ success: false, error: 'Input message exceeds maximum limit of 5,000 characters.' });
    }

    const result = await investigatorAgent.runInvestigation(text.trim());
    return res.json({
      success: true,
      investigation: result
    });
  } catch (err: any) {
    console.error('Investigation execution error:', err);
    return res.status(500).json({
      success: false,
      error: 'An unexpected error occurred during graph investigation. Please verify input and retry.'
    });
  }
});

// GET /api/investigations
apiRouter.get('/investigations', async (req: Request, res: Response) => {
  try {
    const limit = parseInt(req.query.limit as string, 10) || 50;
    const history = await graphQueries.getInvestigationHistory(limit);
    res.json({
      success: true,
      history,
      total: history.length
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Failed to fetch investigation history' });
  }
});

// GET /api/investigations/:id
apiRouter.get('/investigations/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const record = await graphQueries.getInvestigationById(id);
    if (!record) {
      return res.status(404).json({ success: false, error: `Investigation with ID "${id}" was not found.` });
    }
    return res.json({ success: true, investigation: record });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Failed to load investigation' });
  }
});

// POST /api/investigations/:id/feedback
apiRouter.post('/investigations/:id/feedback', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { verdict, note } = req.body;

    if (!['CONFIRMED_FRAUD', 'NEEDS_REVIEW', 'FALSE_POSITIVE'].includes(verdict)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid feedback verdict. Allowed values: CONFIRMED_FRAUD, NEEDS_REVIEW, FALSE_POSITIVE.'
      });
    }

    const saved = await graphQueries.saveAnalystFeedback(id, verdict, note);
    if (!saved) {
      return res.status(404).json({ success: false, error: `Investigation "${id}" not found.` });
    }

    return res.json({
      success: true,
      message: 'Analyst feedback successfully recorded and linked to investigation in FalkorDB.',
      feedback: { verdict, note, timestamp: new Date().toISOString() }
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Failed to save feedback' });
  }
});

// GET /api/demo/scenarios
apiRouter.get('/demo/scenarios', (_req: Request, res: Response) => {
  res.json({
    success: true,
    scenarios: DEMO_SCENARIOS
  });
});

// POST /api/counterfactual/simulate
apiRouter.post('/counterfactual/simulate', (req: Request, res: Response) => {
  try {
    const { rawText, matchedIndicatorIds, excludedRuleIds } = req.body;
    const extraction = extractEntities(rawText || '');
    const simulatedAssessment = investigatorAgent.simulateCounterfactual({
      extraction,
      matchedIndicatorIds: Array.isArray(matchedIndicatorIds) ? matchedIndicatorIds : [],
      excludedRuleIds: Array.isArray(excludedRuleIds) ? excludedRuleIds : []
    });

    res.json({
      success: true,
      assessment: simulatedAssessment
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Counterfactual simulation failed' });
  }
});

// GET /api/reports/:id
apiRouter.get('/reports/:id', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const record = await graphQueries.getInvestigationById(id);
    if (!record) {
      return res.status(404).json({ success: false, error: 'Investigation report not found' });
    }

    const format = req.query.format || 'json';

    if (format === 'markdown') {
      const md = `
# ScamGraph AI — Investigation Dossier
**Investigation ID:** ${record.id}  
**Timestamp:** ${record.timestamp}  
**Risk Score:** ${record.riskScore}/100 (${record.riskLevel})  
**Evidence Confidence:** ${record.evidenceConfidence}% | **Coverage:** ${record.evidenceCoverage}

---

## 1. Executive Summary
${record.summary}

## 2. Submitted Input
> ${record.rawTextPreview}

## 3. Matched Indicators in FalkorDB
${record.matchedIndicatorIds.map(id => `- \`${id}\``).join('\n') || '- None matched'}

## 4. Key Findings
${record.findings.map(f => `### ${f.title} [${f.severity}]\n${f.description}\n*Corroborating Evidence:* ${f.evidenceIds.join(', ') || 'Heuristic pattern'}`).join('\n\n')}

## 5. Discovered Relationship Paths
${record.evidencePaths.map(p => `- ${p.summary}`).join('\n') || '- No multi-hop paths discovered.'}

## 6. Feedback
${record.feedback ? `**Analyst Verdict:** ${record.feedback.verdict} (${record.feedback.timestamp})\n**Note:** ${record.feedback.note || 'None'}` : 'No feedback registered yet.'}

---
*Notice: Synthetic intelligence decision-support report.*
`;
      res.setHeader('Content-Type', 'text/markdown');
      res.setHeader('Content-Disposition', `attachment; filename="scamgraph-investigation-${record.id}.md"`);
      return res.send(md);
    }

    return res.json({
      success: true,
      report: record
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err?.message || 'Report generation error' });
  }
});

// POST /api/graph/seed
apiRouter.post('/graph/seed', async (_req: Request, res: Response) => {
  try {
    falkorService.seedMemoryStore();
    await falkorService.seedLiveDatabase();
    const stats = await graphQueries.getGraphStatistics();
    res.json({
      success: true,
      message: 'FalkorDB graph store successfully re-seeded with synthetic intelligence dataset.',
      stats
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Seeding failed' });
  }
});

// POST /api/graph/test-connection
apiRouter.post('/graph/test-connection', async (req: Request, res: Response) => {
  try {
    const { url } = req.body;
    const connected = await falkorService.connect(url);
    const status = falkorService.getStatus();
    res.json({
      success: true,
      connected,
      status
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err?.message || 'Connection test failed' });
  }
});
