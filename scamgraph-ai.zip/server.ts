import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { apiRouter } from './server/routes/api';
import { falkorService } from './server/services/falkordb';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;
  const isProduction = process.env.NODE_ENV === 'production';

  app.use(express.json({ limit: '5mb' }));
  app.use(express.urlencoded({ extended: true }));

  // API Router
  app.use('/api', apiRouter);

  // Background FalkorDB live connection check
  falkorService.connect().then(connected => {
    if (connected) {
      console.log('✅ Connected to live FalkorDB instance at', process.env.FALKORDB_URL || 'falkordb://localhost:6379');
    } else {
      console.log('ℹ️ Operating in FalkorDB Standalone Cypher Graph Mode (Host localhost:6379 not detected). Ready for Docker connection.');
    }
  }).catch(err => {
    console.warn('FalkorDB initial probe warning:', err?.message);
  });

  if (!isProduction) {
    // Development mode: mount Vite dev server middlewares
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        watch: process.env.DISABLE_HMR === 'true' ? null : {}
      },
      appType: 'spa'
    });

    app.use(vite.middlewares);
  } else {
    // Production mode: serve built assets from dist
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 ScamGraph AI server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Fatal server startup failure:', err);
  process.exit(1);
});
